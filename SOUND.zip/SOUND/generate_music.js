const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'music.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$genreFilter = isset($_GET['genre']) ? (int)$_GET['genre'] : 0;

$query = "SELECT m.*, a.name as artist_name, al.name as album_name, g.name as genre_name, l.name as language_name, y.year
          FROM music m 
          JOIN artists a ON m.artist_id = a.id 
          LEFT JOIN albums al ON m.album_id = al.id 
          LEFT JOIN genres g ON m.genre_id = g.id
          LEFT JOIN languages l ON m.language_id = l.id
          LEFT JOIN years y ON m.year_id = y.id
          WHERE m.status = 'active'";
$params = [];

if($search) {
    $query .= " AND (m.song_name LIKE ? OR a.name LIKE ? OR al.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%";
}
if($genreFilter) {
    $query .= " AND m.genre_id = ?";
    $params[] = $genreFilter;
}

$query .= " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$musicList = $stmt->fetchAll();

$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();

$pageTitle = "Explore Music";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Explore Music</h1>
            <p class="text-secondary">Discover songs from different artists, albums, genres, years and languages.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="music.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search for a song, artist or album..." value="<?= htmlspecialchars($search) ?>">
                <select name="genre" class="form-select w-auto">
                    <option value="">All Genres</option>
                    <?php foreach($genres as $g): ?>
                        <option value="<?= $g['id'] ?>" <?= $genreFilter == $g['id'] ? 'selected' : '' ?>><?= htmlspecialchars($g['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($musicList) > 0): ?>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
        <?php foreach($musicList as $music): ?>
        <div class="col">
            <div class="music-card h-100">
                <?php if($music['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light d-block h-100">
                    <div class="card-img-wrapper">
                        <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" alt="<?= htmlspecialchars($music['song_name']) ?>">
                        <div class="play-overlay">
                            <i class="fas fa-play-circle play-btn play-music-btn" 
                               data-src="/SOUND/assets/music/<?= $music['music_file'] ?>" 
                               data-title="<?= htmlspecialchars($music['song_name']) ?>" 
                               data-artist="<?= htmlspecialchars($music['artist_name']) ?>"
                               data-cover="/SOUND/assets/images/<?= $music['cover_image'] ?>"></i>
                        </div>
                    </div>
                    <div class="p-3">
                        <h6 class="mb-1 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                        <small class="text-secondary d-block text-truncate"><?= htmlspecialchars($music['artist_name']) ?></small>
                        <small class="text-muted"><?= htmlspecialchars($music['genre_name']) ?> • <?= $music['year'] ?></small>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-music fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No music found.</h4>
        <p class="text-secondary">Try changing your search or filter options to find more results.</p>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'music_details.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT m.*, a.name as artist_name, al.name as album_name, g.name as genre_name, l.name as language_name, y.year
          FROM music m 
          JOIN artists a ON m.artist_id = a.id 
          LEFT JOIN albums al ON m.album_id = al.id 
          LEFT JOIN genres g ON m.genre_id = g.id
          LEFT JOIN languages l ON m.language_id = l.id
          LEFT JOIN years y ON m.year_id = y.id
          WHERE m.id = ? AND m.status = 'active'");
$stmt->execute([$id]);
$music = $stmt->fetch();

if(!$music) {
    header("Location: 404.php");
    exit;
}

// Handle Review Submission
if($_SERVER['REQUEST_METHOD'] == 'POST' && isLoggedIn()) {
    $rating = (int)$_POST['rating'];
    $review_text = sanitize($_POST['review']);
    if($rating >= 1 && $rating <= 5) {
        $stmt = $pdo->prepare("INSERT INTO reviews (user_id, content_type, content_id, review, rating) VALUES (?, 'music', ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $id, $review_text, $rating]);
        $_SESSION['success'] = "Review submitted successfully!";
        header("Location: music_details.php?id=$id");
        exit;
    }
}

// Fetch Reviews
$stmt = $pdo->prepare("SELECT r.*, u.name as user_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.content_type = 'music' AND r.content_id = ? AND r.status = 'approved' ORDER BY r.created_at DESC");
$stmt->execute([$id]);
$reviews = $stmt->fetchAll();

// Calculate Rating
$stmt = $pdo->prepare("SELECT AVG(rating) as avg, COUNT(*) as cnt FROM reviews WHERE content_type = 'music' AND content_id = ? AND status = 'approved'");
$stmt->execute([$id]);
$ratingStats = $stmt->fetch();
$avgRating = round($ratingStats['avg'], 1);

$pageTitle = htmlspecialchars($music['song_name']);
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-secondary text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="music.php" class="text-secondary text-decoration-none">Music</a></li>
            <li class="breadcrumb-item active text-light" aria-current="page"><?= htmlspecialchars($music['song_name']) ?></li>
        </ol>
    </nav>

    <?= getFlashSuccess() ?>
    
    <div class="row mb-5">
        <div class="col-md-4 mb-4 mb-md-0">
            <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" alt="Cover" class="img-fluid rounded shadow-lg w-100">
            <button class="btn btn-primary w-100 mt-3 py-3 fw-bold fs-5 play-music-btn"
                    data-src="/SOUND/assets/music/<?= $music['music_file'] ?>" 
                    data-title="<?= htmlspecialchars($music['song_name']) ?>" 
                    data-artist="<?= htmlspecialchars($music['artist_name']) ?>"
                    data-cover="/SOUND/assets/images/<?= $music['cover_image'] ?>">
                <i class="fas fa-play-circle me-2"></i> Play
            </button>
        </div>
        <div class="col-md-8">
            <h1 class="fw-bold display-5 mb-1"><?= htmlspecialchars($music['song_name']) ?></h1>
            <h4 class="text-primary mb-3"><a href="artist_details.php?id=<?= $music['artist_id'] ?>" class="text-primary text-decoration-none"><?= htmlspecialchars($music['artist_name']) ?></a></h4>
            
            <div class="d-flex flex-wrap gap-3 mb-4 text-secondary">
                <span><i class="fas fa-compact-disc me-2"></i> <?= htmlspecialchars($music['album_name'] ?? 'Single') ?></span>
                <span><i class="fas fa-calendar me-2"></i> <?= htmlspecialchars($music['year'] ?? 'Unknown') ?></span>
                <span><i class="fas fa-music me-2"></i> <?= htmlspecialchars($music['genre_name'] ?? 'Unknown') ?></span>
                <span><i class="fas fa-globe me-2"></i> <?= htmlspecialchars($music['language_name'] ?? 'Unknown') ?></span>
                <?php if($ratingStats['cnt'] > 0): ?>
                    <span class="text-warning"><?= getStars(round($avgRating)) ?> (<?= $avgRating ?>)</span>
                <?php endif; ?>
            </div>

            <h5 class="fw-bold mt-4 mb-3 border-bottom border-secondary pb-2">About This Song</h5>
            <p class="text-light text-justify" style="line-height: 1.8;">
                <?= htmlspecialchars($music['description'] ?? $music['song_name'] . ' is a ' . ($music['genre_name']??'track') . ' track performed by ' . $music['artist_name'] . ' and released as part of the album ' . ($music['album_name']??'Single') . ' in ' . ($music['year']??'Unknown') . '.') ?>
            </p>
        </div>
    </div>

    <!-- Reviews Section -->
    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-4">User Reviews</h4>
            
            <?php if(isLoggedIn()): ?>
                <div class="card bg-dark border-secondary mb-4 p-4">
                    <h5 class="mb-3">Rate This Song</h5>
                    <p class="text-secondary mb-3">Share your rating and let other listeners know what you think.</p>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-light">Rating</label>
                            <select name="rating" class="form-select bg-dark text-light border-secondary w-auto" required>
                                <option value="5">5 Stars - Excellent</option>
                                <option value="4">4 Stars - Good</option>
                                <option value="3">3 Stars - Average</option>
                                <option value="2">2 Stars - Poor</option>
                                <option value="1">1 Star - Terrible</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Write a Review</label>
                            <textarea name="review" class="form-control bg-dark text-light border-secondary" rows="3" placeholder="Share your thoughts about this song..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit Review</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="alert alert-secondary bg-dark border-secondary text-light">
                    <p class="mb-0">Please <a href="auth/login.php" class="text-primary fw-bold">log in</a> to rate and review this song.</p>
                </div>
            <?php endif; ?>

            <?php if(count($reviews) > 0): ?>
                <?php foreach($reviews as $rev): ?>
                    <div class="card bg-transparent border-secondary mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0 fw-bold"><?= htmlspecialchars($rev['user_name']) ?></h6>
                                <small class="text-muted"><?= date('F j, Y', strtotime($rev['created_at'])) ?></small>
                            </div>
                            <div class="mb-2"><?= getStars($rev['rating']) ?></div>
                            <p class="text-light mb-0"><?= nl2br(htmlspecialchars($rev['review'])) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-secondary">No reviews yet. Be the first to review!</p>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <h5 class="fw-bold mb-4">More Like This</h5>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM music WHERE genre_id = ? AND id != ? LIMIT 4");
            $stmt->execute([$music['genre_id'], $id]);
            $related = $stmt->fetchAll();
            foreach($related as $rel):
            ?>
                <a href="music_details.php?id=<?= $rel['id'] ?>" class="d-flex align-items-center text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary">
                    <img src="/SOUND/assets/images/<?= $rel['cover_image'] ?>" class="rounded me-3" style="width:60px;height:60px;object-fit:cover;">
                    <div>
                        <h6 class="text-light mb-1 text-truncate" style="max-width: 200px;"><?= htmlspecialchars($rel['song_name']) ?></h6>
                        <small class="text-secondary">Listen</small>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
