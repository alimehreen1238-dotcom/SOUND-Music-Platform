<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$genreFilter = isset($_GET['genre']) ? (int)$_GET['genre'] : 0;

$query = "SELECT m.*, a.name as artist_name, al.name as album_name, g.name as genre_name, l.name as language_name, y.year
          FROM music m 
          JOIN artists a ON m.artist_id = a.id 
          LEFT JOIN albums al ON m.album_id = al.id 
          LEFT JOIN genres g ON m.genre_id = g.id
          LEFT JOIN languages l ON m.language_id = l.id
          LEFT JOIN years y ON m.year_id = y.id
          WHERE m.status = 'active'";
$params = [];

if($search) {
    $query .= " AND (m.song_name LIKE ? OR a.name LIKE ? OR al.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%";
}
if($genreFilter) {
    $query .= " AND m.genre_id = ?";
    $params[] = $genreFilter;
}

$query .= " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$musicList = $stmt->fetchAll();

$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();

$pageTitle = "Explore Music";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Explore Music</h1>
            <p class="text-secondary">Discover songs from different artists, albums, genres, years and languages.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="music.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search for a song, artist or album..." value="<?= htmlspecialchars($search) ?>" style="background:rgba(20,5,10,0.7);border:1px solid rgba(139,0,0,0.4);color:#fff;">
                <select name="genre" class="form-select w-auto" style="background:rgba(25,5,10,0.88);border:1px solid rgba(139,0,0,0.5);color:#fff;min-width:130px;">
                    <option value="" style="background:#1a0508;color:#fff;">All Genres</option>
                    <?php foreach($genres as $g): ?>
                        <option value="<?= $g['id'] ?>" <?= $genreFilter == $g['id'] ? 'selected' : '' ?> style="background:#1a0508;color:#fff;"><?= htmlspecialchars($g['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($musicList) > 0): ?>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
        <?php foreach($musicList as $music): ?>
        <div class="col">
            <div class="music-card h-100">
                <?php if($music['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light d-block h-100">
                    <div class="card-img-wrapper">
                        <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" alt="<?= htmlspecialchars($music['song_name']) ?>">
                        <div class="play-overlay">
                            <i class="fas fa-play-circle play-btn play-music-btn" 
                               data-src="/SOUND/assets/music/<?= $music['music_file'] ?>" 
                               data-title="<?= htmlspecialchars($music['song_name']) ?>" 
                               data-artist="<?= htmlspecialchars($music['artist_name']) ?>"
                               data-cover="/SOUND/assets/images/<?= $music['cover_image'] ?>"></i>
                        </div>
                    </div>
                    <div class="p-3">
                        <h6 class="mb-1 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                        <small class="text-secondary d-block text-truncate"><?= htmlspecialchars($music['artist_name']) ?></small>
                        <small class="text-muted"><?= htmlspecialchars($music['genre_name']) ?> • <?= $music['year'] ?></small>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-music fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No music found.</h4>
        <p class="text-secondary">Try changing your search or filter options to find more results.</p>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>