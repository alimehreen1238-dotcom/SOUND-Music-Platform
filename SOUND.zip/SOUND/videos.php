<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$query = "SELECT v.*, a.name as artist_name, al.name as album_name, y.year, l.name as language_name 
          FROM videos v 
          JOIN artists a ON v.artist_id = a.id 
          LEFT JOIN albums al ON v.album_id = al.id 
          LEFT JOIN years y ON v.year_id = y.id
          LEFT JOIN languages l ON v.language_id = l.id
          WHERE v.status = 'active'";
$params = [];

if($search) {
    $query .= " AND (v.video_name LIKE ? OR a.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%";
}

$query .= " ORDER BY v.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$videoList = $stmt->fetchAll();

$pageTitle = "Explore Videos";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Explore Videos</h1>
            <p class="text-secondary">Watch music videos and entertainment content from regional and English artists.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="videos.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search videos, artists or albums..." value="<?= htmlspecialchars($search) ?>" style="background:rgba(20,5,10,0.7);border:1px solid rgba(139,0,0,0.4);color:#fff;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($videoList) > 0): ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 gsap-stagger-cards">
        <?php foreach($videoList as $video): ?>
        <div class="col">
            <div class="video-card h-100">
                <?php if($video['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                <a href="video_details.php?id=<?= $video['id'] ?>" class="text-decoration-none text-light d-block h-100">
                    <div class="card-img-wrapper" style="height: 200px;">
                        <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" alt="<?= htmlspecialchars($video['video_name']) ?>">
                        <div class="play-overlay">
                            <i class="fas fa-play play-btn"></i>
                        </div>
                    </div>
                    <div class="p-3">
                        <h5 class="mb-1 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h5>
                        <p class="text-secondary mb-2 text-truncate"><?= htmlspecialchars($video['artist_name']) ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3 border-top border-secondary pt-2">
                            <small class="text-muted"><?= htmlspecialchars($video['year'] ?? 'Unknown') ?> • <?= htmlspecialchars($video['language_name'] ?? 'Unknown') ?></small>
                            <span class="btn btn-sm btn-watch-now rounded-pill px-3" style="background:#8B0000;color:#fff;border:1px solid #8B0000;font-size:0.8rem;transition:all 0.3s ease;">Watch Now</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-video fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No videos found.</h4>
        <p class="text-secondary">Try another search or adjust your filters.</p>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>