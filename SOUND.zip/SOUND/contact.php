<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "Thank you for contacting SOUND. Your message has been received.";
    header("Location: contact.php"); exit;
}
$pageTitle = "Contact SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row">
        <div class="col-md-6 mb-5 mb-md-0">
            <h1 class="fw-bold mb-3">Contact SOUND</h1>
            <p class="text-secondary mb-5">Have a question, suggestion or feedback? We'd love to hear from you. Send us a message and our team will get back to you.</p>
            
            <h4 class="fw-bold text-primary mb-4">Get in Touch</h4>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-envelope fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Email</h6>
                    <a href="mailto:<?= $settings['Contact Email'] ?? 'support@sound.com' ?>" class="text-primary text-decoration-none"><?= $settings['Contact Email'] ?? 'support@sound.com' ?></a>
                </div>
            </div>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-phone fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Phone</h6>
                    <span class="text-secondary"><?= $settings['Contact Phone'] ?? '+92 300 1234567' ?></span>
                </div>
            </div>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-map-marker-alt fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Location</h6>
                    <span class="text-secondary"><?= $settings['Address'] ?? 'Karachi, Pakistan' ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-dark border-secondary">
                <div class="card-body p-4">
                    <?= getFlashSuccess() ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-light">Full Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="Enter your phone number">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="Enter your subject" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label text-light">Message</label>
                            <textarea name="message" class="form-control" rows="5" placeholder="Write your message here..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>