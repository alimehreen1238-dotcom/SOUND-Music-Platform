const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'user/dashboard.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();
if(isAdmin()) { header("Location: /SOUND/admin/index.php"); exit; }

$stmt = $pdo->prepare("SELECT COUNT(*) FROM reviews WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$totalReviews = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM ratings WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$totalRatings = $stmt->fetchColumn();

$pageTitle = "Dashboard";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <h2 class="fw-bold mb-2">Welcome Back, <?= htmlspecialchars($_SESSION['name']) ?></h2>
    <p class="text-secondary mb-5">Manage your SOUND account, reviews and ratings from your personal dashboard.</p>
    
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-comment-dots fs-1 text-primary mb-3"></i>
                    <h4>My Reviews</h4>
                    <p class="text-secondary">You have <?= $totalReviews ?> reviews.</p>
                    <a href="my_reviews.php" class="btn btn-outline-light mt-2">Manage Reviews</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-star fs-1 text-primary mb-3"></i>
                    <h4>My Ratings</h4>
                    <p class="text-secondary">You have <?= $totalRatings ?> ratings.</p>
                    <a href="my_ratings.php" class="btn btn-outline-light mt-2">Manage Ratings</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-user fs-1 text-primary mb-3"></i>
                    <h4>My Profile</h4>
                    <p class="text-secondary">View and edit your account information.</p>
                    <a href="profile.php" class="btn btn-outline-light mt-2">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center">
        <a href="../music.php" class="btn btn-primary px-4 me-2">Explore Music</a>
        <a href="../videos.php" class="btn btn-outline-light px-4">Explore Videos</a>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'user/profile.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    
    $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
    if($stmt->execute([$name, $phone, $address, $_SESSION['user_id']])) {
        $_SESSION['name'] = $name;
        $_SESSION['success'] = "Your profile has been updated successfully.";
        header("Location: profile.php");
        exit;
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again.";
    }
}
$pageTitle = "My Profile";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark text-white border-secondary">
                <div class="card-header border-secondary bg-transparent p-4">
                    <h3 class="mb-1">My Profile</h3>
                    <p class="text-secondary mb-0">View and manage your personal account information.</p>
                </div>
                <div class="card-body p-4">
                    <?= getFlashSuccess() ?>
                    <?= getFlashError() ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-secondary">User ID</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($user['user_id']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-secondary">Email Address</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label text-light">Address</label>
                            <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($user['address']) ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                        <a href="dashboard.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'about.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
$pageTitle = "About SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">About SOUND</h1>
            <p class="lead text-secondary mb-5">
                <?= $settings['About Website'] ?? 'SOUND is an entertainment platform designed to bring music and video discovery together in one convenient digital experience.' ?>
            </p>
            
            <p class="text-light mb-5 text-justify">
                Our platform allows users to explore songs and videos according to artists, albums, genres, years and languages.
            </p>

            <h3 class="fw-bold mb-3 text-primary">Our Purpose</h3>
            <p class="text-light mb-5 text-justify">
                Our purpose is to make entertainment discovery simple, organized and enjoyable.
            </p>

            <h3 class="fw-bold mb-3 text-primary">What We Offer</h3>
            <ul class="list-unstyled text-light mb-5 ms-3">
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Music</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Videos</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Artists</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Albums</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Genres</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Languages</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Ratings & Reviews</li>
            </ul>

            <h3 class="fw-bold mb-3 text-primary">Our Vision</h3>
            <p class="text-light mb-5 text-justify">
                To create a digital space where people can easily discover sounds, artists and entertainment from different cultures and generations.
            </p>

            <h3 class="fw-bold mb-3 text-primary">Our Community</h3>
            <p class="text-light text-justify">
                SOUND gives registered users the opportunity to share their opinions by rating and reviewing available music and videos.
            </p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
