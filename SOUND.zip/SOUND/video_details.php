<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT v.*, a.name as artist_name, al.name as album_name, g.name as genre_name, l.name as language_name, y.year
          FROM videos v 
          JOIN artists a ON v.artist_id = a.id 
          LEFT JOIN albums al ON v.album_id = al.id 
          LEFT JOIN genres g ON v.genre_id = g.id
          LEFT JOIN languages l ON v.language_id = l.id
          LEFT JOIN years y ON v.year_id = y.id
          WHERE v.id = ? AND v.status = 'active'");
$stmt->execute([$id]);
$video = $stmt->fetch();

if(!$video) {
    header("Location: 404.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isLoggedIn()) {
    $rating = (int)$_POST['rating'];
    $review_text = sanitize($_POST['review']);
    if($rating >= 1 && $rating <= 5) {
        $stmt = $pdo->prepare("INSERT INTO reviews (user_id, content_type, content_id, review, rating) VALUES (?, 'video', ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $id, $review_text, $rating]);
        $_SESSION['success'] = "Review submitted successfully!";
        header("Location: video_details.php?id=$id");
        exit;
    }
}

$stmt = $pdo->prepare("SELECT r.*, u.name as user_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.content_type = 'video' AND r.content_id = ? AND r.status = 'approved' ORDER BY r.created_at DESC");
$stmt->execute([$id]);
$reviews = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT AVG(rating) as avg, COUNT(*) as cnt FROM reviews WHERE content_type = 'video' AND content_id = ? AND status = 'approved'");
$stmt->execute([$id]);
$ratingStats = $stmt->fetch();
$avgRating = round($ratingStats['avg'], 1);

$pageTitle = htmlspecialchars($video['video_name']);
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-secondary text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="videos.php" class="text-secondary text-decoration-none">Videos</a></li>
            <li class="breadcrumb-item active text-light" aria-current="page"><?= htmlspecialchars($video['video_name']) ?></li>
        </ol>
    </nav>

    <?= getFlashSuccess() ?>
    
    <div class="row mb-5">
        <div class="col-12 mb-4">
            <div class="ratio ratio-16x9 bg-black rounded shadow-lg overflow-hidden border border-secondary">
                <?php if($video['video_url']): ?>
                    <iframe src="<?= htmlspecialchars($video['video_url']) ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <?php else: ?>
                    <video controls poster="/SOUND/assets/images/<?= $video['thumbnail'] ?>">
                        <source src="/SOUND/assets/videos/<?= htmlspecialchars($video['video_file']) ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="col-md-8">
            <h1 class="fw-bold display-6 mb-1"><?= htmlspecialchars($video['video_name']) ?></h1>
            <h4 class="text-primary mb-3"><a href="artist_details.php?id=<?= $video['artist_id'] ?>" class="text-primary text-decoration-none"><?= htmlspecialchars($video['artist_name']) ?></a></h4>
            
            <div class="d-flex flex-wrap gap-3 mb-4 text-secondary">
                <span><i class="fas fa-compact-disc me-2"></i> <?= htmlspecialchars($video['album_name'] ?? 'Single') ?></span>
                <span><i class="fas fa-calendar me-2"></i> <?= htmlspecialchars($video['year'] ?? 'Unknown') ?></span>
                <span><i class="fas fa-music me-2"></i> <?= htmlspecialchars($video['genre_name'] ?? 'Unknown') ?></span>
                <span><i class="fas fa-globe me-2"></i> <?= htmlspecialchars($video['language_name'] ?? 'Unknown') ?></span>
                <?php if($ratingStats['cnt'] > 0): ?>
                    <span class="text-warning"><?= getStars(round($avgRating)) ?> (<?= $avgRating ?>)</span>
                <?php endif; ?>
            </div>

            <h5 class="fw-bold mt-4 mb-3 border-bottom border-secondary pb-2">About This Video</h5>
            <p class="text-light text-justify" style="line-height: 1.8;">
                <?= htmlspecialchars($video['description'] ?? 'Watch ' . $video['video_name'] . ' by ' . $video['artist_name'] . '. This video is part of ' . ($video['album_name']??'Single') . ' and was released in ' . ($video['year']??'Unknown') . '.') ?>
            </p>
        </div>
        
        <div class="col-md-4">
            <h5 class="fw-bold mb-4 mt-4 mt-md-0">Similar Videos</h5>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM videos WHERE genre_id = ? AND id != ? LIMIT 3");
            $stmt->execute([$video['genre_id'], $id]);
            $related = $stmt->fetchAll();
            foreach($related as $rel):
            ?>
                <a href="video_details.php?id=<?= $rel['id'] ?>" class="d-block text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary group">
                    <img src="/SOUND/assets/images/<?= $rel['thumbnail'] ?>" class="rounded w-100 mb-2" style="height:100px;object-fit:cover;">
                    <h6 class="text-light mb-1 text-truncate"><?= htmlspecialchars($rel['video_name']) ?></h6>
                    <small class="text-secondary"><?= htmlspecialchars($rel['artist_name'] ?? '') ?></small>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Reviews Section -->
    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-4">User Reviews</h4>
            <?php if(isLoggedIn()): ?>
                <div class="card bg-dark border-secondary mb-4 p-4">
                    <h5 class="mb-3">Rate This Video</h5>
                    <p class="text-secondary mb-3">How would you rate this video?</p>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-light">Rating</label>
                            <select name="rating" class="form-select bg-dark text-light border-secondary w-auto" required>
                                <option value="5">5 Stars - Excellent</option>
                                <option value="4">4 Stars - Good</option>
                                <option value="3">3 Stars - Average</option>
                                <option value="2">2 Stars - Poor</option>
                                <option value="1">1 Star - Terrible</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">User Reviews</label>
                            <textarea name="review" class="form-control bg-dark text-light border-secondary" rows="3" placeholder="Share your thoughts about this video with the SOUND community." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary px-4">Review</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="alert alert-secondary bg-dark border-secondary text-light">
                    <p class="mb-0">Please <a href="auth/login.php" class="text-primary fw-bold">log in</a> to rate and review this video.</p>
                </div>
            <?php endif; ?>

            <?php if(count($reviews) > 0): ?>
                <?php foreach($reviews as $rev): ?>
                    <div class="card bg-transparent border-secondary mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0 fw-bold"><?= htmlspecialchars($rev['user_name']) ?></h6>
                                <small class="text-muted"><?= date('F j, Y', strtotime($rev['created_at'])) ?></small>
                            </div>
                            <div class="mb-2"><?= getStars($rev['rating']) ?></div>
                            <p class="text-light mb-0"><?= nl2br(htmlspecialchars($rev['review'])) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-secondary">No reviews yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>