const https = require('https');
const fs = require('fs');

const download = (prompt, file) => new Promise((resolve) => {
    const seed = Math.floor(Math.random() * 999999);
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1920&height=1080&nologo=true&seed=${seed}`;
    console.log(`Downloading to ${file}...`);
    https.get(url, res => {
        if (res.statusCode === 200) {
            const w = fs.createWriteStream(file);
            res.pipe(w);
            w.on('finish', () => resolve(true));
        } else if (res.headers.location) {
            https.get(res.headers.location, res2 => {
                if (res2.statusCode === 200) {
                    const w = fs.createWriteStream(file);
                    res2.pipe(w);
                    w.on('finish', () => resolve(true));
                } else {
                    console.log("Error on redirect: ", res2.statusCode);
                    resolve(false);
                }
            }).on('error', (e) => { console.log(e); resolve(false); });
        } else {
            console.log("Status: ", res.statusCode);
            resolve(false);
        }
    }).on('error', (e) => { console.log(e); resolve(false); });
});

async function run() {
    while(!fs.existsSync("C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide2.jpg")) {
        let res = await download("HD photorealistic portrait of a modern Gen-Z Pakistani music producer working in a dark recording studio with a mixing console and red LED lighting, Behind the Beats, professional cinematic photography, no text", "C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide2.jpg");
        if(res) break;
        await new Promise(r => setTimeout(r, 2000));
    }
    
    while(!fs.existsSync("C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide3.jpg")) {
        let res = await download("HD cinematic portrait of a young modern Pakistani indie singer performing with passion into a studio microphone, stylish Gen-Z fashion, Voice of a Generation, maroon background glow, no text", "C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide3.jpg");
        if(res) break;
        await new Promise(r => setTimeout(r, 2000));
    }
    
    console.log("Done");
}

run();
