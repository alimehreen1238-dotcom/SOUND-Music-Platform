<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT a.*, g.name as genre_name, l.name as language_name
          FROM artists a
          LEFT JOIN genres g ON a.genre_id = g.id
          LEFT JOIN languages l ON a.language_id = l.id
          WHERE a.id = ?");
$stmt->execute([$id]);
$artist = $stmt->fetch();

if(!$artist) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM music WHERE artist_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 8");
$stmt->execute([$id]);
$musicList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM videos WHERE artist_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 6");
$stmt->execute([$id]);
$videoList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM albums WHERE artist_id = ? ORDER BY created_at DESC LIMIT 6");
$stmt->execute([$id]);
$albumList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($artist['name']);
require_once 'includes/header.php';
?>
<!-- Artist Hero -->
<section class="position-relative" style="height: 400px; background: linear-gradient(to top, rgba(10,10,10,1), rgba(10,10,10,0.4)), url('/SOUND/assets/images/<?= $artist['image'] ?>') center/cover; margin-top: -80px; padding-top: 80px;">
    <div class="container h-100 d-flex align-items-end pb-5 gsap-fade-up">
        <div class="d-flex align-items-end">
            <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle border border-4 border-dark me-4 shadow" style="width:200px;height:200px;object-fit:cover;">
            <div>
                <h1 class="display-3 fw-bold text-white mb-2"><?= htmlspecialchars($artist['name']) ?></h1>
                <p class="fs-5 text-light mb-0">
                    <span class="badge bg-primary me-2"><?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?></span>
                    <span class="badge bg-secondary me-2"><?= htmlspecialchars($artist['language_name'] ?? 'Various') ?></span>
                    <span class="text-muted"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($artist['region'] ?? '') ?>, <?= htmlspecialchars($artist['country'] ?? '') ?></span>
                </p>
            </div>
        </div>
    </div>
</section>

<div class="container py-5 gsap-fade-up">
    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-3 border-bottom border-secondary pb-2">About the Artist</h4>
            <p class="text-light text-justify mb-5" style="line-height:1.8;">
                <?= htmlspecialchars($artist['name']) ?> is an artist known for their work in <?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?> music and entertainment. Explore the artist's music, videos and albums available on SOUND.
                <br><br>
                <?= nl2br(htmlspecialchars($artist['biography'] ?? '')) ?>
            </p>

            <h4 class="fw-bold mb-4">Music by <?= htmlspecialchars($artist['name']) ?></h4>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3 mb-5">
                <?php foreach($musicList as $music): ?>
                <div class="col">
                    <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none">
                        <div class="card bg-dark border-secondary h-100">
                            <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                            <div class="card-body p-2">
                                <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if(count($albumList) > 0): ?>
            <h4 class="fw-bold mb-4">Albums by <?= htmlspecialchars($artist['name']) ?></h4>
            <div class="row row-cols-2 row-cols-md-3 g-3 mb-5">
                <?php foreach($albumList as $album): ?>
                <div class="col">
                    <a href="album_details.php?id=<?= $album['id'] ?>" class="text-decoration-none">
                        <div class="card bg-dark border-secondary">
                            <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                            <div class="card-body p-2 text-center">
                                <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($album['name']) ?></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <?php if(count($videoList) > 0): ?>
            <h5 class="fw-bold mb-4">Videos by <?= htmlspecialchars($artist['name']) ?></h5>
            <?php foreach($videoList as $video): ?>
                <a href="video_details.php?id=<?= $video['id'] ?>" class="d-block text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary">
                    <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" class="rounded w-100 mb-2" style="height:120px;object-fit:cover;">
                    <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h6>
                </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>