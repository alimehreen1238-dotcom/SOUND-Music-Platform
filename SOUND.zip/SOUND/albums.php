<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$query = "SELECT al.*, a.name as artist_name, g.name as genre_name, y.year, l.name as language_name,
          (SELECT COUNT(*) FROM music WHERE album_id = al.id) as tracks
          FROM albums al
          LEFT JOIN artists a ON al.artist_id = a.id
          LEFT JOIN genres g ON al.genre_id = g.id
          LEFT JOIN years y ON al.year_id = y.id
          LEFT JOIN languages l ON al.language_id = l.id
          WHERE 1=1";
$params = [];

if($search) {
    $query .= " AND (al.name LIKE ? OR a.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%";
}
$query .= " ORDER BY al.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$albumList = $stmt->fetchAll();

$pageTitle = "Explore Albums";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Explore Albums</h1>
            <p class="text-secondary">Browse albums from different artists, genres, years and languages.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="albums.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search albums..." value="<?= htmlspecialchars($search) ?>" style="background:rgba(20,5,10,0.7);border:1px solid rgba(139,0,0,0.4);color:#fff;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($albumList) > 0): ?>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
        <?php foreach($albumList as $album): ?>
        <div class="col">
            <div class="album-card h-100 p-2">
                <a href="album_details.php?id=<?= $album['id'] ?>" class="text-decoration-none text-light d-block h-100">
                    <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="w-100 rounded mb-3 shadow" style="height:180px;object-fit:cover;">
                    <h6 class="fw-bold mb-1 text-truncate"><?= htmlspecialchars($album['name']) ?></h6>
                    <small class="text-secondary d-block text-truncate"><?= htmlspecialchars($album['artist_name']) ?></small>
                    <small class="text-muted d-block mt-2"><?= $album['year'] ?? 'Unknown' ?> • <?= $album['tracks'] ?> tracks</small>
                    <div class="mt-3 text-center"><span class="btn btn-sm btn-outline-light w-100">View Album</span></div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-record-vinyl fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No albums found.</h4>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
