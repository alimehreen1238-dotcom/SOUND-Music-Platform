const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'faq.php': `<?php
require_once 'config/db.php';
$pageTitle = "FAQ";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4 text-center">Frequently Asked Questions</h1>
            
            <div class="accordion accordion-flush" id="faqAccordion">
                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                            What is SOUND?
                        </button>
                    </h2>
                    <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            SOUND is an entertainment website where users can discover music, videos, artists, albums, genres and languages.
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                            Do I need an account to browse content?
                        </button>
                    </h2>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            No. Visitors can browse available music and videos without creating an account.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                            Why should I create an account?
                        </button>
                    </h2>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Registered users can rate and review music and videos and manage their account information.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                            Can I search for a specific artist?
                        </button>
                    </h2>
                    <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. You can search by artist name and explore their available music, videos and albums.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                            Can I search by year?
                        </button>
                    </h2>
                    <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Music and videos can be filtered according to their release year.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                            Can I edit my review?
                        </button>
                    </h2>
                    <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. You can modify your own reviews from your account.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq7">
                            Can I change my rating?
                        </button>
                    </h2>
                    <div id="faq7" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Registered users can update their ratings.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq8">
                            Is registration free?
                        </button>
                    </h2>
                    <div id="faq8" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Creating a SOUND account is free.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'privacy_policy.php': `<?php
require_once 'config/db.php';
$pageTitle = "Privacy Policy";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">Privacy Policy</h1>
            <p class="text-secondary mb-5">At SOUND, we respect your privacy and are committed to protecting the information you provide while using our website.</p>
            
            <h4 class="fw-bold text-primary mb-3">Information We Collect</h4>
            <p class="text-light mb-4">When you create an account, we may collect information such as your name, address, phone number, email address and account credentials.</p>

            <h4 class="fw-bold text-primary mb-3">How We Use Information</h4>
            <p class="text-light mb-4">Information may be used to create and manage your account, provide website functionality, maintain security and improve the user experience.</p>

            <h4 class="fw-bold text-primary mb-3">Reviews and Ratings</h4>
            <p class="text-light mb-4">Reviews and ratings submitted by registered users may be displayed alongside the relevant music or video content.</p>

            <h4 class="fw-bold text-primary mb-3">Data Security</h4>
            <p class="text-light mb-4">We take reasonable measures to protect user information and prevent unauthorized access.</p>

            <h4 class="fw-bold text-primary mb-3">Cookies</h4>
            <p class="text-light mb-4">SOUND may use cookies or similar technologies to support website functionality and improve the browsing experience.</p>

            <h4 class="fw-bold text-primary mb-3">Changes</h4>
            <p class="text-light mb-4">This Privacy Policy may be updated when necessary. Users are encouraged to review this page periodically.</p>

            <h4 class="fw-bold text-primary mb-3">Contact</h4>
            <p class="text-light mb-4">If you have questions about this Privacy Policy, please <a href="contact.php" class="text-primary">contact us</a> through the Contact page.</p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'terms_conditions.php': `<?php
require_once 'config/db.php';
$pageTitle = "Terms & Conditions";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">Terms & Conditions</h1>
            <p class="text-secondary mb-5">By accessing and using SOUND, you agree to follow these Terms & Conditions.</p>
            
            <h4 class="fw-bold text-primary mb-3">User Accounts</h4>
            <p class="text-light mb-4">Users are responsible for providing accurate information during registration and maintaining the security of their account credentials.</p>

            <h4 class="fw-bold text-primary mb-3">Website Content</h4>
            <p class="text-light mb-4">Music, videos, images, descriptions and other content available on the website are provided for entertainment and informational purposes.</p>

            <h4 class="fw-bold text-primary mb-3">Reviews</h4>
            <p class="text-light mb-4">Users are responsible for the content of reviews they submit. Reviews should be relevant, respectful and appropriate.</p>

            <h4 class="fw-bold text-primary mb-3">Ratings</h4>
            <p class="text-light mb-4">Users may provide ratings based on their personal experience and opinion.</p>

            <h4 class="fw-bold text-primary mb-3">Prohibited Activities</h4>
            <p class="text-light mb-4">Users must not attempt to misuse the website, gain unauthorized access, interfere with website functionality or submit unlawful content.</p>

            <h4 class="fw-bold text-primary mb-3">Intellectual Property</h4>
            <p class="text-light mb-4">Website content may be protected by applicable intellectual property laws. Users should not reproduce or distribute content without appropriate authorization.</p>

            <h4 class="fw-bold text-primary mb-3">Changes</h4>
            <p class="text-light mb-4">SOUND may update these Terms & Conditions when necessary.</p>

            <h4 class="fw-bold text-primary mb-3">Contact</h4>
            <p class="text-light mb-4">For questions regarding these terms, please <a href="contact.php" class="text-primary">contact SOUND</a> through the Contact page.</p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'contact.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "Thank you for contacting SOUND. Your message has been received.";
    header("Location: contact.php"); exit;
}
$pageTitle = "Contact SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row">
        <div class="col-md-6 mb-5 mb-md-0">
            <h1 class="fw-bold mb-3">Contact SOUND</h1>
            <p class="text-secondary mb-5">Have a question, suggestion or feedback? We'd love to hear from you. Send us a message and our team will get back to you.</p>
            
            <h4 class="fw-bold text-primary mb-4">Get in Touch</h4>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-envelope fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Email</h6>
                    <a href="mailto:<?= $settings['Contact Email'] ?? 'support@sound.com' ?>" class="text-primary text-decoration-none"><?= $settings['Contact Email'] ?? 'support@sound.com' ?></a>
                </div>
            </div>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-phone fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Phone</h6>
                    <span class="text-secondary"><?= $settings['Contact Phone'] ?? '+92 300 1234567' ?></span>
                </div>
            </div>
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-map-marker-alt fs-3 text-secondary me-3" style="width: 30px;"></i>
                <div>
                    <h6 class="mb-1 text-light">Location</h6>
                    <span class="text-secondary"><?= $settings['Address'] ?? 'Karachi, Pakistan' ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-dark border-secondary">
                <div class="card-body p-4">
                    <?= getFlashSuccess() ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-light">Full Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="Enter your phone number">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="Enter your subject" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label text-light">Message</label>
                            <textarea name="message" class="form-control" rows="5" placeholder="Write your message here..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'auth/forgot_password.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "If an account exists with this email address, password reset instructions have been sent.";
    header("Location: forgot_password.php"); exit;
}
$pageTitle = "Forgot Password";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Forgot Your Password?</h2>
        <p class="text-center text-secondary mb-4">Enter the email address associated with your SOUND account and we'll help you reset your password.</p>
        <?= getFlashSuccess() ?>
        <form method="POST">
            <div class="mb-4">
                <label class="form-label text-light">Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Send Reset Link</button>
        </form>
        <div class="text-center mt-4">
            <a href="login.php" class="text-primary text-decoration-none"><i class="fas fa-arrow-left me-2"></i>Back to Login</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'auth/reset_password.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "Your password has been updated successfully.";
    header("Location: login.php"); exit;
}
$pageTitle = "Reset Password";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Create a New Password</h2>
        <p class="text-center text-secondary mb-4">Enter a new password for your SOUND account.</p>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light">New Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-4">
                <label class="form-label text-light">Confirm New Password</label>
                <input type="password" name="confirm" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Reset Password</button>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
