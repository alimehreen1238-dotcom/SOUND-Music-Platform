<?php
require_once 'config/db.php';
header('Content-Type: application/json');

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$query = isset($data['query']) ? trim(strtolower($data['query'])) : '';

if (empty($query)) {
    echo json_encode(['reply' => 'Please ask a question.', 'results' => []]);
    exit;
}

$reply = "";
$results = [];

// Helper functions for matching
function contains($str, $keyword) {
    return strpos($str, $keyword) !== false;
}

try {
    // 0. Hardcoded Rule-based Greetings
    if ($query === 'hi') {
        echo json_encode(['reply' => 'Hello! 👋 Welcome to SOUND. How can I help you today?', 'results' => []]);
        exit;
    }
    if ($query === 'hello') {
        echo json_encode(['reply' => 'Hey! Welcome to SOUND 🎵 What would you like to explore?', 'results' => []]);
        exit;
    }
    if ($query === 'what is sound?' || $query === 'what is sound') {
        echo json_encode(['reply' => 'SOUND is a music and entertainment platform where you can explore music, videos, artists, albums, genres and more.', 'results' => []]);
        exit;
    }
    if ($query === 'tell me about music') {
        echo json_encode(['reply' => 'Sure! You can explore the latest music, artists, albums and different genres on SOUND.', 'results' => []]);
        exit;
    }
    if ($query === 'who are the artists?' || $query === 'who are the artists') {
        echo json_encode(['reply' => 'You can explore artists from different music categories and languages in the Artists section.', 'results' => []]);
        exit;
    }
    if ($query === 'help') {
        echo json_encode(['reply' => 'I can help you explore music, videos, artists, albums, genres, languages and other sections of SOUND.', 'results' => []]);
        exit;
    }

    // 1. Search for Artists
    if (contains($query, 'artist') || contains($query, 'singer') || preg_match('/songs by (.*)/', $query, $matches) || preg_match('/about (.*)/', $query, $matches)) {
        $search = isset($matches[1]) ? trim(str_replace('?', '', $matches[1])) : $query;
        $searchWords = explode(' ', $search);
        
        $sql = "SELECT id, name, image FROM artists WHERE name LIKE :search LIMIT 3";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['search' => "%" . $searchWords[0] . "%"]);
        $artists = $stmt->fetchAll();
        
        if ($artists) {
            $reply = "I found these artists matching your request:";
            foreach($artists as $art) {
                $results[] = [
                    'type' => 'artist',
                    'title' => $art['name'],
                    'image' => '/SOUND/assets/images/' . $art['image'],
                    'url' => '/SOUND/artist_details.php?id=' . $art['id']
                ];
                
                // Fetch some songs by this artist
                $s = $pdo->prepare("SELECT id, song_name, cover_image FROM music WHERE artist_id = ? LIMIT 3");
                $s->execute([$art['id']]);
                $songs = $s->fetchAll();
                foreach($songs as $song) {
                    $results[] = [
                        'type' => 'music',
                        'title' => $song['song_name'] . ' (by ' . $art['name'] . ')',
                        'image' => '/SOUND/assets/images/' . $song['cover_image'],
                        'url' => '/SOUND/music_details.php?id=' . $song['id']
                    ];
                }
            }
            echo json_encode(['reply' => $reply, 'results' => $results]);
            exit;
        }
    }
    
    // 2. Search for Languages (e.g. Punjabi, Urdu)
    $stmt = $pdo->query("SELECT id, name FROM languages");
    $allLangs = $stmt->fetchAll();
    foreach($allLangs as $lang) {
        if (contains($query, strtolower($lang['name']))) {
            // Find songs in this language
            $s = $pdo->prepare("SELECT m.id, m.song_name, m.cover_image, a.name as artist_name FROM music m JOIN artists a ON m.artist_id = a.id WHERE m.language_id = ? LIMIT 5");
            $s->execute([$lang['id']]);
            $songs = $s->fetchAll();
            
            if ($songs) {
                $reply = "Here are some " . $lang['name'] . " songs from our collection:";
                foreach($songs as $song) {
                    $results[] = [
                        'type' => 'music',
                        'title' => $song['song_name'] . ' - ' . $song['artist_name'],
                        'image' => '/SOUND/assets/images/' . $song['cover_image'],
                        'url' => '/SOUND/music_details.php?id=' . $song['id']
                    ];
                }
                echo json_encode(['reply' => $reply, 'results' => $results]);
                exit;
            }
        }
    }
    
    // 3. Search for Genres (e.g. Pop, Sufi)
    $stmt = $pdo->query("SELECT id, name FROM genres");
    $allGenres = $stmt->fetchAll();
    foreach($allGenres as $genre) {
        if (contains($query, strtolower($genre['name']))) {
            $s = $pdo->prepare("SELECT m.id, m.song_name, m.cover_image, a.name as artist_name FROM music m JOIN artists a ON m.artist_id = a.id WHERE m.genre_id = ? LIMIT 5");
            $s->execute([$genre['id']]);
            $songs = $s->fetchAll();
            
            if ($songs) {
                $reply = "I found some great " . $genre['name'] . " tracks for you:";
                foreach($songs as $song) {
                    $results[] = [
                        'type' => 'music',
                        'title' => $song['song_name'] . ' - ' . $song['artist_name'],
                        'image' => '/SOUND/assets/images/' . $song['cover_image'],
                        'url' => '/SOUND/music_details.php?id=' . $song['id']
                    ];
                }
                echo json_encode(['reply' => $reply, 'results' => $results]);
                exit;
            }
        }
    }

    // 4. Search for Videos
    if (contains($query, 'video') || contains($query, 'watch')) {
        $search = str_replace(['video', 'videos', 'watch', 'show me', 'find'], '', $query);
        $search = trim($search);
        
        $sql = "SELECT v.id, v.video_name, v.thumbnail, a.name as artist_name FROM videos v JOIN artists a ON v.artist_id = a.id ";
        if (!empty($search)) {
            $sql .= "WHERE v.video_name LIKE :search OR a.name LIKE :search LIMIT 5";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['search' => "%$search%"]);
        } else {
            $sql .= "ORDER BY RAND() LIMIT 5";
            $stmt = $pdo->query($sql);
        }
        
        $vids = $stmt->fetchAll();
        if ($vids) {
            $reply = "Here are some videos you can watch:";
            foreach($vids as $vid) {
                $results[] = [
                    'type' => 'video',
                    'title' => $vid['video_name'] . ' - ' . $vid['artist_name'],
                    'image' => '/SOUND/assets/images/' . $vid['thumbnail'],
                    'url' => '/SOUND/video_details.php?id=' . $vid['id']
                ];
            }
            echo json_encode(['reply' => $reply, 'results' => $results]);
            exit;
        }
    }
    
    // 5. Search for Albums
    if (contains($query, 'album')) {
        $stmt = $pdo->query("SELECT al.id, al.name, al.cover, a.name as artist_name FROM albums al JOIN artists a ON al.artist_id = a.id ORDER BY RAND() LIMIT 5");
        $albs = $stmt->fetchAll();
        if ($albs) {
            $reply = "Here are some popular albums available right now:";
            foreach($albs as $alb) {
                $results[] = [
                    'type' => 'album',
                    'title' => $alb['name'] . ' by ' . $alb['artist_name'],
                    'image' => '/SOUND/assets/images/' . $alb['cover'],
                    'url' => '/SOUND/album_details.php?id=' . $alb['id']
                ];
            }
            echo json_encode(['reply' => $reply, 'results' => $results]);
            exit;
        }
    }

    // 6. Generic Music Search (Fallback)
    $cleanQuery = str_replace(['play', 'find', 'search', 'music', 'songs', 'song', '?'], '', $query);
    $cleanQuery = trim($cleanQuery);
    
    if (!empty($cleanQuery)) {
        $stmt = $pdo->prepare("SELECT m.id, m.song_name, m.cover_image, a.name as artist_name FROM music m JOIN artists a ON m.artist_id = a.id WHERE m.song_name LIKE ? OR a.name LIKE ? LIMIT 5");
        $stmt->execute(["%$cleanQuery%", "%$cleanQuery%"]);
        $songs = $stmt->fetchAll();
        
        if ($songs) {
            $reply = "I found these results based on your search:";
            foreach($songs as $song) {
                $results[] = [
                    'type' => 'music',
                    'title' => $song['song_name'] . ' - ' . $song['artist_name'],
                    'image' => '/SOUND/assets/images/' . $song['cover_image'],
                    'url' => '/SOUND/music_details.php?id=' . $song['id']
                ];
            }
            echo json_encode(['reply' => $reply, 'results' => $results]);
            exit;
        }
    }
    
    // Default Fallback
    echo json_encode([
        'reply' => "I'm not sure how to find that right now, but you can explore our latest music and videos on the homepage! Try asking me 'Show me Punjabi songs' or 'Find albums'.",
        'results' => []
    ]);

} catch (PDOException $e) {
    echo json_encode(['reply' => 'Sorry, I encountered a database error while searching.', 'results' => []]);
}
