-- SOUND Database Schema
CREATE DATABASE IF NOT EXISTS sound_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sound_db;

CREATE TABLE website_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    user_id VARCHAR(50) UNIQUE NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE genres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE languages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE years (
    id INT AUTO_INCREMENT PRIMARY KEY,
    year INT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE artists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    biography TEXT,
    image VARCHAR(255) DEFAULT 'default_artist.jpg',
    country VARCHAR(50),
    region VARCHAR(50),
    genre_id INT,
    language_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE SET NULL
);

CREATE TABLE albums (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    artist_id INT,
    genre_id INT,
    year_id INT,
    language_id INT,
    description TEXT,
    cover VARCHAR(255) DEFAULT 'default_album.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE SET NULL,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL,
    FOREIGN KEY (year_id) REFERENCES years(id) ON DELETE SET NULL,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE SET NULL
);

CREATE TABLE music (
    id INT AUTO_INCREMENT PRIMARY KEY,
    song_name VARCHAR(100) NOT NULL,
    artist_id INT,
    album_id INT,
    genre_id INT,
    year_id INT,
    language_id INT,
    description TEXT,
    music_file VARCHAR(255) NOT NULL,
    cover_image VARCHAR(255) DEFAULT 'default_music.jpg',
    release_date DATE,
    is_new BOOLEAN DEFAULT TRUE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE SET NULL,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL,
    FOREIGN KEY (year_id) REFERENCES years(id) ON DELETE SET NULL,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE SET NULL
);

CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    video_name VARCHAR(100) NOT NULL,
    artist_id INT,
    album_id INT,
    genre_id INT,
    year_id INT,
    language_id INT,
    description TEXT,
    video_file VARCHAR(255),
    video_url VARCHAR(255),
    thumbnail VARCHAR(255) DEFAULT 'default_video.jpg',
    release_date DATE,
    is_new BOOLEAN DEFAULT TRUE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE SET NULL,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL,
    FOREIGN KEY (year_id) REFERENCES years(id) ON DELETE SET NULL,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE SET NULL
);

CREATE TABLE ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    content_type ENUM('music', 'video') NOT NULL,
    content_id INT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE(user_id, content_type, content_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    content_type ENUM('music', 'video') NOT NULL,
    content_id INT NOT NULL,
    review TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    status ENUM('pending', 'approved', 'hidden') DEFAULT 'approved',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert Dummy Data
INSERT INTO website_settings (setting_key, setting_value) VALUES 
('Website Name', 'SOUND'),
('Website Tagline', 'Your Sound. Your World.'),
('About Website', 'SOUND is an entertainment platform designed to bring music and video discovery together in one convenient digital experience.'),
('Contact Email', 'support@sound.com'),
('Contact Phone', '+92 300 1234567'),
('Address', 'Karachi, Pakistan'),
('Facebook URL', '#'),
('Instagram URL', '#'),
('YouTube URL', '#'),
('Footer Text', 'Made for entertainment, discovery and connection.'),
('Copyright Text', '© 2026 SOUND. All Rights Reserved.'),
('Hero Heading', 'Your Sound. Your World.'),
('Hero Description', 'Discover music, videos, artists and stories from different cultures, languages and generations — all in one immersive place.'),
('Welcome Heading', 'Welcome to SOUND'),
('Welcome Description', 'Welcome to SOUND, your destination for discovering music and entertainment. Explore the latest songs, classic favorites, exciting videos, talented artists and diverse genres from regional and English entertainment.');

INSERT INTO users (name, user_id, address, phone, email, password, role) VALUES 
('Admin User', 'admin', 'Admin HQ', '03001234567', 'admin@sound.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'), -- password is 'password'
('Demo User', 'demo_user', 'Demo Street', '03001234568', 'user@sound.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

INSERT INTO genres (name, description) VALUES 
('Pop', 'Popular music'), ('Rock', 'Rock music'), ('Classical', 'Classical music'), 
('Folk', 'Traditional Folk music'), ('Hip Hop', 'Hip Hop and Rap'), ('Sufi', 'Sufi devotional music'), 
('Romantic', 'Romantic melodies'), ('Electronic', 'Electronic Dance Music'), 
('Jazz', 'Jazz music'), ('Traditional', 'Traditional local music'), ('Fusion', 'Blend of styles');

INSERT INTO languages (name, description) VALUES 
('English', 'English Language'), ('Urdu', 'Urdu Language'), ('Punjabi', 'Punjabi Language'), 
('Sindhi', 'Sindhi Language'), ('Pashto', 'Pashto Language'), ('Balochi', 'Balochi Language'), 
('Saraiki', 'Saraiki Language'), ('Hindi', 'Hindi Language');

INSERT INTO years (year) VALUES (2020), (2021), (2022), (2023), (2024), (2025), (2026);

INSERT INTO artists (name, biography, country, region, genre_id, language_id) VALUES 
('Ali Zafar', 'Famous Pakistani singer and actor.', 'Pakistan', 'Punjab', 1, 2),
('Atif Aslam', 'Internationally acclaimed vocalist.', 'Pakistan', 'Punjab', 7, 2),
('Abida Parveen', 'Queen of Sufi music.', 'Pakistan', 'Sindh', 6, 2),
('Nusrat Fateh Ali Khan', 'Legendary Qawwali maestro.', 'Pakistan', 'Punjab', 6, 3),
('Strings', 'Iconic pop rock band.', 'Pakistan', 'Sindh', 2, 2),
('Nazia Hassan', 'Queen of South Asian pop.', 'Pakistan', 'Sindh', 1, 2),
('Bohemia', 'Pioneer of Punjabi Rap.', 'Pakistan', 'Punjab', 5, 3),
('Mai Dhai', 'Traditional folk singer.', 'Pakistan', 'Sindh', 4, 4),
('Zeb Bangash', 'Versatile singer of regional and fusion music.', 'Pakistan', 'KPK', 11, 5),
('Aima Baig', 'Contemporary pop singer.', 'Pakistan', 'Punjab', 1, 2);

INSERT INTO albums (name, artist_id, genre_id, year_id, language_id, description) VALUES 
('Jhoom', 1, 1, 2, 2, 'A wonderful album.'),
('Jal Pari', 2, 1, 1, 2, 'Classic debut album.'),
('Raqs-e-Bismil', 3, 6, 3, 2, 'Soulful sufi renditions.'),
('Mustt Mustt', 4, 6, 1, 3, 'Legendary international album.'),
('Duur', 5, 2, 1, 2, 'The hit pop rock album.'),
('Disco Deewane', 6, 1, 1, 2, 'The biggest selling pop album.'),
('Pesa Nasha Pyar', 7, 5, 2, 3, 'Groundbreaking rap album.'),
('Folk Tales', 8, 4, 3, 4, 'Songs of the desert.'),
('Sandara', 9, 11, 4, 5, 'A fusion masterpiece.'),
('Aima Top Hits', 10, 1, 5, 2, 'Collection of recent hits.');

-- Insert at least 20 music tracks
INSERT INTO music (song_name, artist_id, album_id, genre_id, year_id, language_id, description, music_file, is_new) VALUES 
('Midnight in Lahore', 1, 1, 1, 5, 2, 'A beautiful pop track.', 'dummy.mp3', 1),
('Dil Ki Dastaan', 2, 2, 7, 4, 2, 'Romantic hit.', 'dummy.mp3', 1),
('Raat Ka Safar', 5, 5, 2, 3, 2, 'Rock anthem.', 'dummy.mp3', 0),
('Khwab', 10, 10, 1, 6, 2, 'Dreamy pop song.', 'dummy.mp3', 1),
('Ishq Da Rang', 4, 4, 6, 1, 3, 'Deep sufi vibe.', 'dummy.mp3', 0),
('Karachi Nights', 1, 1, 1, 7, 2, 'Upbeat pop track.', 'dummy.mp3', 1),
('Tere Baad', 2, 2, 7, 5, 2, 'Heartbreak melody.', 'dummy.mp3', 1),
('Rang-e-Mohabbat', 3, 3, 6, 2, 2, 'Sufi devotion.', 'dummy.mp3', 0),
('Saanson Mein', 6, 6, 1, 1, 2, 'Classic pop.', 'dummy.mp3', 0),
('Chandni', 5, 5, 2, 3, 2, 'Acoustic rock.', 'dummy.mp3', 1),
('Dil Se Pakistan', 1, 1, 1, 6, 2, 'Patriotic song.', 'dummy.mp3', 1),
('Shehr-e-Ishq', 3, 3, 6, 4, 2, 'Soulful track.', 'dummy.mp3', 1),
('Barish', 2, 2, 7, 6, 2, 'Monsoon romance.', 'dummy.mp3', 1),
('Yaadon Ka Shehar', 5, 5, 2, 5, 2, 'Nostalgic song.', 'dummy.mp3', 0),
('Safar', 10, 10, 1, 7, 2, 'Travel anthem.', 'dummy.mp3', 1),
('Kali Kali Zulfon Ke', 4, 4, 6, 1, 3, 'Masterpiece qawwali.', 'dummy.mp3', 0),
('Ek Din Aayega', 7, 7, 5, 4, 3, 'Rap classic.', 'dummy.mp3', 1),
('Sindhi Lada', 8, 8, 4, 5, 4, 'Traditional folk.', 'dummy.mp3', 1),
('Peshawar Beats', 9, 9, 11, 6, 5, 'Modern fusion.', 'dummy.mp3', 1),
('Lahore Diye', 7, 7, 5, 7, 3, 'Punjabi rap.', 'dummy.mp3', 1);

-- Insert at least 20 videos
INSERT INTO videos (video_name, artist_id, album_id, genre_id, year_id, language_id, description, video_url, is_new) VALUES 
('Midnight in Lahore Video', 1, 1, 1, 5, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Dil Ki Dastaan Video', 2, 2, 7, 4, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Raat Ka Safar Video', 5, 5, 2, 3, 2, 'Live Performance', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Khwab Video', 10, 10, 1, 6, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Ishq Da Rang Video', 4, 4, 6, 1, 3, 'Live Concert', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Karachi Nights Video', 1, 1, 1, 7, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Tere Baad Video', 2, 2, 7, 5, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Rang-e-Mohabbat Video', 3, 3, 6, 2, 2, 'Studio Session', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Saanson Mein Video', 6, 6, 1, 1, 2, 'Classic Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Chandni Video', 5, 5, 2, 3, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Dil Se Pakistan Video', 1, 1, 1, 6, 2, 'Patriotic Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Shehr-e-Ishq Video', 3, 3, 6, 4, 2, 'Live Performance', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Barish Video', 2, 2, 7, 6, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Yaadon Ka Shehar Video', 5, 5, 2, 5, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Safar Video', 10, 10, 1, 7, 2, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Kali Kali Zulfon Ke Video', 4, 4, 6, 1, 3, 'Live in London', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 0),
('Ek Din Aayega Video', 7, 7, 5, 4, 3, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Sindhi Lada Video', 8, 8, 4, 5, 4, 'Folk Performance', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Peshawar Beats Video', 9, 9, 11, 6, 5, 'Studio Session', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('Lahore Diye Video', 7, 7, 5, 7, 3, 'Official Music Video', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1);

-- Reviews & Ratings
INSERT INTO ratings (user_id, content_type, content_id, rating) VALUES 
(2, 'music', 1, 5), (2, 'music', 2, 4), (2, 'video', 1, 5);

INSERT INTO reviews (user_id, content_type, content_id, review, rating) VALUES 
(2, 'music', 1, 'Absolutely loved this track!', 5),
(2, 'music', 2, 'Great melody, touches the heart.', 4),
(2, 'video', 1, 'Amazing visuals and story.', 5);
