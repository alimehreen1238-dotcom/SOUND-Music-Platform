<?php
require_once 'config/db.php';
$pageTitle = "Explore SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up text-center">
    <h1 class="fw-bold mb-3 display-4">Explore SOUND</h1>
    <p class="text-secondary lead mb-5 max-w-lg mx-auto">Go beyond your usual favorites. Discover new music, videos, artists, albums and genres.</p>
    
    <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
        <div class="col">
            <a href="music.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-music fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Latest Music</h4>
                <p class="text-secondary mb-0">Discover the newest tracks.</p>
            </a>
        </div>
        <div class="col">
            <a href="videos.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-video fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Latest Videos</h4>
                <p class="text-secondary mb-0">Watch new visual experiences.</p>
            </a>
        </div>
        <div class="col">
            <a href="artists.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-users fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Featured Artists</h4>
                <p class="text-secondary mb-0">Explore talented creators.</p>
            </a>
        </div>
        <div class="col">
            <a href="albums.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-record-vinyl fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Popular Albums</h4>
                <p class="text-secondary mb-0">Browse album collections.</p>
            </a>
        </div>
        <div class="col">
            <a href="genres.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-compact-disc fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Popular Genres</h4>
                <p class="text-secondary mb-0">Find your perfect vibe.</p>
            </a>
        </div>
        <div class="col">
            <a href="languages.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-globe fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Regional Sounds</h4>
                <p class="text-secondary mb-0">Listen across cultures.</p>
            </a>
        </div>
    </div>
    
    <div class="bg-black p-5 rounded border border-secondary shadow-lg">
        <h3 class="fw-bold mb-3">There's always something new to discover.</h3>
        <a href="music.php" class="btn btn-primary btn-lg mt-3">Explore All Music</a>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>