<?php
require_once 'config/db.php';
$pageTitle = "FAQ";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4 text-center">Frequently Asked Questions</h1>
            
            <div class="accordion accordion-flush" id="faqAccordion">
                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                            What is SOUND?
                        </button>
                    </h2>
                    <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            SOUND is an entertainment website where users can discover music, videos, artists, albums, genres and languages.
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                            Do I need an account to browse content?
                        </button>
                    </h2>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            No. Visitors can browse available music and videos without creating an account.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                            Why should I create an account?
                        </button>
                    </h2>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Registered users can rate and review music and videos and manage their account information.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                            Can I search for a specific artist?
                        </button>
                    </h2>
                    <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. You can search by artist name and explore their available music, videos and albums.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                            Can I search by year?
                        </button>
                    </h2>
                    <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Music and videos can be filtered according to their release year.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                            Can I edit my review?
                        </button>
                    </h2>
                    <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. You can modify your own reviews from your account.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq7">
                            Can I change my rating?
                        </button>
                    </h2>
                    <div id="faq7" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Registered users can update their ratings.
                        </div>
                    </div>
                </div>

                <div class="accordion-item bg-transparent border-secondary mb-3">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed bg-dark text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq8">
                            Is registration free?
                        </button>
                    </h2>
                    <div id="faq8" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary bg-dark border-top border-secondary">
                            Yes. Creating a SOUND account is free.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>