const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'admin/includes/sidebar.php': `<div class="admin-sidebar shadow-lg">
    <div class="text-center mb-4">
        <h4 class="text-light fw-bold">SOUND Admin</h4>
        <small class="text-secondary"><?= htmlspecialchars($_SESSION['name']) ?></small>
    </div>
    <ul class="list-unstyled">
        <li><a href="index.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF'])=='index.php'?'active':'' ?>"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
        <li><a href="manage_music.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'music')!==false?'active':'' ?>"><i class="fas fa-music me-2"></i> Manage Music</a></li>
        <li><a href="manage_videos.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'video')!==false?'active':'' ?>"><i class="fas fa-video me-2"></i> Manage Videos</a></li>
        <li><a href="manage_artists.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'artist')!==false?'active':'' ?>"><i class="fas fa-users me-2"></i> Manage Artists</a></li>
        <li><a href="manage_albums.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'album')!==false?'active':'' ?>"><i class="fas fa-record-vinyl me-2"></i> Manage Albums</a></li>
        <li><a href="manage_genres.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'genre')!==false?'active':'' ?>"><i class="fas fa-list me-2"></i> Manage Genres</a></li>
        <li><a href="manage_languages.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'language')!==false?'active':'' ?>"><i class="fas fa-globe me-2"></i> Manage Languages</a></li>
        <li><a href="manage_users.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'user')!==false?'active':'' ?>"><i class="fas fa-user-shield me-2"></i> Manage Users</a></li>
        <li><a href="settings.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'setting')!==false?'active':'' ?>"><i class="fas fa-cog me-2"></i> Website Settings</a></li>
        <li><a href="/SOUND/index.php" class="admin-nav-link mt-4 text-info"><i class="fas fa-external-link-alt me-2"></i> View Website</a></li>
        <li><a href="/SOUND/auth/logout.php" class="admin-nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
    </ul>
</div>`,

'admin/includes/header.php': `<?php require_once __DIR__.'/../../config/db.php'; require_once __DIR__.'/../../includes/functions.php'; requireAdmin(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOUND Administration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/SOUND/assets/css/style.css">
    <style>body { background-color: #111; }</style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <div class="admin-main">
`,

'admin/includes/footer.php': `    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>`,

'admin/index.php': `<?php
$pageTitle = "Dashboard";
require_once 'includes/header.php';

$stats = [
    'Music' => $pdo->query("SELECT COUNT(*) FROM music")->fetchColumn(),
    'Videos' => $pdo->query("SELECT COUNT(*) FROM videos")->fetchColumn(),
    'Artists' => $pdo->query("SELECT COUNT(*) FROM artists")->fetchColumn(),
    'Users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
];
?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-1">Dashboard</h2>
    <p class="text-secondary mb-4">Welcome to the SOUND Administration Panel.</p>
    
    <div class="row g-4 mb-4">
        <?php foreach($stats as $label => $count): ?>
        <div class="col-md-3">
            <div class="card bg-dark text-white border-secondary h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="text-secondary mb-2"><?= $label ?></h5>
                    <h2 class="fw-bold mb-0 text-primary"><?= $count ?></h2>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'admin/manage_music.php': `<?php
require_once 'includes/header.php';

if(isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM music WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    $_SESSION['success'] = "Music entry deleted successfully.";
    header("Location: manage_music.php");
    exit;
}

$stmt = $pdo->query("SELECT m.*, a.name as artist_name FROM music m LEFT JOIN artists a ON m.artist_id = a.id ORDER BY m.created_at DESC");
$musicList = $stmt->fetchAll();
?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Manage Music</h2>
            <p class="text-secondary mb-0">Add, edit, view and delete music content.</p>
        </div>
        <a href="add_music.php" class="btn btn-primary fw-bold"><i class="fas fa-plus me-2"></i>Add New Music</a>
    </div>
    
    <?= getFlashSuccess() ?>
    <?= getFlashError() ?>
    
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3">ID</th>
                            <th>Song Name</th>
                            <th>Artist</th>
                            <th>Status</th>
                            <th>New</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($musicList as $m): ?>
                        <tr>
                            <td class="ps-4 text-secondary">#<?= $m['id'] ?></td>
                            <td class="fw-bold"><?= htmlspecialchars($m['song_name']) ?></td>
                            <td><?= htmlspecialchars($m['artist_name']) ?></td>
                            <td><span class="badge <?= $m['status']=='active'?'bg-success':'bg-danger' ?>"><?= ucfirst($m['status']) ?></span></td>
                            <td><?= $m['is_new'] ? '<span class="badge bg-primary">Yes</span>' : '-' ?></td>
                            <td class="text-end pe-4">
                                <a href="../music_details.php?id=<?= $m['id'] ?>" target="_blank" class="btn btn-sm btn-outline-info"><i class="fas fa-eye"></i></a>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this item? This action cannot be undone.');">
                                    <input type="hidden" name="delete_id" value="<?= $m['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$musicList): ?>
                        <tr><td colspan="6" class="text-center py-4 text-secondary">No music entries found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'admin/add_music.php': `<?php
require_once 'includes/header.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $song_name = sanitize($_POST['song_name']);
    $artist_id = (int)$_POST['artist_id'];
    $album_id = $_POST['album_id'] ? (int)$_POST['album_id'] : null;
    $genre_id = (int)$_POST['genre_id'];
    $year_id = (int)$_POST['year_id'];
    $language_id = (int)$_POST['language_id'];
    $is_new = isset($_POST['is_new']) ? 1 : 0;
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("INSERT INTO music (song_name, artist_id, album_id, genre_id, year_id, language_id, music_file, is_new, status) VALUES (?, ?, ?, ?, ?, ?, 'dummy.mp3', ?, ?)");
    if($stmt->execute([$song_name, $artist_id, $album_id, $genre_id, $year_id, $language_id, $is_new, $status])) {
        $_SESSION['success'] = "Music has been added successfully.";
        header("Location: manage_music.php");
        exit;
    }
}
$artists = $pdo->query("SELECT * FROM artists ORDER BY name")->fetchAll();
$albums = $pdo->query("SELECT * FROM albums ORDER BY name")->fetchAll();
$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();
$years = $pdo->query("SELECT * FROM years ORDER BY year DESC")->fetchAll();
$langs = $pdo->query("SELECT * FROM languages ORDER BY name")->fetchAll();
?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">Add New Music</h2>
    <div class="card bg-dark border-secondary">
        <div class="card-body p-4">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Song Name *</label>
                        <input type="text" name="song_name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Artist *</label>
                        <select name="artist_id" class="form-select" required>
                            <?php foreach($artists as $a): ?><option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Genre *</label>
                        <select name="genre_id" class="form-select" required>
                            <?php foreach($genres as $g): ?><option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Language *</label>
                        <select name="language_id" class="form-select" required>
                            <?php foreach($langs as $l): ?><option value="<?= $l['id'] ?>"><?= htmlspecialchars($l['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Year *</label>
                        <select name="year_id" class="form-select" required>
                            <?php foreach($years as $y): ?><option value="<?= $y['id'] ?>"><?= htmlspecialchars($y['year']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Status *</label>
                        <select name="status" class="form-select" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="mb-4 form-check">
                    <input type="checkbox" name="is_new" class="form-check-input" id="is_new" checked>
                    <label class="form-check-label text-light" for="is_new">Mark as New Content</label>
                </div>
                <button type="submit" class="btn btn-primary fw-bold px-4">Save Music</button>
                <a href="manage_music.php" class="btn btn-outline-secondary ms-2">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
