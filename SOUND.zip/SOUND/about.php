<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
$pageTitle = "About SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">About SOUND</h1>
            <p class="lead text-secondary mb-5">
                <?= $settings['About Website'] ?? 'SOUND is an entertainment platform designed to bring music and video discovery together in one convenient digital experience.' ?>
            </p>
            
            <p class="text-light mb-5 text-justify">
                Our platform allows users to explore songs and videos according to artists, albums, genres, years and languages.
            </p>

            <h3 class="fw-bold mb-3 text-primary">Our Purpose</h3>
            <p class="text-light mb-5 text-justify">
                Our purpose is to make entertainment discovery simple, organized and enjoyable.
            </p>

            <h3 class="fw-bold mb-3 text-primary">What We Offer</h3>
            <ul class="list-unstyled text-light mb-5 ms-3">
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Music</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Videos</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Artists</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Albums</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Genres</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Languages</li>
                <li class="mb-2"><i class="fas fa-check text-primary me-2"></i> Ratings & Reviews</li>
            </ul>

            <h3 class="fw-bold mb-3 text-primary">Our Vision</h3>
            <p class="text-light mb-5 text-justify">
                To create a digital space where people can easily discover sounds, artists and entertainment from different cultures and generations.
            </p>

            <h3 class="fw-bold mb-3 text-primary">Our Community</h3>
            <p class="text-light text-justify">
                SOUND gives registered users the opportunity to share their opinions by rating and reviewing available music and videos.
            </p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>