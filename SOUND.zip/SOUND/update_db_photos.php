
<?php
require_once 'C:/xampp/htdocs/SOUND/config/db.php';
$pdo->query("UPDATE music SET cover_image = CONCAT('music/music', id, '.jpg') WHERE id <= 15");
$pdo->query("UPDATE videos SET thumbnail = CONCAT('videos/vid', id, '.jpg') WHERE id <= 15");
$pdo->query("UPDATE artists SET image = CONCAT('artists/art', id, '.jpg') WHERE id <= 10");
$pdo->query("UPDATE albums SET cover = CONCAT('albums/alb', id, '.jpg') WHERE id <= 10");
echo "Database updated successfully to use .jpg photography.";
?>
    