const https = require('https');

function searchPixabay(query) {
    return new Promise((resolve) => {
        const options = {
            hostname: 'pixabay.com',
            path: '/images/search/' + encodeURIComponent(query) + '/',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'Accept': 'text/html'
            }
        };
        https.get(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                const regex = /https:\/\/cdn\.pixabay\.com\/photo\/[^\s"']+/g;
                const matches = data.match(regex) || [];
                resolve([...new Set(matches)]);
            });
        });
    });
}

searchPixabay('pakistan').then(urls => {
    console.log("Found:", urls.length);
    console.log(urls.slice(0, 10));
});
