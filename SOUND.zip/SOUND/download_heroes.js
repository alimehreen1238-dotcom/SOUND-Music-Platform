const https = require('https');
const fs = require('fs');

const download = (prompt, file) => new Promise((resolve) => {
    const seed = Math.floor(Math.random() * 999999);
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1920&height=1080&nologo=true&seed=${seed}`;
    console.log(`Downloading to ${file}...`);
    https.get(url, res => {
        if (res.statusCode === 200) {
            const w = fs.createWriteStream(file);
            res.pipe(w);
            w.on('finish', () => resolve(true));
        } else if (res.headers.location) {
            https.get(res.headers.location, res2 => {
                if (res2.statusCode === 200) {
                    const w = fs.createWriteStream(file);
                    res2.pipe(w);
                    w.on('finish', () => resolve(true));
                } else {
                    resolve(false);
                }
            }).on('error', () => resolve(false));
        } else resolve(false);
    }).on('error', () => resolve(false));
});

async function run() {
    await download("HD wide photographic shot of a massive Pakistani music concert, neon red stage lights, modern youth Gen-Z crowd, highly energetic atmosphere, The Pulse of Pakistan, no text, photorealistic", "C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide1.jpg");
    await new Promise(r => setTimeout(r, 2000));
    await download("HD photorealistic portrait of a modern Gen-Z Pakistani music producer working in a dark recording studio with a mixing console and red LED lighting, Behind the Beats, professional cinematic photography, no text", "C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide2.jpg");
    await new Promise(r => setTimeout(r, 2000));
    await download("HD cinematic portrait of a young modern Pakistani indie singer performing with passion into a studio microphone, stylish Gen-Z fashion, Voice of a Generation, maroon background glow, no text", "C:/xampp/htdocs/SOUND/assets/images/hero/hero_slide3.jpg");
    console.log("Done");
}

run();
