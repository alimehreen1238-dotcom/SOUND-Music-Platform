<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$query = "SELECT a.*, g.name as genre_name, l.name as language_name,
          (SELECT COUNT(*) FROM music WHERE artist_id = a.id) as releases
          FROM artists a
          LEFT JOIN genres g ON a.genre_id = g.id
          LEFT JOIN languages l ON a.language_id = l.id
          WHERE 1=1";
$params = [];

if($search) {
    $query .= " AND a.name LIKE ?";
    $params[] = "%$search%";
}
$query .= " ORDER BY a.name ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$artistList = $stmt->fetchAll();

$pageTitle = "Discover Artists";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Discover Artists</h1>
            <p class="text-secondary">Explore artists from different genres, languages and regions. Discover their music, videos and albums.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="artists.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search artists..." value="<?= htmlspecialchars($search) ?>" style="background:rgba(20,5,10,0.7);border:1px solid rgba(139,0,0,0.4);color:#fff;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($artistList) > 0): ?>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($artistList as $artist): ?>
        <div class="col">
            <div class="card bg-dark text-white h-100 border-secondary text-center p-3 artist-card hover-bg-primary transition-all">
                <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle mx-auto mb-3" style="width:120px;height:120px;object-fit:cover;">
                <h5 class="card-title fw-bold mb-1"><?= htmlspecialchars($artist['name']) ?></h5>
                <p class="text-secondary mb-2 small"><?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?> • <?= htmlspecialchars($artist['language_name'] ?? 'Various') ?></p>
                <p class="text-muted small mb-3"><?= $artist['releases'] ?> releases</p>
                <a href="artist_details.php?id=<?= $artist['id'] ?>" class="btn btn-outline-light btn-sm rounded-pill mt-auto">View Artist</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-users fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No artists found.</h4>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
