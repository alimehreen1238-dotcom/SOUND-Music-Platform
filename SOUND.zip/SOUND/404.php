<?php http_response_code(404); $pageTitle = "Page Not Found"; require_once 'includes/header.php'; ?>
<div class="container text-center section-padding gsap-fade-up">
    <h1 class="display-1 fw-bold text-primary mb-3">404</h1>
    <h3 class="fw-bold text-light mb-3">Page Not Found</h3>
    <p class="text-secondary mb-4">The page you're looking for doesn't exist or may have been moved.</p>
    <a href="/SOUND/index.php" class="btn btn-primary px-4">Back to Home</a>
</div>
<?php require_once 'includes/footer.php'; ?>