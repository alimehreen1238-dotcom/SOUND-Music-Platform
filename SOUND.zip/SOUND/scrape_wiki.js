const https = require('https');
const fs = require('fs');
const path = require('path');

const fetchWikimediaImages = (query, count) => {
    return new Promise((resolve, reject) => {
        const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query + ' filetype:bitmap')}&gsrnamespace=6&gsrlimit=${count}&prop=imageinfo&iiprop=url&format=json`;
        https.get(url, { headers: { 'User-Agent': 'SOUND-Project/1.0 (test@test.com)' } }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    const pages = parsed.query ? parsed.query.pages : {};
                    const urls = Object.values(pages)
                        .map(p => p.imageinfo && p.imageinfo[0] ? p.imageinfo[0].url : null)
                        .filter(u => u && !u.endsWith('.svg') && !u.endsWith('.gif'));
                    resolve(urls);
                } catch (e) {
                    resolve([]);
                }
            });
        }).on('error', reject);
    });
};

(async () => {
    const urls = await fetchWikimediaImages('pakistan music', 10);
    console.log("Found URLs:", urls.length);
    console.log(urls.slice(0, 5));
})();
