const https = require('https');
const fs = require('fs');
const path = require('path');

const baseImgDir = 'C:/xampp/htdocs/SOUND/assets/images';

const pages = [
    'Music_of_Pakistan',
    'Qawwali',
    'Coke_Studio_(Pakistani_TV_program)',
    'Pakistani_pop_music',
    'Sufi_rock',
    'Atif_Aslam',
    'Nusrat_Fateh_Ali_Khan',
    'Abida_Parveen',
    'Ali_Zafar',
    'Nazia_Hassan',
    'Junoon_(band)',
    'Vital_Signs_(band)',
    'Culture_of_Pakistan',
    'Tabla',
    'Sitar',
    'Lahore',
    'Karachi'
];

const req = (url) => new Promise(resolve => {
    https.get(url, { headers: { 'User-Agent': 'SOUND-Project/1.0 (test@test.com)' } }, res => {
        let data = '';
        res.on('data', c => data+=c);
        res.on('end', () => resolve(data));
    }).on('error', () => resolve('{}'));
});

async function getWikiImages() {
    let allFileTitles = [];
    console.log("Fetching image lists from Wikipedia...");
    for (let p of pages) {
        let url = `https://en.wikipedia.org/w/api.php?action=query&prop=images&titles=${encodeURIComponent(p)}&imlimit=50&format=json`;
        let res = await req(url);
        try {
            let j = JSON.parse(res);
            let pgs = Object.values(j.query.pages);
            if (pgs[0] && pgs[0].images) {
                let titles = pgs[0].images.map(img => img.title).filter(t => t.toLowerCase().endsWith('.jpg') || t.toLowerCase().endsWith('.jpeg'));
                allFileTitles.push(...titles);
            }
        } catch(e){}
    }
    allFileTitles = [...new Set(allFileTitles)];
    console.log(`Found ${allFileTitles.length} unique image files.`);
    
    // Resolve URLs
    let imgUrls = [];
    console.log("Resolving direct URLs...");
    for (let i = 0; i < allFileTitles.length; i += 20) {
        let chunk = allFileTitles.slice(i, i+20).map(encodeURIComponent).join('|');
        let url = `https://en.wikipedia.org/w/api.php?action=query&titles=${chunk}&prop=imageinfo&iiprop=url&format=json`;
        let res = await req(url);
        try {
            let j = JSON.parse(res);
            let pgs = Object.values(j.query.pages);
            pgs.forEach(p => {
                if (p.imageinfo && p.imageinfo[0]) imgUrls.push(p.imageinfo[0].url);
            });
        } catch(e){}
    }
    
    imgUrls = [...new Set(imgUrls)];
    console.log(`Resolved ${imgUrls.length} direct URLs.`);
    return imgUrls;
}

const downloadFile = (url, filepath) => {
    return new Promise((resolve) => {
        https.get(url, { headers: { 'User-Agent': 'SOUND-Project/1.0' } }, (res) => {
            if (res.statusCode === 200) {
                const file = fs.createWriteStream(filepath);
                res.pipe(file);
                file.on('finish', () => { file.close(); resolve(true); });
            } else if (res.statusCode >= 300 && res.headers.location) {
                https.get(res.headers.location, (res2) => {
                    const file = fs.createWriteStream(filepath);
                    res2.pipe(file);
                    file.on('finish', () => { file.close(); resolve(true); });
                }).on('error', () => resolve(false));
            } else {
                resolve(false);
            }
        }).on('error', () => resolve(false));
    });
};

async function processAll() {
    const urls = await getWikiImages();
    if (urls.length < 10) return console.log("Not enough images!");
    
    // Shuffle urls
    for (let i = urls.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [urls[i], urls[j]] = [urls[j], urls[i]];
    }

    let uIdx = 0;
    const nextUrl = () => urls[uIdx++ % urls.length];

    const tasks = [
        { file: 'hero/hero_bg.jpg' },
        ...Array.from({length: 15}, (_, i) => ({ file: `music/music${i+1}.jpg` })),
        ...Array.from({length: 15}, (_, i) => ({ file: `videos/vid${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `artists/art${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `albums/alb${i+1}.jpg` }))
    ];
    
    console.log(`Downloading ${tasks.length} real photos...`);
    for (let t of tasks) {
        let success = await downloadFile(nextUrl(), path.join(baseImgDir, t.file));
        if(!success) console.log("Failed downloading to " + t.file);
    }
    console.log("All Wikipedia real photography downloads complete.");
}

processAll();
