<?php
$pageTitle = "Home";
require_once 'includes/header.php';

// Fetch Latest Music
$stmt = $pdo->query("SELECT m.*, a.name as artist_name, al.name as album_name 
                     FROM music m 
                     JOIN artists a ON m.artist_id = a.id 
                     LEFT JOIN albums al ON m.album_id = al.id 
                     WHERE m.status = 'active' 
                     ORDER BY m.created_at DESC LIMIT 15");
$latestMusic = $stmt->fetchAll();

// Fetch Latest Videos
$stmt = $pdo->query("SELECT v.*, a.name as artist_name 
                     FROM videos v 
                     JOIN artists a ON v.artist_id = a.id 
                     WHERE v.status = 'active' 
                     ORDER BY v.created_at DESC LIMIT 15");
$latestVideos = $stmt->fetchAll();

// Fetch Featured Artists
$stmt = $pdo->query("SELECT * FROM artists ORDER BY created_at DESC LIMIT 10");
$featuredArtists = $stmt->fetchAll();

// Fetch Genres
$stmt = $pdo->query("SELECT * FROM genres LIMIT 12");
$genres = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero-section p-0 m-0" style="background: transparent;">
    <div id="heroCarousel" class="carousel slide carousel-fade w-100 h-100" data-bs-ride="carousel" data-bs-interval="7000">
        <!-- Indicators -->
        <div class="carousel-indicators mb-5" style="z-index: 10;">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
        </div>

        <!-- Slides -->
        <div class="carousel-inner w-100 h-100">
            <!-- Slide 1 -->
            <div class="carousel-item active w-100 h-100" style="background: url('/SOUND/assets/images/hero/hero_slide1.jpg') center/cover no-repeat;">
                <div class="hero-overlay" style="background: linear-gradient(to bottom, rgba(5,5,5,0.15) 0%, rgba(58,7,20,0.45) 60%, rgba(5,5,5,0.92) 100%);"></div>
                <div class="container hero-content d-flex align-items-center h-100">
                    <div class="text-center text-md-start w-100 mt-5">
                        <h1 class="display-1 fw-bold mb-4 text-white gsap-fade-up">THE PULSE OF PAKISTAN</h1>
                        <p class="lead text-light mb-5 max-w-lg gsap-fade-up" style="max-width: 600px;">Feel the energy of the crowd and discover the biggest trending performances of the year.</p>
                        <div class="d-flex gap-3 justify-content-center justify-content-md-start gsap-fade-up">
                            <a href="music.php" class="btn btn-primary btn-lg px-4 py-2 rounded-pill">Explore Music</a>
                            <a href="videos.php" class="btn btn-outline-light btn-lg px-4 py-2 rounded-pill">Watch Videos</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Slide 2 -->
            <div class="carousel-item w-100 h-100" style="background: url('/SOUND/assets/images/hero/hero_slide2.jpg') center/cover no-repeat;">
                <div class="hero-overlay" style="background: linear-gradient(to bottom, rgba(5,5,5,0.15) 0%, rgba(58,7,20,0.45) 60%, rgba(5,5,5,0.92) 100%);"></div>
                <div class="container hero-content d-flex align-items-center h-100">
                    <div class="text-center text-md-start w-100 mt-5">
                        <h1 class="display-1 fw-bold mb-4 text-white">BEHIND THE BEATS</h1>
                        <p class="lead text-light mb-5 max-w-lg" style="max-width: 600px;">Step into the studio and explore how modern Pakistani masterpieces are crafted.</p>
                        <div class="d-flex gap-3 justify-content-center justify-content-md-start">
                            <a href="albums.php" class="btn btn-outline-light btn-lg px-4 py-2 rounded-pill">View Albums</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item w-100 h-100" style="background: url('/SOUND/assets/images/hero/hero_slide3.jpg') center/cover no-repeat;">
                <div class="hero-overlay" style="background: linear-gradient(to bottom, rgba(5,5,5,0.15) 0%, rgba(58,7,20,0.45) 60%, rgba(5,5,5,0.92) 100%);"></div>
                <div class="container hero-content d-flex align-items-center h-100">
                    <div class="text-center text-md-start w-100 mt-5">
                        <h1 class="display-1 fw-bold mb-4 text-white">VOICE OF A GENERATION</h1>
                        <p class="lead text-light mb-5 max-w-lg" style="max-width: 600px;">From Sufi legends to contemporary indie stars, connect with the artists shaping the soundscape.</p>
                        <div class="d-flex gap-3 justify-content-center justify-content-md-start">
                            <a href="artists.php" class="btn btn-primary btn-lg px-4 py-2 rounded-pill">Meet the Artists</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev" style="width: 5%; z-index: 10;">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next" style="width: 5%; z-index: 10;">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        <div id="three-canvas"></div>
    </div>
</section>

<!-- Welcome Section -->

<section class="section-padding bg-black">
    <div class="container text-center gsap-fade-up">
        <h2 class="fw-bold mb-4"><?= $settings['Welcome Heading'] ?? 'Welcome to SOUND' ?></h2>
        <p class="text-secondary mx-auto" style="max-width: 800px; font-size: 1.1rem;">
            <?= $settings['Welcome Description'] ?? 'Welcome to SOUND, your destination for discovering music and entertainment.' ?>
        </p>
        <p class="text-secondary mx-auto mb-5" style="max-width: 800px; font-size: 1.1rem;">
            Whether you are looking for a new song, exploring an artist, discovering an album or watching a video, SOUND makes it simple to find something that matches your mood.
        </p>
        
        <!-- SOUND AI Chat Box -->
        <div class="row justify-content-center mt-4">
            <div class="col-12 col-lg-10">
                <div class="ai-chat-container text-start rounded-4 p-0 overflow-hidden" style="background: rgba(10,10,10,0.8); border: 1px solid rgba(139,0,0,0.3); box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                    <!-- Header -->
                    <div class="ai-header p-3 d-flex justify-content-between align-items-center" style="background: linear-gradient(to right, #3A0714, #050505); border-bottom: 1px solid rgba(139,0,0,0.2);">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-robot text-white fs-4 me-3"></i>
                            <div>
                                <h5 class="mb-0 text-white fw-bold">SOUND AI Assistant</h5>
                                <small class="text-light opacity-75">Ask anything about our music, artists, or videos...</small>
                            </div>
                        </div>
                        <button type="button" id="ai-clear-btn" class="btn btn-sm btn-outline-light rounded-pill px-3">Clear Chat</button>
                    </div>
                    
                    <!-- Chat History Area -->
                    <div id="ai-chat-history" class="p-4" style="height: 350px; overflow-y: auto; background: #0b0b0b;">
                        <!-- Initial Message -->
                        <div class="d-flex mb-4">
                            <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; min-width: 40px;">
                                <i class="fas fa-robot text-white"></i>
                            </div>
                            <div class="bg-dark text-light rounded-3 p-3 shadow-sm border border-secondary" style="border-color: rgba(255,255,255,0.05) !important;">
                                Hi there! I'm your SOUND AI assistant. You can ask me to find Punjabi songs, search for specific artists, look for 2026 music, or explore videos. What would you like to listen to today?
                            </div>
                        </div>
                    </div>
                    
                    <!-- Input Area -->
                    <div class="p-3 bg-black border-top" style="border-color: rgba(139,0,0,0.2) !important;">
                        <form id="ai-chat-form" class="d-flex position-relative">
                            <input type="text" id="ai-chat-input" class="form-control rounded-pill bg-white text-dark py-3 px-4 shadow-none fw-bold" placeholder="Type your question here..." required style="border: 2px solid transparent; outline: none !important; box-shadow: none !important;">
                            <button type="submit" class="btn btn-primary rounded-circle position-absolute d-flex justify-content-center align-items-center" style="right: 8px; top: 8px; width: 40px; height: 40px; padding: 0; transition: transform 0.2s;">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Latest Music -->
<section class="section-padding">
    <div class="container position-relative">
        <div class="d-flex justify-content-between align-items-end mb-4 gsap-fade-up">
            <div>
                <h2 class="fw-bold mb-2">Latest Music</h2>
                <p class="text-secondary mb-0">Discover the newest additions to our music collection.</p>
            </div>
            <div>
                <a href="music.php" class="btn btn-outline-light">View All</a>
            </div>
        </div>
        
        <div class="position-relative">
            <button class="btn text-white fs-1 position-absolute start-0 translate-middle-y scroll-btn-hover" style="top: 50%; z-index: 5; background: none; border: none; padding: 0 10px; transition: all 0.2s; text-shadow: 0 2px 10px rgba(0,0,0,0.8);" onclick="document.getElementById('musicScroll').scrollBy({left: -300, behavior: 'smooth'})">‹</button>
            <div id="musicScroll" class="horizontal-scroll gsap-stagger-cards px-4" style="scroll-behavior: smooth;">
                <?php foreach($latestMusic as $music): ?>
                <div class="col-card">
                    <div class="music-card">
                        <?php if($music['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                        <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light d-block">
                            <div class="card-img-wrapper">
                                <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" alt="<?= htmlspecialchars($music['song_name']) ?>">
                                <div class="play-overlay">
                                    <i class="fas fa-play-circle play-btn play-music-btn" 
                                       data-src="/SOUND/assets/music/<?= $music['music_file'] ?>" 
                                       data-title="<?= htmlspecialchars($music['song_name']) ?>" 
                                       data-artist="<?= htmlspecialchars($music['artist_name']) ?>"
                                       data-cover="/SOUND/assets/images/<?= $music['cover_image'] ?>"></i>
                                </div>
                            </div>
                            <div class="p-3">
                                <h5 class="mb-1 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h5>
                                <p class="text-secondary mb-0 text-truncate"><?= htmlspecialchars($music['artist_name']) ?></p>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button class="btn text-white fs-1 position-absolute end-0 translate-middle-y scroll-btn-hover" style="top: 50%; z-index: 5; background: none; border: none; padding: 0 10px; transition: all 0.2s; text-shadow: 0 2px 10px rgba(0,0,0,0.8);" onclick="document.getElementById('musicScroll').scrollBy({left: 300, behavior: 'smooth'})">›</button>
        </div>
    </div>
</section>

<!-- Latest Videos -->
<section class="section-padding bg-black">
    <div class="container position-relative">
        <div class="d-flex justify-content-between align-items-end mb-4 gsap-fade-up">
            <div>
                <h2 class="fw-bold mb-2">Latest Videos</h2>
                <p class="text-secondary mb-0">Watch the latest additions to the SOUND video collection.</p>
            </div>
            <div>
                <a href="videos.php" class="btn btn-outline-light">View All</a>
            </div>
        </div>
        
        <div class="position-relative">
            <button class="btn text-white fs-1 position-absolute start-0 translate-middle-y scroll-btn-hover" style="top: 50%; z-index: 5; background: none; border: none; padding: 0 10px; transition: all 0.2s; text-shadow: 0 2px 10px rgba(0,0,0,0.8);" onclick="document.getElementById('videoScroll').scrollBy({left: -320, behavior: 'smooth'})">‹</button>
            <div id="videoScroll" class="horizontal-scroll gsap-stagger-cards px-4" style="scroll-behavior: smooth;">
                <?php foreach($latestVideos as $video): ?>
                <div class="col-card" style="min-width: 300px;">
                    <div class="video-card">
                        <?php if($video['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                        <a href="video_details.php?id=<?= $video['id'] ?>" class="text-decoration-none text-light d-block">
                            <div class="card-img-wrapper" style="height: 170px;">
                                <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" alt="<?= htmlspecialchars($video['video_name']) ?>">
                                <div class="play-overlay">
                                    <i class="fas fa-play play-btn"></i>
                                </div>
                            </div>
                            <div class="p-3">
                                <h5 class="mb-1 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h5>
                                <p class="text-secondary mb-0 text-truncate"><?= htmlspecialchars($video['artist_name']) ?></p>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button class="btn text-white fs-1 position-absolute end-0 translate-middle-y scroll-btn-hover" style="top: 50%; z-index: 5; background: none; border: none; padding: 0 10px; transition: all 0.2s; text-shadow: 0 2px 10px rgba(0,0,0,0.8);" onclick="document.getElementById('videoScroll').scrollBy({left: 320, behavior: 'smooth'})">›</button>
        </div>
    </div>
</section>

<!-- Featured Artists -->
<section class="section-padding">
    <div class="container">
        <div class="text-center mb-5 gsap-fade-up">
            <h2 class="fw-bold mb-2">Featured Artists</h2>
            <p class="text-secondary">Meet the voices and creators behind the sounds you love.</p>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
            <?php foreach($featuredArtists as $artist): ?>
            <div class="col">
                <a href="artist_details.php?id=<?= $artist['id'] ?>" class="text-decoration-none text-center d-block artist-card-link">
                    <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle mb-3 border border-secondary" style="width:150px;height:150px;object-fit:cover;">
                    <h5 class="text-light mb-0"><?= htmlspecialchars($artist['name']) ?></h5>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Genres -->
<section class="section-padding bg-black">
    <div class="container">
        <div class="text-center mb-5 gsap-fade-up">
            <h2 class="fw-bold mb-2">Explore by Genre</h2>
            <p class="text-secondary">From timeless classics to modern sounds, explore entertainment across different genres.</p>
        </div>
        <div class="row row-cols-2 row-cols-md-4 g-3 gsap-stagger-cards">
            <?php foreach($genres as $genre): ?>
            <div class="col">
                <a href="genre_details.php?id=<?= $genre['id'] ?>" class="btn btn-outline-light w-100 py-3 fw-bold fs-5 rounded text-uppercase">
                    <?= htmlspecialchars($genre['name']) ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Pakistan Feature -->
<section class="section-padding text-center position-relative" style="background: linear-gradient(rgba(5,5,5,0.6), rgba(58,7,20,0.55), rgba(5,5,5,0.85)), url('/SOUND/assets/images/hero/pakistan_bg.jpg') center/cover no-repeat fixed;">
    <div class="container gsap-fade-up">
        <h2 class="display-4 fw-bold mb-3 text-primary">The Sound of Pakistan</h2>
        <p class="lead text-light mb-4 mx-auto" style="max-width: 700px;">
            From timeless melodies to modern rhythms, Pakistani music continues to evolve while carrying stories, emotions and traditions across generations.
        </p>
        <a href="explore.php?region=pakistan" class="btn btn-primary btn-lg">Explore Pakistani Sounds</a>
    </div>
</section>

<!-- CTA -->
<section class="section-padding bg-black text-center">
    <div class="container gsap-fade-up">
        <h2 class="fw-bold mb-3">Find Your Next Favorite Sound</h2>
        <p class="text-secondary mb-4 mx-auto" style="max-width:600px;">
            Your next favorite song, artist or video could be just one click away. Create your SOUND account and become part of the community.
        </p>
        <div class="d-flex justify-content-center gap-3">
            <a href="explore.php" class="btn btn-primary btn-lg px-4">Start Exploring</a>
            <a href="auth/register.php" class="btn btn-outline-light btn-lg px-4">Create Account</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>