<?php http_response_code(500); $pageTitle = "Server Error"; require_once 'includes/header.php'; ?>
<div class="container text-center section-padding gsap-fade-up">
    <h1 class="display-1 fw-bold text-warning mb-3">500</h1>
    <h3 class="fw-bold text-light mb-3">Something Went Wrong</h3>
    <p class="text-secondary mb-4">We're sorry, but something unexpected happened. Please try again later.</p>
    <a href="/SOUND/index.php" class="btn btn-primary px-4">Back to Home</a>
</div>
<?php require_once 'includes/footer.php'; ?>