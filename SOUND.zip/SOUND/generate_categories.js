const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'genres.php': `<?php
require_once 'config/db.php';
$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();
$pageTitle = "Explore Genres";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Explore Genres</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Discover music and videos organized by genre. Explore familiar favorites or find a new sound.</p>
    </div>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($genres as $genre): ?>
        <div class="col">
            <a href="genre_details.php?id=<?= $genre['id'] ?>" class="btn btn-outline-light w-100 py-4 fw-bold fs-5 rounded d-flex flex-column align-items-center justify-content-center h-100 shadow hover-bg-primary transition-all">
                <i class="fas fa-music mb-2 fs-3 text-primary"></i>
                <span class="text-uppercase"><?= htmlspecialchars($genre['name']) ?></span>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'genre_details.php': `<?php
require_once 'config/db.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM genres WHERE id = ?");
$stmt->execute([$id]);
$genre = $stmt->fetch();
if(!$genre) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT m.*, a.name as artist_name FROM music m JOIN artists a ON m.artist_id=a.id WHERE m.genre_id=? AND m.status='active' ORDER BY m.created_at DESC LIMIT 8");
$stmt->execute([$id]);
$musicList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT v.*, a.name as artist_name FROM videos v JOIN artists a ON v.artist_id=a.id WHERE v.genre_id=? AND v.status='active' ORDER BY v.created_at DESC LIMIT 4");
$stmt->execute([$id]);
$videoList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($genre['name']) . " Music";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="mb-5 border-bottom border-secondary pb-4">
        <h1 class="display-4 fw-bold text-primary mb-3"><?= htmlspecialchars($genre['name']) ?> Music</h1>
        <p class="lead text-light">Explore music and videos from the <?= htmlspecialchars($genre['name']) ?> genre. Discover popular artists, albums and songs available on SOUND.</p>
    </div>

    <h4 class="fw-bold mb-4">Latest <?= htmlspecialchars($genre['name']) ?> Music</h4>
    <?php if($musicList): ?>
        <div class="row row-cols-2 row-cols-md-4 g-4 mb-5">
            <?php foreach($musicList as $music): ?>
            <div class="col">
                <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light">
                    <div class="card bg-dark border-secondary h-100">
                        <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                        <div class="card-body p-2">
                            <h6 class="mb-0 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                            <small class="text-secondary text-truncate d-block"><?= htmlspecialchars($music['artist_name']) ?></small>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-secondary mb-5">No music is currently available for this genre.</p>
    <?php endif; ?>

    <h4 class="fw-bold mb-4"><?= htmlspecialchars($genre['name']) ?> Videos</h4>
    <?php if($videoList): ?>
        <div class="row row-cols-1 row-cols-md-4 g-4 mb-5">
            <?php foreach($videoList as $video): ?>
            <div class="col">
                <a href="video_details.php?id=<?= $video['id'] ?>" class="text-decoration-none text-light">
                    <div class="card bg-dark border-secondary h-100">
                        <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" class="card-img-top" style="height:120px;object-fit:cover;">
                        <div class="card-body p-2">
                            <h6 class="mb-0 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h6>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-secondary">No videos are currently available for this genre.</p>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'languages.php': `<?php
require_once 'config/db.php';
$langs = $pdo->query("SELECT * FROM languages ORDER BY name")->fetchAll();
$pageTitle = "Explore by Language";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Explore by Language</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Discover music and videos from different languages and cultures. Select a language to explore its available music, videos, artists and albums.</p>
    </div>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($langs as $lang): ?>
        <div class="col">
            <a href="language_details.php?id=<?= $lang['id'] ?>" class="btn btn-outline-light w-100 py-4 fw-bold fs-5 rounded h-100 shadow hover-bg-primary transition-all">
                <span class="text-uppercase"><?= htmlspecialchars($lang['name']) ?></span>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'language_details.php': `<?php
require_once 'config/db.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM languages WHERE id = ?");
$stmt->execute([$id]);
$lang = $stmt->fetch();
if(!$lang) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT m.*, a.name as artist_name FROM music m JOIN artists a ON m.artist_id=a.id WHERE m.language_id=? AND m.status='active' ORDER BY m.created_at DESC LIMIT 8");
$stmt->execute([$id]);
$musicList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($lang['name']) . " Content";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="mb-5 border-bottom border-secondary pb-4">
        <h1 class="display-4 fw-bold text-primary mb-3"><?= htmlspecialchars($lang['name']) ?></h1>
        <p class="lead text-light">Explore music and videos available in <?= htmlspecialchars($lang['name']) ?>. Discover artists, albums and entertainment from the <?= htmlspecialchars($lang['name']) ?> music collection.</p>
    </div>

    <h4 class="fw-bold mb-4">Latest <?= htmlspecialchars($lang['name']) ?> Music</h4>
    <?php if($musicList): ?>
        <div class="row row-cols-2 row-cols-md-4 g-4 mb-5">
            <?php foreach($musicList as $music): ?>
            <div class="col">
                <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light">
                    <div class="card bg-dark border-secondary h-100">
                        <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                        <div class="card-body p-2">
                            <h6 class="mb-0 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                            <small class="text-secondary text-truncate d-block"><?= htmlspecialchars($music['artist_name']) ?></small>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-secondary mb-5">No content is currently available for this language.</p>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'search.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$q = isset($_GET['q']) ? sanitize($_GET['q']) : '';

$mRes = []; $vRes = []; $aRes = []; $alRes = [];
if($q) {
    $mStmt = $pdo->prepare("SELECT * FROM music WHERE song_name LIKE ? AND status='active' LIMIT 10");
    $mStmt->execute(["%$q%"]); $mRes = $mStmt->fetchAll();
    
    $vStmt = $pdo->prepare("SELECT * FROM videos WHERE video_name LIKE ? AND status='active' LIMIT 10");
    $vStmt->execute(["%$q%"]); $vRes = $vStmt->fetchAll();
    
    $aStmt = $pdo->prepare("SELECT * FROM artists WHERE name LIKE ? LIMIT 10");
    $aStmt->execute(["%$q%"]); $aRes = $aStmt->fetchAll();
    
    $alStmt = $pdo->prepare("SELECT * FROM albums WHERE name LIKE ? LIMIT 10");
    $alStmt->execute(["%$q%"]); $alRes = $alStmt->fetchAll();
}

$pageTitle = "Search SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Search SOUND</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Search across music, videos, artists and albums to quickly find what you're looking for.</p>
        <form method="GET" action="search.php" class="d-flex justify-content-center mt-4 mx-auto" style="max-width: 600px;">
            <div class="input-group input-group-lg">
                <input type="text" name="q" class="form-control bg-dark text-light border-secondary" placeholder="Search music, videos, artists, albums..." value="<?= htmlspecialchars($q) ?>">
                <button type="submit" class="btn btn-primary px-4"><i class="fas fa-search"></i></button>
            </div>
        </form>
    </div>

    <?php if($q): ?>
        <h4 class="fw-bold mb-4 border-bottom border-secondary pb-2">Results for: "<?= htmlspecialchars($q) ?>"</h4>
        
        <?php if(!$mRes && !$vRes && !$aRes && !$alRes): ?>
            <div class="text-center py-5">
                <i class="fas fa-search fs-1 text-muted mb-3"></i>
                <h4 class="text-light">No results found.</h4>
                <p class="text-secondary">We couldn't find anything matching your search. Try a different keyword.</p>
            </div>
        <?php else: ?>
            
            <?php if($mRes): ?>
                <h5 class="fw-bold mb-3 text-primary">Music</h5>
                <div class="row row-cols-2 row-cols-md-5 g-3 mb-5">
                    <?php foreach($mRes as $r): ?>
                    <div class="col"><a href="music_details.php?id=<?= $r['id'] ?>" class="text-decoration-none text-light"><div class="card bg-dark border-secondary p-2"><h6 class="mb-0 text-truncate"><?= htmlspecialchars($r['song_name']) ?></h6></div></a></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if($vRes): ?>
                <h5 class="fw-bold mb-3 text-primary">Videos</h5>
                <div class="row row-cols-2 row-cols-md-5 g-3 mb-5">
                    <?php foreach($vRes as $r): ?>
                    <div class="col"><a href="video_details.php?id=<?= $r['id'] ?>" class="text-decoration-none text-light"><div class="card bg-dark border-secondary p-2"><h6 class="mb-0 text-truncate"><?= htmlspecialchars($r['video_name']) ?></h6></div></a></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'explore.php': `<?php
require_once 'config/db.php';
$pageTitle = "Explore SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up text-center">
    <h1 class="fw-bold mb-3 display-4">Explore SOUND</h1>
    <p class="text-secondary lead mb-5 max-w-lg mx-auto">Go beyond your usual favorites. Discover new music, videos, artists, albums and genres.</p>
    
    <div class="row row-cols-1 row-cols-md-3 g-4 mb-5">
        <div class="col">
            <a href="music.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-music fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Latest Music</h4>
                <p class="text-secondary mb-0">Discover the newest tracks.</p>
            </a>
        </div>
        <div class="col">
            <a href="videos.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-video fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Latest Videos</h4>
                <p class="text-secondary mb-0">Watch new visual experiences.</p>
            </a>
        </div>
        <div class="col">
            <a href="artists.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-users fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Featured Artists</h4>
                <p class="text-secondary mb-0">Explore talented creators.</p>
            </a>
        </div>
        <div class="col">
            <a href="albums.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-record-vinyl fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Popular Albums</h4>
                <p class="text-secondary mb-0">Browse album collections.</p>
            </a>
        </div>
        <div class="col">
            <a href="genres.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-compact-disc fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Popular Genres</h4>
                <p class="text-secondary mb-0">Find your perfect vibe.</p>
            </a>
        </div>
        <div class="col">
            <a href="languages.php" class="card bg-dark border-secondary text-light text-decoration-none h-100 hover-bg-primary transition-all p-4">
                <i class="fas fa-globe fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold">Regional Sounds</h4>
                <p class="text-secondary mb-0">Listen across cultures.</p>
            </a>
        </div>
    </div>
    
    <div class="bg-black p-5 rounded border border-secondary shadow-lg">
        <h3 class="fw-bold mb-3">There's always something new to discover.</h3>
        <a href="music.php" class="btn btn-primary btn-lg mt-3">Explore All Music</a>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
