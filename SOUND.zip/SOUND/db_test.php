<?php
/**
 * SOUND DB COMPREHENSIVE TEST SCRIPT
 * Tests all database functionality end-to-end
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$results = [];
$fixes = [];

// =============================================
// 1. DATABASE CONNECTION
// =============================================
try {
    require_once 'config/db.php';
    $results['DB Connection'] = ['pass' => true, 'detail' => "Connected to sound_db on localhost"];
} catch(Exception $e) {
    $results['DB Connection'] = ['pass' => false, 'detail' => $e->getMessage()];
    die(json_encode($results));
}

// =============================================
// 2. TABLE STRUCTURE CHECK
// =============================================
$expectedTables = ['users','music','videos','artists','albums','genres','languages','years',
                   'reviews','ratings','favorites','website_settings'];
$stmt = $pdo->query("SHOW TABLES");
$actualTables = array_column($stmt->fetchAll(PDO::FETCH_NUM), 0);
$missingTables = array_diff($expectedTables, $actualTables);
$results['Tables Present'] = [
    'pass' => empty($missingTables),
    'detail' => empty($missingTables)
        ? "All expected tables found: " . implode(', ', $actualTables)
        : "MISSING: " . implode(', ', $missingTables) . " | Found: " . implode(', ', $actualTables)
];

// Show column info for users table
$stmt = $pdo->query("DESCRIBE users");
$userCols = array_column($stmt->fetchAll(), 'Field');
$results['Users Table Columns'] = ['pass' => true, 'detail' => implode(', ', $userCols)];

// =============================================
// 3. DATA COUNTS (View)
// =============================================
$countTables = ['artists','albums','music','videos','genres','languages','years','users','reviews','ratings','favorites'];
foreach($countTables as $tbl) {
    if(in_array($tbl, $actualTables)) {
        $count = $pdo->query("SELECT COUNT(*) FROM `$tbl`")->fetchColumn();
        $results["Count: $tbl"] = ['pass' => true, 'detail' => "$count records"];
    }
}

// =============================================
// 4. SIGNUP TEST — INSERT then DELETE
// =============================================
$testEmail = 'dbtest_' . time() . '@sound-test.local';
$testUserId = 'test_' . time();
$testPass = password_hash('TestPass123!', PASSWORD_DEFAULT);
try {
    $stmt = $pdo->prepare("INSERT INTO users (name, user_id, address, phone, email, password) VALUES (?,?,?,?,?,?)");
    $stmt->execute(['DB Test User', $testUserId, 'Test Address 123', '03001234567', $testEmail, $testPass]);
    $newId = $pdo->lastInsertId();
    $results['Signup INSERT'] = ['pass' => true, 'detail' => "User inserted with id=$newId"];

    // Verify it was stored
    $stmt = $pdo->prepare("SELECT id,name,email,role,status FROM users WHERE id=?");
    $stmt->execute([$newId]);
    $row = $stmt->fetch();
    $results['Signup Verify'] = [
        'pass' => ($row && $row['email'] === $testEmail),
        'detail' => $row ? "role={$row['role']}, status={$row['status']}" : "Row not found"
    ];

    // 5. LOGIN TEST
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=?");
    $stmt->execute([$testEmail]);
    $user = $stmt->fetch();
    $loginOk = $user && password_verify('TestPass123!', $user['password']);
    $results['Login Verify'] = [
        'pass' => $loginOk,
        'detail' => $loginOk ? "password_verify passed, role={$user['role']}" : "password_verify FAILED"
    ];

    // Session fields present
    $results['Login Session Fields'] = [
        'pass' => isset($user['id'], $user['role'], $user['name'], $user['status']),
        'detail' => "Fields: " . implode(', ', array_keys($user))
    ];

    // Check default role/status
    if($user['role'] !== 'user' || $user['status'] !== 'active') {
        $fixes[] = "Default role/status mismatch: role={$user['role']} status={$user['status']}";
    }

    // Cleanup test user
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$newId]);
    $results['Signup Cleanup'] = ['pass' => true, 'detail' => "Test user removed"];

} catch(PDOException $e) {
    $results['Signup INSERT'] = ['pass' => false, 'detail' => $e->getMessage()];
    // Try to fix: check if required columns exist
    $fixes[] = "Signup failed: " . $e->getMessage();
}

// =============================================
// 6. MUSIC CRUD
// =============================================
if(in_array('music', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE music");
    $musicCols = array_column($stmt->fetchAll(), 'Field');
    $results['Music Columns'] = ['pass' => true, 'detail' => implode(', ', $musicCols)];

    // Check required columns
    $reqMusic = ['id','song_name','artist_id','album_id','genre_id','language_id','year_id','cover_image','status'];
    $missing = array_diff($reqMusic, $musicCols);
    $results['Music Required Cols'] = [
        'pass' => empty($missing),
        'detail' => empty($missing) ? "All required columns present" : "MISSING: " . implode(', ', $missing)
    ];

    // View music with artist join
    try {
        $stmt = $pdo->query("SELECT m.id, m.song_name, a.name as artist FROM music m JOIN artists a ON m.artist_id=a.id LIMIT 3");
        $rows = $stmt->fetchAll();
        $results['Music View (JOIN)'] = ['pass' => true, 'detail' => count($rows) . " rows: " . implode(', ', array_column($rows,'song_name'))];
    } catch(PDOException $e) {
        $results['Music View (JOIN)'] = ['pass' => false, 'detail' => $e->getMessage()];
    }
}

// =============================================
// 7. VIDEOS CRUD
// =============================================
if(in_array('videos', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE videos");
    $videoCols = array_column($stmt->fetchAll(), 'Field');
    $results['Video Columns'] = ['pass' => true, 'detail' => implode(', ', $videoCols)];
    $reqVideo = ['id','video_name','artist_id','album_id','thumbnail','status'];
    $missing = array_diff($reqVideo, $videoCols);
    $results['Video Required Cols'] = ['pass' => empty($missing), 'detail' => empty($missing) ? "All present" : "MISSING: ".implode(',',$missing)];
}

// =============================================
// 8. ARTISTS
// =============================================
if(in_array('artists', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE artists");
    $cols = array_column($stmt->fetchAll(), 'Field');
    $req = ['id','name','genre_id','language_id','image'];
    $missing = array_diff($req, $cols);
    $results['Artists Required Cols'] = ['pass' => empty($missing), 'detail' => empty($missing) ? "All present: ".implode(',',$cols) : "MISSING:".implode(',',$missing)];
}

// =============================================
// 9. ALBUMS
// =============================================
if(in_array('albums', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE albums");
    $cols = array_column($stmt->fetchAll(), 'Field');
    $req = ['id','name','artist_id','cover_image'];
    $missing = array_diff($req, $cols);
    $results['Albums Required Cols'] = ['pass' => empty($missing), 'detail' => empty($missing) ? "All present: ".implode(',',$cols) : "MISSING:".implode(',',$missing)];
}

// =============================================
// 10. GENRES
// =============================================
if(in_array('genres', $actualTables)) {
    $genres = $pdo->query("SELECT id,name FROM genres ORDER BY name")->fetchAll();
    $results['Genres View'] = ['pass' => count($genres) > 0, 'detail' => implode(', ', array_column($genres,'name'))];
}

// =============================================
// 11. LANGUAGES + YEARS
// =============================================
if(in_array('languages', $actualTables)) {
    $langs = $pdo->query("SELECT id,name FROM languages ORDER BY name")->fetchAll();
    $results['Languages View'] = ['pass' => count($langs) > 0, 'detail' => implode(', ', array_column($langs,'name'))];
}
if(in_array('years', $actualTables)) {
    $years = $pdo->query("SELECT COUNT(*) FROM years")->fetchColumn();
    $results['Years View'] = ['pass' => $years > 0, 'detail' => "$years year records"];
}

// =============================================
// 12. REVIEWS
// =============================================
if(in_array('reviews', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE reviews");
    $cols = array_column($stmt->fetchAll(), 'Field');
    $req = ['id','user_id','music_id','review_text'];
    $missing = array_diff($req, $cols);
    $results['Reviews Schema'] = ['pass' => empty($missing), 'detail' => "Cols: ".implode(',',$cols)];
    $count = $pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
    $results['Reviews Count'] = ['pass' => true, 'detail' => "$count reviews in DB"];
}

// =============================================
// 13. RATINGS
// =============================================
if(in_array('ratings', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE ratings");
    $cols = array_column($stmt->fetchAll(), 'Field');
    $req = ['id','user_id','music_id','rating'];
    $missing = array_diff($req, $cols);
    $results['Ratings Schema'] = ['pass' => empty($missing), 'detail' => "Cols: ".implode(',',$cols)];
    $count = $pdo->query("SELECT COUNT(*) FROM ratings")->fetchColumn();
    $results['Ratings Count'] = ['pass' => true, 'detail' => "$count ratings in DB"];
}

// =============================================
// 14. FAVORITES
// =============================================
if(in_array('favorites', $actualTables)) {
    $stmt = $pdo->query("DESCRIBE favorites");
    $cols = array_column($stmt->fetchAll(), 'Field');
    $results['Favorites Schema'] = ['pass' => true, 'detail' => "Cols: ".implode(',',$cols)];
    $count = $pdo->query("SELECT COUNT(*) FROM favorites")->fetchColumn();
    $results['Favorites Count'] = ['pass' => true, 'detail' => "$count favorites in DB"];
}

// =============================================
// 15. SEARCH FUNCTIONALITY
// =============================================
try {
    $stmt = $pdo->prepare("SELECT m.*, a.name as artist_name FROM music m JOIN artists a ON m.artist_id=a.id WHERE (m.song_name LIKE ? OR a.name LIKE ?) AND m.status='active' LIMIT 5");
    $stmt->execute(['%a%','%a%']);
    $rows = $stmt->fetchAll();
    $results['Music Search Query'] = ['pass' => true, 'detail' => count($rows)." results for '%a%'"];
} catch(PDOException $e) {
    $results['Music Search Query'] = ['pass' => false, 'detail' => $e->getMessage()];
}

try {
    $stmt = $pdo->prepare("SELECT v.*, a.name as artist_name FROM videos v JOIN artists a ON v.artist_id=a.id WHERE (v.video_name LIKE ? OR a.name LIKE ?) AND v.status='active' LIMIT 5");
    $stmt->execute(['%a%','%a%']);
    $rows = $stmt->fetchAll();
    $results['Video Search Query'] = ['pass' => true, 'detail' => count($rows)." results for '%a%'"];
} catch(PDOException $e) {
    $results['Video Search Query'] = ['pass' => false, 'detail' => $e->getMessage()];
}

// =============================================
// 16. ADMIN QUERIES (manage pages)
// =============================================
try {
    $stmt = $pdo->query("SELECT id,name,email,role,status,created_at FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll();
    $results['Admin Users List'] = ['pass' => true, 'detail' => count($users)." users"];
} catch(PDOException $e) {
    $results['Admin Users List'] = ['pass' => false, 'detail' => $e->getMessage()];
}

try {
    $stmt = $pdo->query("SELECT m.*, a.name as artist, al.name as album FROM music m JOIN artists a ON m.artist_id=a.id LEFT JOIN albums al ON m.album_id=al.id ORDER BY m.created_at DESC");
    $rows = $stmt->fetchAll();
    $results['Admin Music List'] = ['pass' => true, 'detail' => count($rows)." music records"];
} catch(PDOException $e) {
    $results['Admin Music List'] = ['pass' => false, 'detail' => $e->getMessage()];
}

// =============================================
// 17. WEBSITE SETTINGS
// =============================================
if(in_array('website_settings', $actualTables)) {
    $settings = $pdo->query("SELECT setting_key, setting_value FROM website_settings")->fetchAll();
    $results['Website Settings'] = ['pass' => count($settings) > 0, 'detail' => count($settings)." settings: ".implode(', ', array_column($settings,'setting_key'))];
}

// =============================================
// 18. ADMIN CRUD TEST (Add+Delete music)
// =============================================
try {
    $firstArtist = $pdo->query("SELECT id FROM artists LIMIT 1")->fetchColumn();
    $firstAlbum = $pdo->query("SELECT id FROM albums LIMIT 1")->fetchColumn();
    $firstGenre = $pdo->query("SELECT id FROM genres LIMIT 1")->fetchColumn();
    $firstLang = $pdo->query("SELECT id FROM languages LIMIT 1")->fetchColumn();
    $firstYear = $pdo->query("SELECT id FROM years LIMIT 1")->fetchColumn();

    $stmt = $pdo->prepare("INSERT INTO music (song_name,artist_id,album_id,genre_id,language_id,year_id,cover_image,status) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->execute(['DB_TEST_SONG', $firstArtist, $firstAlbum, $firstGenre, $firstLang, $firstYear, 'default_music.jpg', 'active']);
    $testMusicId = $pdo->lastInsertId();
    $results['Admin Music INSERT'] = ['pass' => true, 'detail' => "Inserted test music id=$testMusicId"];

    // Edit
    $pdo->prepare("UPDATE music SET song_name=? WHERE id=?")->execute(['DB_TEST_SONG_UPDATED', $testMusicId]);
    $updated = $pdo->prepare("SELECT song_name FROM music WHERE id=?");
    $updated->execute([$testMusicId]);
    $row = $updated->fetch();
    $results['Admin Music UPDATE'] = ['pass' => $row['song_name']==='DB_TEST_SONG_UPDATED', 'detail' => "Updated name: ".$row['song_name']];

    // Delete
    $pdo->prepare("DELETE FROM music WHERE id=?")->execute([$testMusicId]);
    $check = $pdo->prepare("SELECT COUNT(*) FROM music WHERE id=?");
    $check->execute([$testMusicId]);
    $results['Admin Music DELETE'] = ['pass' => $check->fetchColumn()==0, 'detail' => "Test record deleted successfully"];

} catch(PDOException $e) {
    $results['Admin Music CRUD'] = ['pass' => false, 'detail' => $e->getMessage()];
}

// =============================================
// 19. FAVORITES INSERT/DELETE TEST
// =============================================
if(in_array('favorites', $actualTables)) {
    try {
        $favCols = $pdo->query("DESCRIBE favorites")->fetchAll(PDO::FETCH_COLUMN);
        $firstMusic = $pdo->query("SELECT id FROM music LIMIT 1")->fetchColumn();
        // Try inserting a dummy favorite (user_id=0 won't violate FK if no FK constraint)
        $stmt = $pdo->prepare("INSERT INTO favorites (user_id, music_id) VALUES (?,?)");
        $stmt->execute([9999, $firstMusic]);
        $favId = $pdo->lastInsertId();
        $pdo->prepare("DELETE FROM favorites WHERE id=?")->execute([$favId]);
        $results['Favorites INSERT/DELETE'] = ['pass' => true, 'detail' => "Insert+delete OK (id=$favId)"];
    } catch(PDOException $e) {
        $results['Favorites INSERT/DELETE'] = ['pass' => false, 'detail' => $e->getMessage()];
    }
}

// =============================================
// OUTPUT
// =============================================
$pass = 0; $fail = 0;
foreach($results as $k=>$v) {
    if($v['pass']) $pass++; else $fail++;
}

header('Content-Type: text/plain');
echo "============================================================\n";
echo "  SOUND DATABASE COMPREHENSIVE TEST RESULTS\n";
echo "  " . date('Y-m-d H:i:s') . "\n";
echo "============================================================\n\n";

foreach($results as $name => $r) {
    $icon = $r['pass'] ? '[PASS]' : '[FAIL]';
    echo str_pad($icon, 7) . " $name\n";
    echo "         " . $r['detail'] . "\n\n";
}

echo "============================================================\n";
echo "  TOTAL: $pass PASS, $fail FAIL\n";

if(!empty($fixes)) {
    echo "\nISSUES NOTED:\n";
    foreach($fixes as $f) echo "  - $f\n";
}

echo "============================================================\n";
