<?php
require_once 'config/db.php';
$langs = $pdo->query("SELECT * FROM languages ORDER BY name")->fetchAll();
$pageTitle = "Explore by Language";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Explore by Language</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Discover music and videos from different languages and cultures. Select a language to explore its available music, videos, artists and albums.</p>
    </div>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($langs as $lang): ?>
        <div class="col">
            <a href="language_details.php?id=<?= $lang['id'] ?>" class="btn btn-outline-light w-100 py-4 fw-bold fs-5 rounded h-100 shadow hover-bg-primary transition-all">
                <span class="text-uppercase"><?= htmlspecialchars($lang['name']) ?></span>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>