<?php
require_once 'config/db.php';
$pageTitle = "Terms & Conditions";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">Terms & Conditions</h1>
            <p class="text-secondary mb-5">By accessing and using SOUND, you agree to follow these Terms & Conditions.</p>
            
            <h4 class="fw-bold text-primary mb-3">User Accounts</h4>
            <p class="text-light mb-4">Users are responsible for providing accurate information during registration and maintaining the security of their account credentials.</p>

            <h4 class="fw-bold text-primary mb-3">Website Content</h4>
            <p class="text-light mb-4">Music, videos, images, descriptions and other content available on the website are provided for entertainment and informational purposes.</p>

            <h4 class="fw-bold text-primary mb-3">Reviews</h4>
            <p class="text-light mb-4">Users are responsible for the content of reviews they submit. Reviews should be relevant, respectful and appropriate.</p>

            <h4 class="fw-bold text-primary mb-3">Ratings</h4>
            <p class="text-light mb-4">Users may provide ratings based on their personal experience and opinion.</p>

            <h4 class="fw-bold text-primary mb-3">Prohibited Activities</h4>
            <p class="text-light mb-4">Users must not attempt to misuse the website, gain unauthorized access, interfere with website functionality or submit unlawful content.</p>

            <h4 class="fw-bold text-primary mb-3">Intellectual Property</h4>
            <p class="text-light mb-4">Website content may be protected by applicable intellectual property laws. Users should not reproduce or distribute content without appropriate authorization.</p>

            <h4 class="fw-bold text-primary mb-3">Changes</h4>
            <p class="text-light mb-4">SOUND may update these Terms & Conditions when necessary.</p>

            <h4 class="fw-bold text-primary mb-3">Contact</h4>
            <p class="text-light mb-4">For questions regarding these terms, please <a href="contact.php" class="text-primary">contact SOUND</a> through the Contact page.</p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>