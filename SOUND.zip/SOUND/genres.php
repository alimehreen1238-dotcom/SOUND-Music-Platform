<?php
require_once 'config/db.php';
$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();
$pageTitle = "Explore Genres";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Explore Genres</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Discover music and videos organized by genre. Explore familiar favorites or find a new sound.</p>
    </div>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($genres as $genre): ?>
        <div class="col">
            <a href="genre_details.php?id=<?= $genre['id'] ?>" class="btn btn-outline-light w-100 py-4 fw-bold fs-5 rounded d-flex flex-column align-items-center justify-content-center h-100 shadow hover-bg-primary transition-all">
                <i class="fas fa-music mb-2 fs-3 text-primary"></i>
                <span class="text-uppercase"><?= htmlspecialchars($genre['name']) ?></span>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>