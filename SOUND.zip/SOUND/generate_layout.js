const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'includes/header.php': `<?php require_once __DIR__.'/../config/db.php'; require_once __DIR__.'/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? $pageTitle . ' - ' : '' ?><?= $settings['Website Name'] ?? 'SOUND' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/SOUND/assets/css/style.css">
</head>
<body>
    <div id="loader" class="loading-screen d-flex flex-column justify-content-center align-items-center">
        <h1 class="display-3 fw-bold text-white mb-2">SOUND</h1>
        <p class="text-light">TUNING INTO YOUR WORLD...</p>
    </div>
    <?php include 'navbar.php'; ?>
    <main class="main-content">`,
    
    'includes/navbar.php': `<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNavbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-3" href="/SOUND/index.php"><?= $settings['Website Name'] ?? 'SOUND' ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="/SOUND/index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/music.php">Music</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/videos.php">Videos</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/explore.php">Explore</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/artists.php">Artists</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/albums.php">Albums</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/genres.php">Genres</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/languages.php">Languages</a></li>
            </ul>
            <div class="d-flex align-items-center">
                <a href="/SOUND/search.php" class="text-light me-3 fs-5"><i class="fas fa-search"></i></a>
                <?php if (isLoggedIn()): ?>
                    <div class="dropdown">
                        <a class="btn btn-outline-light dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> Profile
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isAdmin()): ?>
                                <li><a class="dropdown-item" href="/SOUND/admin/index.php">Admin Panel</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="/SOUND/user/dashboard.php">Dashboard</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/SOUND/auth/logout.php">Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/SOUND/auth/login.php" class="btn btn-primary me-2">Login</a>
                    <a href="/SOUND/auth/register.php" class="btn btn-outline-light">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>`,
    
    'includes/footer.php': `    </main>
    <footer class="footer mt-auto py-5 bg-black text-light">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6">
                    <h3 class="fw-bold mb-3"><?= $settings['Website Name'] ?? 'SOUND' ?></h3>
                    <h6 class="text-primary mb-3"><?= $settings['Website Tagline'] ?? 'Your Sound. Your World.' ?></h6>
                    <p class="text-secondary"><?= $settings['Footer Text'] ?? 'Made for entertainment, discovery and connection.' ?></p>
                    <div class="social-links mt-4">
                        <a href="<?= $settings['Facebook URL'] ?? '#' ?>" class="me-3 fs-4 text-light"><i class="fab fa-facebook"></i></a>
                        <a href="<?= $settings['Instagram URL'] ?? '#' ?>" class="me-3 fs-4 text-light"><i class="fab fa-instagram"></i></a>
                        <a href="<?= $settings['YouTube URL'] ?? '#' ?>" class="fs-4 text-light"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="/SOUND/index.php">Home</a></li>
                        <li><a href="/SOUND/music.php">Music</a></li>
                        <li><a href="/SOUND/videos.php">Videos</a></li>
                        <li><a href="/SOUND/explore.php">Explore</a></li>
                        <li><a href="/SOUND/artists.php">Artists</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3">
                    <h5 class="mb-3">More</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="/SOUND/albums.php">Albums</a></li>
                        <li><a href="/SOUND/genres.php">Genres</a></li>
                        <li><a href="/SOUND/languages.php">Languages</a></li>
                        <li><a href="/SOUND/about.php">About</a></li>
                        <li><a href="/SOUND/contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="mb-3">Information</h5>
                    <ul class="list-unstyled footer-links mb-3">
                        <li><a href="/SOUND/faq.php">FAQ</a></li>
                        <li><a href="/SOUND/privacy_policy.php">Privacy Policy</a></li>
                        <li><a href="/SOUND/terms_conditions.php">Terms & Conditions</a></li>
                    </ul>
                    <p class="text-secondary mb-1"><i class="fas fa-envelope me-2"></i> <?= $settings['Contact Email'] ?? 'support@sound.com' ?></p>
                    <p class="text-secondary"><i class="fas fa-phone me-2"></i> <?= $settings['Contact Phone'] ?? '+92 300 1234567' ?></p>
                </div>
            </div>
            <div class="border-top border-secondary mt-4 pt-4 text-center text-secondary">
                <p class="mb-0"><?= $settings['Copyright Text'] ?? '© 2026 SOUND. All Rights Reserved.' ?></p>
            </div>
        </div>
    </footer>
    
    <div id="mini-player" class="mini-player d-none">
        <div class="d-flex align-items-center w-100 px-3 py-2">
            <img id="mp-cover" src="/SOUND/assets/images/default_music.jpg" alt="Cover" class="rounded me-3" style="width:50px;height:50px;object-fit:cover;">
            <div class="flex-grow-1 me-3 text-truncate">
                <h6 id="mp-title" class="mb-0 text-light text-truncate">Song Title</h6>
                <small id="mp-artist" class="text-secondary text-truncate">Artist</small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <button id="mp-play" class="btn text-light p-0 fs-3"><i class="fas fa-play-circle"></i></button>
                <button id="mp-close" class="btn text-secondary p-0 ms-2"><i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="progress-container px-3 pb-2 w-100">
            <input type="range" id="mp-progress" class="form-range" min="0" max="100" value="0">
        </div>
        <audio id="audio-element" src=""></audio>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="/SOUND/assets/js/main.js"></script>
</body>
</html>`,

'assets/css/style.css': \`
:root { --bg-dark: #0a0a0a; --bg-darker: #050505; --primary-red: #8B0000; --accent-red: #B22222; --text-light: #f4f4f4; --text-muted: #aaaaaa; --glass-bg: rgba(20, 20, 20, 0.7); --glass-border: rgba(255, 255, 255, 0.1); }
body { background-color: var(--bg-dark); color: var(--text-light); font-family: 'Inter', sans-serif; overflow-x: hidden; }
.text-primary { color: var(--primary-red) !important; }
.bg-primary { background-color: var(--primary-red) !important; }
.btn-primary { background-color: var(--primary-red); border-color: var(--primary-red); }
.btn-primary:hover { background-color: var(--accent-red); border-color: var(--accent-red); }
.bg-black { background-color: var(--bg-darker) !important; }
.loading-screen { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: var(--bg-darker); z-index: 9999; transition: opacity 0.5s ease; }
.navbar { background: transparent; transition: all 0.3s ease; padding: 1.5rem 0; }
.navbar.scrolled { background: var(--glass-bg); backdrop-filter: blur(10px); border-bottom: 1px solid var(--glass-border); padding: 0.8rem 0; }
.navbar-nav .nav-link { color: var(--text-light); font-weight: 500; margin: 0 0.5rem; transition: color 0.2s; }
.navbar-nav .nav-link:hover { color: var(--accent-red); }
.hero-section { position: relative; height: 100vh; display: flex; align-items: center; overflow: hidden; }
#three-canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; opacity: 0.6; }
.hero-content { position: relative; z-index: 1; }
.hero-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom, rgba(10,10,10,0.3) 0%, rgba(10,10,10,1) 100%); z-index: 0; }
.music-card, .video-card, .artist-card, .album-card { background: rgba(20,20,20,0.6); border: 1px solid var(--glass-border); border-radius: 12px; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease; position: relative; text-decoration:none; display:block; color:white; }
.music-card:hover, .video-card:hover, .artist-card:hover, .album-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(139,0,0,0.2); color:white; }
.card-img-wrapper { position: relative; overflow: hidden; }
.card-img-wrapper img { transition: transform 0.5s ease; width: 100%; height: 250px; object-fit: cover; }
.music-card:hover .card-img-wrapper img { transform: scale(1.05); }
.play-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; opacity: 0; transition: opacity 0.3s ease; }
.music-card:hover .play-overlay { opacity: 1; }
.play-btn { font-size: 3rem; color: var(--text-light); text-shadow: 0 0 10px rgba(139,0,0,0.8); }
.play-btn:hover { color: var(--accent-red); }
.badge-new { position: absolute; top: 10px; left: 10px; background: var(--primary-red); color: white; padding: 0.3rem 0.6rem; border-radius: 4px; font-size: 0.8rem; font-weight: bold; animation: pulse 2s infinite; z-index: 2; }
@keyframes pulse { 0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(139,0,0,0.7); } 70% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(139,0,0,0); } 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(139,0,0,0); } }
.horizontal-scroll { display: flex; overflow-x: auto; gap: 1.5rem; padding-bottom: 1rem; scrollbar-width: thin; scrollbar-color: var(--primary-red) var(--bg-dark); }
.horizontal-scroll::-webkit-scrollbar { height: 6px; }
.horizontal-scroll::-webkit-scrollbar-thumb { background: var(--primary-red); border-radius: 3px; }
.horizontal-scroll .col-card { min-width: 250px; flex: 0 0 auto; }
.mini-player { position: fixed; bottom: 20px; right: 20px; width: 350px; background: var(--glass-bg); backdrop-filter: blur(15px); border: 1px solid var(--glass-border); border-radius: 12px; z-index: 1000; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
.footer-links li { margin-bottom: 0.5rem; }
.footer-links a { color: var(--text-muted); text-decoration: none; transition: color 0.2s; }
.footer-links a:hover { color: var(--text-light); }
.main-content { min-height: 80vh; padding-top: 80px; }
.hero-section { padding-top: 0; margin-top: -80px; }
.form-control, .form-select { background-color: rgba(255,255,255,0.05); border: 1px solid var(--glass-border); color: var(--text-light); }
.form-control:focus, .form-select:focus { background-color: rgba(255,255,255,0.1); border-color: var(--primary-red); box-shadow: 0 0 0 0.25rem rgba(139,0,0,0.25); color: var(--text-light); }
.auth-container { max-width: 500px; margin: 4rem auto; }
.auth-card { background: rgba(20,20,20,0.8); border: 1px solid var(--glass-border); border-radius: 12px; padding: 2rem; }
.admin-sidebar { height: 100vh; position: fixed; top: 0; left: 0; width: 250px; background: var(--bg-darker); border-right: 1px solid var(--glass-border); padding-top: 20px; overflow-y: auto; }
.admin-main { margin-left: 250px; padding: 30px; }
.admin-nav-link { color: var(--text-muted); padding: 10px 20px; display: block; text-decoration: none; }
.admin-nav-link:hover, .admin-nav-link.active { background: rgba(139,0,0,0.2); color: white; border-left: 4px solid var(--primary-red); }
.section-padding { padding: 5rem 0; }
\`,

'assets/js/main.js': \`
document.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => { const loader = document.getElementById('loader'); if(loader) { loader.style.opacity = '0'; setTimeout(() => loader.style.display = 'none', 500); } }, 800);
    const navbar = document.getElementById('mainNavbar');
    if(navbar) {
        window.addEventListener('scroll', () => { if (window.scrollY > 50) { navbar.classList.add('scrolled'); } else { navbar.classList.remove('scrolled'); } });
    }
    gsap.registerPlugin(ScrollTrigger);
    gsap.utils.toArray('.gsap-fade-up').forEach(elem => { gsap.from(elem, { scrollTrigger: { trigger: elem, start: "top 85%" }, y: 50, opacity: 0, duration: 0.8, ease: "power2.out" }); });
    gsap.utils.toArray('.gsap-stagger-cards').forEach(container => { gsap.from(container.children, { scrollTrigger: { trigger: container, start: "top 85%" }, y: 50, opacity: 0, duration: 0.6, stagger: 0.1, ease: "power2.out" }); });
    
    const canvas = document.getElementById('three-canvas');
    if (canvas) {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        canvas.appendChild(renderer.domElement);
        const geometry = new THREE.TorusGeometry(10, 3, 16, 100);
        const material = new THREE.MeshBasicMaterial({ color: 0x8b0000, wireframe: true, transparent: true, opacity: 0.3 });
        const torus = new THREE.Mesh(geometry, material);
        scene.add(torus);
        const particlesGeometry = new THREE.BufferGeometry();
        const particlesCount = 500;
        const posArray = new Float32Array(particlesCount * 3);
        for(let i=0; i<particlesCount*3; i++) { posArray[i] = (Math.random() - 0.5) * 50; }
        particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
        const particleMaterial = new THREE.PointsMaterial({ size: 0.05, color: 0xff0000, transparent: true, opacity: 0.5 });
        const particleMesh = new THREE.Points(particlesGeometry, particleMaterial);
        scene.add(particleMesh);
        camera.position.z = 20;
        function animate() { requestAnimationFrame(animate); torus.rotation.x += 0.005; torus.rotation.y += 0.005; particleMesh.rotation.y += 0.001; renderer.render(scene, camera); }
        animate();
        window.addEventListener('resize', () => { camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix(); renderer.setSize(window.innerWidth, window.innerHeight); });
        gsap.to(torus.position, { y: 5, scrollTrigger: { trigger: ".hero-section", start: "top top", end: "bottom top", scrub: 1 } });
    }
    const mpContainer = document.getElementById('mini-player');
    const audioElement = document.getElementById('audio-element');
    const mpPlayBtn = document.getElementById('mp-play');
    const mpCloseBtn = document.getElementById('mp-close');
    const mpProgress = document.getElementById('mp-progress');
    document.querySelectorAll('.play-music-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); e.stopPropagation();
            const src = this.dataset.src; const title = this.dataset.title; const artist = this.dataset.artist; const cover = this.dataset.cover;
            document.getElementById('mp-title').innerText = title; document.getElementById('mp-artist').innerText = artist; document.getElementById('mp-cover').src = cover;
            audioElement.src = src; audioElement.play(); mpContainer.classList.remove('d-none'); mpPlayBtn.innerHTML = '<i class="fas fa-pause-circle"></i>';
        });
    });
    if(mpPlayBtn) { mpPlayBtn.addEventListener('click', () => { if(audioElement.paused) { audioElement.play(); mpPlayBtn.innerHTML = '<i class="fas fa-pause-circle"></i>'; } else { audioElement.pause(); mpPlayBtn.innerHTML = '<i class="fas fa-play-circle"></i>'; } }); }
    if(mpCloseBtn) { mpCloseBtn.addEventListener('click', () => { audioElement.pause(); mpContainer.classList.add('d-none'); }); }
    if(audioElement) {
        audioElement.addEventListener('timeupdate', () => { if(audioElement.duration) { mpProgress.value = (audioElement.currentTime / audioElement.duration) * 100; } });
        mpProgress.addEventListener('input', () => { audioElement.currentTime = (mpProgress.value / 100) * audioElement.duration; });
    }
});
\`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
