document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.getElementById('mainNavbar');
    if(navbar) {
        window.addEventListener('scroll', () => { if (window.scrollY > 50) { navbar.classList.add('scrolled'); } else { navbar.classList.remove('scrolled'); } });
    }
    gsap.registerPlugin(ScrollTrigger);
    gsap.utils.toArray('.gsap-fade-up').forEach(elem => { gsap.from(elem, { scrollTrigger: { trigger: elem, start: "top 85%" }, y: 50, opacity: 0, duration: 0.8, ease: "power2.out" }); });
    gsap.utils.toArray('.gsap-stagger-cards').forEach(container => { gsap.from(container.children, { scrollTrigger: { trigger: container, start: "top 85%" }, y: 50, opacity: 0, duration: 0.6, stagger: 0.1, ease: "power2.out" }); });
    
    const canvas = document.getElementById('three-canvas');
    if (canvas) {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        canvas.appendChild(renderer.domElement);
        const geometry = new THREE.TorusGeometry(10, 3, 16, 100);
        const material = new THREE.MeshBasicMaterial({ color: 0x8b0000, wireframe: true, transparent: true, opacity: 0.3 });
        const torus = new THREE.Mesh(geometry, material);
        scene.add(torus);
        const particlesGeometry = new THREE.BufferGeometry();
        const particlesCount = 500;
        const posArray = new Float32Array(particlesCount * 3);
        for(let i=0; i<particlesCount*3; i++) { posArray[i] = (Math.random() - 0.5) * 50; }
        particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
        const particleMaterial = new THREE.PointsMaterial({ size: 0.05, color: 0xff0000, transparent: true, opacity: 0.5 });
        const particleMesh = new THREE.Points(particlesGeometry, particleMaterial);
        scene.add(particleMesh);
        camera.position.z = 20;
        // Make Hero static
        renderer.render(scene, camera);
        window.addEventListener('resize', () => { camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix(); renderer.render(scene, camera); });
    }

    // Page transition removed to improve speed

    const mpContainer = document.getElementById('mini-player');
    const audioElement = document.getElementById('audio-element');
    const mpPlayBtn = document.getElementById('mp-play');
    const mpCloseBtn = document.getElementById('mp-close');
    const mpProgress = document.getElementById('mp-progress');
    document.querySelectorAll('.play-music-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); e.stopPropagation();
            const src = this.dataset.src; const title = this.dataset.title; const artist = this.dataset.artist; const cover = this.dataset.cover;
            document.getElementById('mp-title').innerText = title; document.getElementById('mp-artist').innerText = artist; document.getElementById('mp-cover').src = cover;
            audioElement.src = src; audioElement.play(); mpContainer.classList.remove('d-none'); mpPlayBtn.innerHTML = '<i class="fas fa-pause-circle"></i>';
        });
    });
    if(mpPlayBtn) { mpPlayBtn.addEventListener('click', () => { if(audioElement.paused) { audioElement.play(); mpPlayBtn.innerHTML = '<i class="fas fa-pause-circle"></i>'; } else { audioElement.pause(); mpPlayBtn.innerHTML = '<i class="fas fa-play-circle"></i>'; } }); }
    if(mpCloseBtn) { mpCloseBtn.addEventListener('click', () => { audioElement.pause(); mpContainer.classList.add('d-none'); }); }
    if(audioElement) {
        audioElement.addEventListener('timeupdate', () => { if(audioElement.duration) { mpProgress.value = (audioElement.currentTime / audioElement.duration) * 100; } });
        mpProgress.addEventListener('input', () => { audioElement.currentTime = (mpProgress.value / 100) * audioElement.duration; });
    }

    // AI Chat Logic
    const aiForm = document.getElementById('ai-chat-form');
    const aiInput = document.getElementById('ai-chat-input');
    const aiHistory = document.getElementById('ai-chat-history');
    const aiClearBtn = document.getElementById('ai-clear-btn');
    
    if (aiClearBtn) {
        aiClearBtn.addEventListener('click', () => {
            aiHistory.innerHTML = `
                <!-- Initial Message -->
                <div class="d-flex mb-4">
                    <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; min-width: 40px;">
                        <i class="fas fa-robot text-white"></i>
                    </div>
                    <div class="bg-dark text-light rounded-3 p-3 shadow-sm border border-secondary" style="border-color: rgba(255,255,255,0.05) !important;">
                        Hi there! I'm your SOUND AI assistant. You can ask me to find Punjabi songs, search for specific artists, look for 2026 music, or explore videos. What would you like to listen to today?
                    </div>
                </div>
            `;
        });
    }
    
    if (aiForm) {
        aiForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const query = aiInput.value.trim();
            if (!query) return;
            
            // Append User Message
            const userMsg = document.createElement('div');
            userMsg.className = 'd-flex mb-4 justify-content-end';
            userMsg.innerHTML = `
                <div class="bg-white text-dark rounded-3 p-3 shadow-sm border" style="max-width: 80%;">
                    ${query}
                </div>
                <div class="bg-secondary rounded-circle d-flex justify-content-center align-items-center ms-3" style="width: 40px; height: 40px; min-width: 40px;">
                    <i class="fas fa-user text-white"></i>
                </div>
            `;
            aiHistory.appendChild(userMsg);
            aiInput.value = '';
            aiHistory.scrollTop = aiHistory.scrollHeight;
            
            // Append Loading Indicator
            const loadingMsg = document.createElement('div');
            loadingMsg.className = 'd-flex mb-4 ai-loading';
            loadingMsg.innerHTML = `
                <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; min-width: 40px;">
                    <i class="fas fa-robot text-white"></i>
                </div>
                <div class="bg-dark text-light rounded-3 p-3 shadow-sm border border-secondary d-flex align-items-center" style="border-color: rgba(255,255,255,0.05) !important;">
                    <div class="spinner-grow spinner-grow-sm text-primary me-2" role="status"></div>
                    <small>Searching SOUND database...</small>
                </div>
            `;
            aiHistory.appendChild(loadingMsg);
            aiHistory.scrollTop = aiHistory.scrollHeight;
            
            // Fetch AI Response
            fetch('/SOUND/ajax_ai.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: query })
            })
            .then(response => response.json())
            .then(data => {
                loadingMsg.remove();
                
                const aiMsg = document.createElement('div');
                aiMsg.className = 'd-flex mb-4';
                
                let resultsHtml = '';
                if (data.results && data.results.length > 0) {
                    resultsHtml = '<div class="d-flex flex-wrap gap-2 mt-3">';
                    data.results.forEach(res => {
                        resultsHtml += `
                            <a href="${res.url}" class="text-decoration-none border border-secondary rounded p-2 d-flex align-items-center text-light bg-black" style="min-width: 150px; flex: 1; border-color: rgba(255,255,255,0.1) !important;">
                                <img src="${res.image}" class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                <div>
                                    <small class="d-block text-truncate" style="max-width: 150px; font-weight: bold;">${res.title}</small>
                                    <span class="badge bg-primary mt-1" style="font-size: 0.6rem;">${res.type.toUpperCase()}</span>
                                </div>
                            </a>
                        `;
                    });
                    resultsHtml += '</div>';
                }
                
                aiMsg.innerHTML = `
                    <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; min-width: 40px;">
                        <i class="fas fa-robot text-white"></i>
                    </div>
                    <div class="bg-dark text-light rounded-3 p-3 shadow-sm border border-secondary w-100" style="border-color: rgba(255,255,255,0.05) !important;">
                        <div>${data.reply}</div>
                        ${resultsHtml}
                    </div>
                `;
                aiHistory.appendChild(aiMsg);
                gsap.from(aiMsg, { opacity: 0, y: 10, duration: 0.4 });
                aiHistory.scrollTop = aiHistory.scrollHeight;
            })
            .catch(error => {
                loadingMsg.remove();
                const errorMsg = document.createElement('div');
                errorMsg.className = 'd-flex mb-4';
                errorMsg.innerHTML = `
                    <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center me-3" style="width: 40px; height: 40px; min-width: 40px;">
                        <i class="fas fa-robot text-white"></i>
                    </div>
                    <div class="bg-dark text-light rounded-3 p-3 shadow-sm border border-secondary text-danger" style="border-color: rgba(255,255,255,0.05) !important;">
                        Sorry, an error occurred while searching.
                    </div>
                `;
                aiHistory.appendChild(errorMsg);
                aiHistory.scrollTop = aiHistory.scrollHeight;
            });
        });
    }
});
