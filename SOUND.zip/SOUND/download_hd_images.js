const https = require('https');
const fs = require('fs');
const path = require('path');

const baseImgDir = 'C:/xampp/htdocs/SOUND/assets/images';

const prompts = [
    // Music (15)
    "HD photorealistic close-up of a Pakistani musician playing a traditional rabab, dark moody studio lighting, 2026 trending music aesthetic",
    "HD wide shot of a modern Pakistani indie pop band performing on a neon-lit stage in Lahore, cinematic photography",
    "HD album art style photo of a modern Pakistani female singer recording in a vocal booth, red and black aesthetic",
    "HD photorealistic shot of an acoustic guitar leaning against an amplifier in a dark Karachi studio, maroon glow",
    "HD vibrant concert photography of a Pakistani rock band, lead guitarist mid-solo, crowd in background, high contrast",
    "HD close-up of a microphone in a dark recording studio with subtle red LED lights, modern Pakistani pop vibes",
    "HD traditional tabla drums glowing under cinematic studio lights, modern fusion music concept",
    "HD beautiful portrait of a Pakistani classical singer performing at a cultural festival, cinematic dark background",
    "HD shot of a modern DJ controller at a Karachi nightlife music event, neon red lights, photorealistic",
    "HD silhouette of a singer against a giant LED screen displaying Pakistani cultural patterns at a concert",
    "HD photorealistic shot of vintage studio headphones resting on a mixing console, moody atmosphere",
    "HD dynamic concert photography, female Pakistani pop star performing with energy, dark cinematic lighting",
    "HD close up of a sitar played by a modern musician, fusion music aesthetic, maroon background",
    "HD studio shot of a modern music producer working on a track, dual monitors, dark room with red accents",
    "HD wide cinematic shot of a Sufi rock performance, traditional clothes mixed with electric guitars, epic lighting",
    
    // Videos (15)
    "HD cinematic still from a Pakistani music video, neon lit street in Lahore at night, moody atmosphere",
    "HD music video thumbnail, artists performing on a rooftop in Karachi at sunset, golden hour lighting",
    "HD cinematic still of a traditional Qawwali performance with modern stage lighting, high contrast",
    "HD music video scene, female singer in modern Pakistani fashion walking down a dimly lit alley, cinematic",
    "HD concert video thumbnail, massive crowd holding up phone lights, red stage lights",
    "HD cinematic still of a drummer hitting crash cymbals, water splashing, high speed photography, red tint",
    "HD music video frame, romantic duet scene in a beautifully lit Mughal courtyard at night",
    "HD behind the scenes music video shoot, camera operator filming an artist, studio lights, dark vibe",
    "HD cinematic still of a Pakistani rapper performing in a graffiti-filled underground club, neon glow",
    "HD music video thumbnail, traditional dhol players in a modern neon-lit studio setting",
    "HD cinematic shot of a vintage microphone stand in the spotlight, empty dark stage, moody red tint",
    "HD music video scene, an artist playing piano in a grand empty hall, dramatic shadows",
    "HD cinematic still of a modern fusion band performing in a desert landscape at dusk",
    "HD music video thumbnail, abstract neon lights surrounding a pop artist, highly stylized 2026 aesthetic",
    "HD cinematic shot of an outdoor music festival in Pakistan, massive stage, lasers, night sky",
    
    // Artists (10)
    "HD professional portrait of a modern male Pakistani pop singer, dark moody background, red rim light",
    "HD professional portrait of a female Pakistani indie musician holding an acoustic guitar, cinematic",
    "HD close-up portrait of a legendary Sufi singer, expressive face, dramatic stage lighting",
    "HD stylish portrait of a young Pakistani rapper, streetwear fashion, neon city lights in background",
    "HD beautiful portrait of a Pakistani female classical vocalist, traditional jewelry, modern dark aesthetic",
    "HD portrait of a rock band lead guitarist, leather jacket, dark studio background with subtle maroon glow",
    "HD artistic portrait of a music producer, wearing headphones, looking at camera, moody studio lighting",
    "HD portrait of a traditional folk singer, weathered face, high contrast cinematic black and white with red accent",
    "HD modern portrait of a female DJ from Karachi, neon lights reflecting on her face",
    "HD stylish group portrait of a 3-piece Pakistani pop band, modern fashion, dark background",
    
    // Albums (10)
    "HD modern album cover art, abstract red and black geometric patterns, Pakistani cultural motifs",
    "HD cinematic album artwork, a lone figure standing on a Lahore rooftop at night, moody",
    "HD aesthetic album cover, close-up of a neon sign in Urdu glowing in a dark alley",
    "HD beautiful album cover, a single red rose resting on a guitar fretboard, dark background",
    "HD modern album artwork, abstract soundwaves forming a landscape, deep maroon and black",
    "HD minimalist album cover, a traditional rabab instrument floating in dark space, cinematic lighting",
    "HD album cover art, double exposure of a singer's face and a Karachi city skyline at night",
    "HD stylized album artwork, vintage cassette tape with red neon glow on a black reflective surface",
    "HD album cover, a beautiful traditional Pakistani door slightly open revealing a bright light, dark setting",
    "HD modern album cover, abstract colorful paint splash in the shape of a treble clef, black background"
];

const tasks = [
    ...Array.from({length: 15}, (_, i) => ({ file: `music/music${i+1}.jpg`, prompt: prompts[i] })),
    ...Array.from({length: 15}, (_, i) => ({ file: `videos/vid${i+1}.jpg`, prompt: prompts[i+15] })),
    ...Array.from({length: 10}, (_, i) => ({ file: `artists/art${i+1}.jpg`, prompt: prompts[i+30] })),
    ...Array.from({length: 10}, (_, i) => ({ file: `albums/alb${i+1}.jpg`, prompt: prompts[i+40] }))
];

const download = (prompt, file) => new Promise((resolve) => {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=800&height=800&nologo=true&seed=${Math.floor(Math.random()*10000)}`;
    https.get(url, res => {
        if (res.statusCode === 200) {
            const w = fs.createWriteStream(file);
            res.pipe(w);
            w.on('finish', () => resolve(true));
        } else if (res.headers.location) {
            https.get(res.headers.location, res2 => {
                if (res2.statusCode === 200) {
                    const w = fs.createWriteStream(file);
                    res2.pipe(w);
                    w.on('finish', () => resolve(true));
                } else {
                    resolve(false);
                }
            }).on('error', () => resolve(false));
        } else resolve(false);
    }).on('error', () => resolve(false));
});

async function run() {
    console.log("Starting HD image generation...");
    for (let i = 0; i < tasks.length; i++) {
        console.log(`Downloading ${i+1}/${tasks.length}: ${tasks[i].file}`);
        await download(tasks[i].prompt, path.join(baseImgDir, tasks[i].file));
        await new Promise(r => setTimeout(r, 1000));
    }
    console.log("All HD images downloaded successfully.");
}

run();
