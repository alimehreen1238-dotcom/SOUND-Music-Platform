<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$q = isset($_GET['q']) ? sanitize($_GET['q']) : '';

$mRes = []; $vRes = []; $aRes = []; $alRes = [];
if($q) {
    $mStmt = $pdo->prepare("SELECT * FROM music WHERE song_name LIKE ? AND status='active' LIMIT 10");
    $mStmt->execute(["%$q%"]); $mRes = $mStmt->fetchAll();
    
    $vStmt = $pdo->prepare("SELECT * FROM videos WHERE video_name LIKE ? AND status='active' LIMIT 10");
    $vStmt->execute(["%$q%"]); $vRes = $vStmt->fetchAll();
    
    $aStmt = $pdo->prepare("SELECT * FROM artists WHERE name LIKE ? LIMIT 10");
    $aStmt->execute(["%$q%"]); $aRes = $aStmt->fetchAll();
    
    $alStmt = $pdo->prepare("SELECT * FROM albums WHERE name LIKE ? LIMIT 10");
    $alStmt->execute(["%$q%"]); $alRes = $alStmt->fetchAll();
}

$pageTitle = "Search SOUND";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="text-center mb-5">
        <h1 class="fw-bold mb-2">Search SOUND</h1>
        <p class="text-secondary mx-auto" style="max-width:600px;">Search across music, videos, artists and albums to quickly find what you're looking for.</p>
        <form method="GET" action="search.php" class="d-flex justify-content-center mt-4 mx-auto" style="max-width: 600px;">
            <div class="input-group input-group-lg">
                <input type="text" name="q" class="form-control bg-dark text-light border-secondary" placeholder="Search music, videos, artists, albums..." value="<?= htmlspecialchars($q) ?>">
                <button type="submit" class="btn btn-primary px-4"><i class="fas fa-search"></i></button>
            </div>
        </form>
    </div>

    <?php if($q): ?>
        <h4 class="fw-bold mb-4 border-bottom border-secondary pb-2">Results for: "<?= htmlspecialchars($q) ?>"</h4>
        
        <?php if(!$mRes && !$vRes && !$aRes && !$alRes): ?>
            <div class="text-center py-5">
                <i class="fas fa-search fs-1 text-muted mb-3"></i>
                <h4 class="text-light">No results found.</h4>
                <p class="text-secondary">We couldn't find anything matching your search. Try a different keyword.</p>
            </div>
        <?php else: ?>
            
            <?php if($mRes): ?>
                <h5 class="fw-bold mb-3 text-primary">Music</h5>
                <div class="row row-cols-2 row-cols-md-5 g-3 mb-5">
                    <?php foreach($mRes as $r): ?>
                    <div class="col"><a href="music_details.php?id=<?= $r['id'] ?>" class="text-decoration-none text-light"><div class="card bg-dark border-secondary p-2"><h6 class="mb-0 text-truncate"><?= htmlspecialchars($r['song_name']) ?></h6></div></a></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if($vRes): ?>
                <h5 class="fw-bold mb-3 text-primary">Videos</h5>
                <div class="row row-cols-2 row-cols-md-5 g-3 mb-5">
                    <?php foreach($vRes as $r): ?>
                    <div class="col"><a href="video_details.php?id=<?= $r['id'] ?>" class="text-decoration-none text-light"><div class="card bg-dark border-secondary p-2"><h6 class="mb-0 text-truncate"><?= htmlspecialchars($r['video_name']) ?></h6></div></a></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>