<?php http_response_code(403); $pageTitle = "Access Denied"; require_once 'includes/header.php'; ?>
<div class="container text-center section-padding gsap-fade-up">
    <h1 class="display-1 fw-bold text-danger mb-3">403</h1>
    <h3 class="fw-bold text-light mb-3">Access Denied</h3>
    <p class="text-secondary mb-4">You don't have permission to access this page.</p>
    <a href="/SOUND/index.php" class="btn btn-outline-light px-4">Back to Home</a>
</div>
<?php require_once 'includes/footer.php'; ?>