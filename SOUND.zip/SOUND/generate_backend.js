const fs = require('fs');
const path = require('path');

const basePath = 'C:/xampp/htdocs/SOUND';

const files = {
    'config/db.php': `<?php
session_start();
$host = 'localhost';
$dbname = 'sound_db';
$user = 'root';
$pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

function getSettings($pdo) {
    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM website_settings");
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    } catch(PDOException $e) {
        return [];
    }
}
$settings = getSettings($pdo);
?>`,
    
    'includes/functions.php': `<?php
function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = "Please log in to continue.";
        header('Location: /SOUND/auth/login.php');
        exit;
    }
}
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /SOUND/403.php');
        exit;
    }
}
function sanitize($data) { return htmlspecialchars(strip_tags(trim($data))); }
function getFlashError() {
    if (isset($_SESSION['error'])) {
        $msg = $_SESSION['error']; unset($_SESSION['error']);
        return "<div class='alert alert-danger'>$msg</div>";
    }
    return '';
}
function getFlashSuccess() {
    if (isset($_SESSION['success'])) {
        $msg = $_SESSION['success']; unset($_SESSION['success']);
        return "<div class='alert alert-success'>$msg</div>";
    }
    return '';
}
function getStars($rating) {
    $stars = '';
    for($i=1; $i<=5; $i++) {
        if($i <= $rating) $stars .= '<i class="fas fa-star text-warning"></i>';
        else $stars .= '<i class="far fa-star text-warning"></i>';
    }
    return $stars;
}
?>`
};

for (const [relPath, content] of Object.entries(files)) {
    fs.writeFileSync(path.join(basePath, relPath), content);
}
console.log("Backend framework generated.");
