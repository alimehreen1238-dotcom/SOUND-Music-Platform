const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'user/my_reviews.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();

if(isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ? AND user_id = ?");
    $stmt->execute([$_POST['delete_id'], $_SESSION['user_id']]);
    $_SESSION['success'] = "Review deleted successfully.";
    header("Location: my_reviews.php"); exit;
}

$stmt = $pdo->prepare("SELECT r.*, 
    CASE WHEN r.content_type='music' THEN m.song_name ELSE v.video_name END as content_name
    FROM reviews r
    LEFT JOIN music m ON r.content_id = m.id AND r.content_type = 'music'
    LEFT JOIN videos v ON r.content_id = v.id AND r.content_type = 'video'
    WHERE r.user_id = ? ORDER BY r.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$reviews = $stmt->fetchAll();

$pageTitle = "My Reviews";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <h2 class="fw-bold mb-2">My Reviews</h2>
    <p class="text-secondary mb-4">View and manage the reviews you have submitted on SOUND.</p>
    
    <?= getFlashSuccess() ?>
    
    <?php if($reviews): ?>
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4">Content</th>
                            <th>Type</th>
                            <th>Rating</th>
                            <th>Review</th>
                            <th>Date</th>
                            <th class="text-end pe-4">Action</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($reviews as $r): ?>
                        <tr>
                            <td class="ps-4 fw-bold"><?= htmlspecialchars($r['content_name']) ?></td>
                            <td><span class="badge bg-secondary"><?= ucfirst($r['content_type']) ?></span></td>
                            <td><span class="text-warning"><?= getStars($r['rating']) ?></span></td>
                            <td class="text-truncate" style="max-width:200px;"><?= htmlspecialchars($r['review']) ?></td>
                            <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                            <td class="text-end pe-4">
                                <a href="../<?= $r['content_type'] ?>_details.php?id=<?= $r['content_id'] ?>" class="btn btn-sm btn-outline-info me-2">View</a>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this review?');">
                                    <input type="hidden" name="delete_id" value="<?= $r['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <h5 class="text-light">You haven't submitted any reviews yet.</h5>
        <p class="text-secondary">Explore music and videos to share your thoughts.</p>
        <a href="../explore.php" class="btn btn-primary mt-3">Explore Content</a>
    </div>
    <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'user/my_ratings.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();

if(isset($_POST['update_id'])) {
    $stmt = $pdo->prepare("UPDATE reviews SET rating = ? WHERE id = ? AND user_id = ?");
    $stmt->execute([$_POST['new_rating'], $_POST['update_id'], $_SESSION['user_id']]);
    $_SESSION['success'] = "Rating updated successfully.";
    header("Location: my_ratings.php"); exit;
}

$stmt = $pdo->prepare("SELECT r.*, 
    CASE WHEN r.content_type='music' THEN m.song_name ELSE v.video_name END as content_name
    FROM reviews r
    LEFT JOIN music m ON r.content_id = m.id AND r.content_type = 'music'
    LEFT JOIN videos v ON r.content_id = v.id AND r.content_type = 'video'
    WHERE r.user_id = ? ORDER BY r.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$ratings = $stmt->fetchAll();

$pageTitle = "My Ratings";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <h2 class="fw-bold mb-2">My Ratings</h2>
    <p class="text-secondary mb-4">View and manage the ratings you have given to music and videos.</p>
    
    <?= getFlashSuccess() ?>
    
    <?php if($ratings): ?>
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4">Content</th>
                            <th>Type</th>
                            <th>Current Rating</th>
                            <th>Date</th>
                            <th class="text-end pe-4">Update</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($ratings as $r): ?>
                        <tr>
                            <td class="ps-4 fw-bold"><?= htmlspecialchars($r['content_name']) ?></td>
                            <td><span class="badge bg-secondary"><?= ucfirst($r['content_type']) ?></span></td>
                            <td><span class="text-warning"><?= getStars($r['rating']) ?></span></td>
                            <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                            <td class="text-end pe-4">
                                <form method="POST" class="d-flex align-items-center justify-content-end gap-2">
                                    <input type="hidden" name="update_id" value="<?= $r['id'] ?>">
                                    <select name="new_rating" class="form-select form-select-sm bg-dark text-light border-secondary w-auto">
                                        <option value="5" <?= $r['rating']==5?'selected':'' ?>>5</option>
                                        <option value="4" <?= $r['rating']==4?'selected':'' ?>>4</option>
                                        <option value="3" <?= $r['rating']==3?'selected':'' ?>>3</option>
                                        <option value="2" <?= $r['rating']==2?'selected':'' ?>>2</option>
                                        <option value="1" <?= $r['rating']==1?'selected':'' ?>>1</option>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-outline-primary">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <h5 class="text-light">You haven't rated any content yet.</h5>
        <a href="../explore.php" class="btn btn-primary mt-3">Explore Content</a>
    </div>
    <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
