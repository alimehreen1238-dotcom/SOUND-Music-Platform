<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT al.*, a.name as artist_name, g.name as genre_name, y.year, l.name as language_name
          FROM albums al
          LEFT JOIN artists a ON al.artist_id = a.id
          LEFT JOIN genres g ON al.genre_id = g.id
          LEFT JOIN years y ON al.year_id = y.id
          LEFT JOIN languages l ON al.language_id = l.id
          WHERE al.id = ?");
$stmt->execute([$id]);
$album = $stmt->fetch();

if(!$album) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM music WHERE album_id = ? AND status = 'active' ORDER BY created_at ASC");
$stmt->execute([$id]);
$trackList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($album['name']);
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5 align-items-center">
        <div class="col-md-4 text-center text-md-start mb-4 mb-md-0">
            <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="img-fluid rounded shadow-lg border border-secondary" style="max-width:300px;">
        </div>
        <div class="col-md-8">
            <p class="text-primary fw-bold tracking-wide mb-1">ALBUM</p>
            <h1 class="display-4 fw-bold mb-2"><?= htmlspecialchars($album['name']) ?></h1>
            <h4 class="text-secondary mb-4">By <a href="artist_details.php?id=<?= $album['artist_id'] ?>" class="text-light text-decoration-none"><?= htmlspecialchars($album['artist_name']) ?></a></h4>
            
            <ul class="list-unstyled text-muted mb-4">
                <li><strong class="text-light">Release Year:</strong> <?= htmlspecialchars($album['year'] ?? 'Unknown') ?></li>
                <li><strong class="text-light">Genre:</strong> <?= htmlspecialchars($album['genre_name'] ?? 'Unknown') ?></li>
                <li><strong class="text-light">Language:</strong> <?= htmlspecialchars($album['language_name'] ?? 'Unknown') ?></li>
            </ul>

            <h5 class="fw-bold mb-2">About This Album</h5>
            <p class="text-light mb-0" style="max-width: 600px;">
                <?= htmlspecialchars($album['description'] ?? $album['name'].' is a collection of music by '.$album['artist_name'].'. Explore the tracks included in this album and discover more music from the artist.') ?>
            </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-4 border-bottom border-secondary pb-2">Track List</h4>
            <div class="list-group list-group-flush bg-transparent">
                <?php $i=1; foreach($trackList as $track): ?>
                <div class="list-group-item bg-transparent text-light border-secondary py-3 d-flex align-items-center justify-content-between hover-bg-dark">
                    <div class="d-flex align-items-center">
                        <span class="text-secondary me-3" style="width:25px;"><?= sprintf("%02d", $i++) ?></span>
                        <button class="btn btn-sm btn-outline-light rounded-circle play-music-btn me-3" style="width:35px;height:35px;"
                           data-src="/SOUND/assets/music/<?= $track['music_file'] ?>" 
                           data-title="<?= htmlspecialchars($track['song_name']) ?>" 
                           data-artist="<?= htmlspecialchars($album['artist_name']) ?>"
                           data-cover="/SOUND/assets/images/<?= $album['cover'] ?>">
                            <i class="fas fa-play"></i>
                        </button>
                        <div>
                            <a href="music_details.php?id=<?= $track['id'] ?>" class="text-light fw-bold text-decoration-none d-block"><?= htmlspecialchars($track['song_name']) ?></a>
                            <small class="text-secondary"><?= htmlspecialchars($album['artist_name']) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if(empty($trackList)): ?>
                <p class="text-secondary">No tracks found in this album.</p>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <h5 class="fw-bold mb-4 mt-4 mt-md-0">More Albums by <?= htmlspecialchars($album['artist_name']) ?></h5>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM albums WHERE artist_id = ? AND id != ? LIMIT 3");
            $stmt->execute([$album['artist_id'], $id]);
            $related = $stmt->fetchAll();
            foreach($related as $rel):
            ?>
                <a href="album_details.php?id=<?= $rel['id'] ?>" class="d-flex align-items-center text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary">
                    <img src="/SOUND/assets/images/<?= $rel['cover'] ?>" class="rounded me-3" style="width:60px;height:60px;object-fit:cover;">
                    <div>
                        <h6 class="text-light mb-1 text-truncate" style="max-width: 150px;"><?= htmlspecialchars($rel['name']) ?></h6>
                        <small class="text-secondary"><?= $rel['year'] ?? '' ?></small>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>