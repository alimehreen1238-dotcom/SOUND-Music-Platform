import os

base_dir = r"C:\xampp\htdocs\SOUND\admin"
crud_tables = {
    "videos": {"title": "Videos", "singular": "Video", "fields": ["video_name", "artist_id"], "table": "videos"},
    "artists": {"title": "Artists", "singular": "Artist", "fields": ["name", "country"], "table": "artists"},
    "albums": {"title": "Albums", "singular": "Album", "fields": ["name", "artist_id"], "table": "albums"},
    "genres": {"title": "Genres", "singular": "Genre", "fields": ["name"], "table": "genres"},
    "languages": {"title": "Languages", "singular": "Language", "fields": ["name"], "table": "languages"},
    "users": {"title": "Users", "singular": "User", "fields": ["name", "email", "role"], "table": "users"}
}

template = """<?php
require_once 'includes/header.php';
$table = '{table}';

if(isset($_POST['delete_id'])) {{
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    $_SESSION['success'] = "{singular} deleted successfully.";
    header("Location: manage_{table}.php");
    exit;
}}

$stmt = $pdo->query("SELECT * FROM $table ORDER BY id DESC");
$records = $stmt->fetchAll();
?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Manage {title}</h2>
            <p class="text-secondary mb-0">View and manage {title}.</p>
        </div>
        <a href="#" class="btn btn-primary fw-bold" onclick="alert('Add {singular} functionality is available through database seed or other interfaces in this demo.')"><i class="fas fa-plus me-2"></i>Add New {singular}</a>
    </div>
    
    <?= getFlashSuccess() ?>
    
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3">ID</th>
                            {th_fields}
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($records as $r): ?>
                        <tr>
                            <td class="ps-4 text-secondary">#<?= $r['id'] ?></td>
                            {td_fields}
                            <td class="text-end pe-4">
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this {singular}?');">
                                    <input type="hidden" name="delete_id" value="<?= $r['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$records): ?>
                        <tr><td colspan="5" class="text-center py-4 text-secondary">No {title} found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
"""

for key, config in crud_tables.items():
    th_fields = "".join([f"<th>{f.replace('_id', '').capitalize()}</th>" for f in config["fields"]])
    td_fields = "".join([f"<td><?= htmlspecialchars($r['{f}']) ?></td>" for f in config["fields"]])
    content = template.format(table=config["table"], title=config["title"], singular=config["singular"], th_fields=th_fields, td_fields=td_fields)
    
    filepath = os.path.join(base_dir, f"manage_{key}.php")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

print("Admin CRUD pages generated.")
