<?php
require_once 'config/db.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM genres WHERE id = ?");
$stmt->execute([$id]);
$genre = $stmt->fetch();
if(!$genre) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT m.*, a.name as artist_name FROM music m JOIN artists a ON m.artist_id=a.id WHERE m.genre_id=? AND m.status='active' ORDER BY m.created_at DESC LIMIT 8");
$stmt->execute([$id]);
$musicList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT v.*, a.name as artist_name FROM videos v JOIN artists a ON v.artist_id=a.id WHERE v.genre_id=? AND v.status='active' ORDER BY v.created_at DESC LIMIT 4");
$stmt->execute([$id]);
$videoList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($genre['name']) . " Music";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="mb-5 border-bottom border-secondary pb-4">
        <h1 class="display-4 fw-bold text-primary mb-3"><?= htmlspecialchars($genre['name']) ?> Music</h1>
        <p class="lead text-light">Explore music and videos from the <?= htmlspecialchars($genre['name']) ?> genre. Discover popular artists, albums and songs available on SOUND.</p>
    </div>

    <h4 class="fw-bold mb-4">Latest <?= htmlspecialchars($genre['name']) ?> Music</h4>
    <?php if($musicList): ?>
        <div class="row row-cols-2 row-cols-md-4 g-4 mb-5">
            <?php foreach($musicList as $music): ?>
            <div class="col">
                <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light">
                    <div class="card bg-dark border-secondary h-100">
                        <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                        <div class="card-body p-2">
                            <h6 class="mb-0 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                            <small class="text-secondary text-truncate d-block"><?= htmlspecialchars($music['artist_name']) ?></small>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-secondary mb-5">No music is currently available for this genre.</p>
    <?php endif; ?>

    <h4 class="fw-bold mb-4"><?= htmlspecialchars($genre['name']) ?> Videos</h4>
    <?php if($videoList): ?>
        <div class="row row-cols-1 row-cols-md-4 g-4 mb-5">
            <?php foreach($videoList as $video): ?>
            <div class="col">
                <a href="video_details.php?id=<?= $video['id'] ?>" class="text-decoration-none text-light">
                    <div class="card bg-dark border-secondary h-100">
                        <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" class="card-img-top" style="height:120px;object-fit:cover;">
                        <div class="card-body p-2">
                            <h6 class="mb-0 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h6>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-secondary">No videos are currently available for this genre.</p>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>