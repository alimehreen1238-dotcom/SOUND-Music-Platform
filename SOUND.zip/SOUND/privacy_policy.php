<?php
require_once 'config/db.php';
$pageTitle = "Privacy Policy";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="fw-bold mb-4">Privacy Policy</h1>
            <p class="text-secondary mb-5">At SOUND, we respect your privacy and are committed to protecting the information you provide while using our website.</p>
            
            <h4 class="fw-bold text-primary mb-3">Information We Collect</h4>
            <p class="text-light mb-4">When you create an account, we may collect information such as your name, address, phone number, email address and account credentials.</p>

            <h4 class="fw-bold text-primary mb-3">How We Use Information</h4>
            <p class="text-light mb-4">Information may be used to create and manage your account, provide website functionality, maintain security and improve the user experience.</p>

            <h4 class="fw-bold text-primary mb-3">Reviews and Ratings</h4>
            <p class="text-light mb-4">Reviews and ratings submitted by registered users may be displayed alongside the relevant music or video content.</p>

            <h4 class="fw-bold text-primary mb-3">Data Security</h4>
            <p class="text-light mb-4">We take reasonable measures to protect user information and prevent unauthorized access.</p>

            <h4 class="fw-bold text-primary mb-3">Cookies</h4>
            <p class="text-light mb-4">SOUND may use cookies or similar technologies to support website functionality and improve the browsing experience.</p>

            <h4 class="fw-bold text-primary mb-3">Changes</h4>
            <p class="text-light mb-4">This Privacy Policy may be updated when necessary. Users are encouraged to review this page periodically.</p>

            <h4 class="fw-bold text-primary mb-3">Contact</h4>
            <p class="text-light mb-4">If you have questions about this Privacy Policy, please <a href="contact.php" class="text-primary">contact us</a> through the Contact page.</p>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>