const https = require('https');
const fs = require('fs');
const path = require('path');

const fetchUnsplashUrls = (query) => {
    return new Promise((resolve, reject) => {
        https.get('https://unsplash.com/s/photos/' + query, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                // handle redirect
                return resolve(fetchUnsplashUrls(res.headers.location));
            }
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                const regex = /https:\/\/images\.unsplash\.com\/photo-[a-zA-Z0-9\-]+/g;
                const matches = data.match(regex) || [];
                // Remove duplicates and append width/quality params
                const unique = [...new Set(matches)].map(url => url + '?w=800&q=80');
                resolve(unique);
            });
        }).on('error', reject);
    });
};

(async () => {
    const urls = await fetchUnsplashUrls('pakistan');
    console.log("Found URLs:", urls.length);
    console.log(urls.slice(0, 5));
})();
