const https = require('https');
const fs = require('fs');
const path = require('path');

const baseImgDir = 'C:/xampp/htdocs/SOUND/assets/images';

const articles = [
    '/wiki/Music_of_Pakistan',
    '/wiki/Qawwali',
    '/wiki/Pakistani_pop_music',
    '/wiki/Coke_Studio_(Pakistani_TV_program)',
    '/wiki/Atif_Aslam',
    '/wiki/Nusrat_Fateh_Ali_Khan',
    '/wiki/Abida_Parveen',
    '/wiki/Ali_Zafar',
    '/wiki/Nazia_Hassan',
    '/wiki/Sufi_rock',
    '/wiki/Junoon_(band)',
    '/wiki/Vital_Signs_(band)',
    '/wiki/String_instruments',
    '/wiki/Tabla',
    '/wiki/Lahore',
    '/wiki/Karachi'
];

function fetchImagesFromArticle(pathStr) {
    return new Promise((resolve) => {
        https.get({
            hostname: 'en.wikipedia.org',
            path: pathStr,
            headers: { 'User-Agent': 'SOUND-Bot/1.0 (test@example.com)' }
        }, (res) => {
            let html = '';
            res.on('data', chunk => html += chunk);
            res.on('end', () => {
                const regex = /<img[^>]+src="\/\/upload\.wikimedia\.org\/wikipedia\/(commons|en)\/thumb\/[^"]+\.(jpg|JPG|jpeg|JPEG|png|PNG)\/[^"]+"/g;
                const matches = html.match(regex) || [];
                const urls = matches.map(img => {
                    const srcMatch = img.match(/src="\/\/([^"]+)"/);
                    if (srcMatch) {
                        // Wikipedia thumbnail URLs: //upload.wikimedia.org/.../thumb/a/a0/File.jpg/220px-File.jpg
                        // We can get the original by stripping /thumb/ and the trailing /...px-...
                        let url = 'https://' + srcMatch[1];
                        url = url.replace('/thumb/', '/');
                        url = url.substring(0, url.lastIndexOf('/'));
                        return url;
                    }
                    return null;
                }).filter(Boolean);
                resolve(urls);
            });
        }).on('error', () => resolve([]));
    });
}

const downloadFile = (url, filepath) => {
    return new Promise((resolve) => {
        https.get(url, { headers: { 'User-Agent': 'SOUND-Bot/1.0' } }, (res) => {
            if (res.statusCode === 200) {
                const file = fs.createWriteStream(filepath);
                res.pipe(file);
                file.on('finish', () => { file.close(); resolve(true); });
            } else {
                resolve(false);
            }
        }).on('error', () => resolve(false));
    });
};

async function processAll() {
    console.log("Scraping Wikipedia articles for Pakistani music images...");
    let allUrls = [];
    for (let a of articles) {
        const urls = await fetchImagesFromArticle(a);
        allUrls.push(...urls);
    }
    
    // Deduplicate
    allUrls = [...new Set(allUrls)];
    console.log("Total unique real photos found: " + allUrls.length);
    
    let uIdx = 0;
    const nextUrl = () => allUrls[uIdx++ % allUrls.length];

    const tasks = [
        { file: 'hero/hero_bg.jpg' },
        ...Array.from({length: 15}, (_, i) => ({ file: `music/music${i+1}.jpg` })),
        ...Array.from({length: 15}, (_, i) => ({ file: `videos/vid${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `artists/art${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `albums/alb${i+1}.jpg` }))
    ];
    
    for (let t of tasks) {
        let success = await downloadFile(nextUrl(), path.join(baseImgDir, t.file));
        if(!success) console.log("Failed downloading to " + t.file);
    }
    console.log("All downloads complete.");
}

processAll();
