const https = require('https');
const fs = require('fs');
const path = require('path');

const baseImgDir = 'C:/xampp/htdocs/SOUND/assets/images';
const dirs = ['music', 'videos', 'artists', 'albums', 'genres', 'languages', 'hero'];

dirs.forEach(d => {
    const p = path.join(baseImgDir, d);
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

// Helper to download image
const downloadImage = (prompt, filepath, width, height) => {
    return new Promise((resolve) => {
        // Add seed for uniqueness
        const seed = Math.floor(Math.random() * 100000);
        const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&nologo=true&seed=${seed}`;
        
        https.get(url, (res) => {
            if (res.statusCode === 200) {
                const file = fs.createWriteStream(filepath);
                res.pipe(file);
                file.on('finish', () => { file.close(); resolve(true); });
            } else if (res.headers.location) {
                https.get(res.headers.location, (res2) => {
                    const file = fs.createWriteStream(filepath);
                    res2.pipe(file);
                    file.on('finish', () => { file.close(); resolve(true); });
                });
            } else {
                resolve(false);
            }
        }).on('error', () => resolve(false));
    });
};

const tasks = [
    // Hero
    { file: 'hero/hero_bg.jpg', p: 'Cinematic photograph of a massive Pakistani music festival at night in Lahore, energetic crowd, dark red concert lighting, photorealistic, DSLR', w: 1200, h: 600, t: 'hero' },
    
    // Music (15)
    { file: 'music/music1.jpg', p: 'Photorealistic album cover, Lahore night street atmosphere, neon lights, dark and moody', w: 500, h: 500 },
    { file: 'music/music2.jpg', p: 'Photorealistic album cover, generic male Pakistani pop singer silhouette in dark studio', w: 500, h: 500 },
    { file: 'music/music3.jpg', p: 'Photorealistic album cover, Karachi night skyline, glowing city lights, cinematic', w: 500, h: 500 },
    { file: 'music/music4.jpg', p: 'Photorealistic album cover, traditional Pakistani musical instruments, sitar and tabla, dark background', w: 500, h: 500 },
    { file: 'music/music5.jpg', p: 'Photorealistic album cover, generic female Pakistani singer performing on stage, red lighting', w: 500, h: 500 },
    { file: 'music/music6.jpg', p: 'Photorealistic album cover, modern recording studio in Pakistan, microphone and mixing desk', w: 500, h: 500 },
    { file: 'music/music7.jpg', p: 'Photorealistic album cover, beautiful rainy street in Pakistan, cinematic, moody', w: 500, h: 500 },
    { file: 'music/music8.jpg', p: 'Photorealistic album cover, Pakistani truck art patterns subtly illuminated in the dark', w: 500, h: 500 },
    { file: 'music/music9.jpg', p: 'Photorealistic album cover, young Pakistani musicians playing acoustic guitar in a cozy room', w: 500, h: 500 },
    { file: 'music/music10.jpg', p: 'Photorealistic album cover, Sufi music performance, mystic atmosphere, dramatic shadows', w: 500, h: 500 },
    { file: 'music/music11.jpg', p: 'Photorealistic album cover, rock band performing, energetic red and black lighting, silhouettes', w: 500, h: 500 },
    { file: 'music/music12.jpg', p: 'Photorealistic album cover, desert sunset in Sindh, traditional musicians, cinematic', w: 500, h: 500 },
    { file: 'music/music13.jpg', p: 'Photorealistic album cover, modern Pakistani street fashion, moody portrait, dark aesthetic', w: 500, h: 500 },
    { file: 'music/music14.jpg', p: 'Photorealistic album cover, classical music setting, harmonium and oil lamps', w: 500, h: 500 },
    { file: 'music/music15.jpg', p: 'Photorealistic album cover, high energy concert crowd in Pakistan, hands in the air', w: 500, h: 500 },
    
    // Videos (15)
    { file: 'videos/vid1.jpg', p: 'Cinematic music video thumbnail, Lahore historical architecture at night, photorealistic', w: 800, h: 450 },
    { file: 'videos/vid2.jpg', p: 'Cinematic music video thumbnail, live concert performance in Pakistan, wide angle', w: 800, h: 450 },
    { file: 'videos/vid3.jpg', p: 'Cinematic music video thumbnail, acoustic session on a rooftop in Karachi', w: 800, h: 450 },
    { file: 'videos/vid4.jpg', p: 'Cinematic music video thumbnail, dramatic Sufi qawwali performance, mystical lighting', w: 800, h: 450 },
    { file: 'videos/vid5.jpg', p: 'Cinematic music video thumbnail, street dancers in Pakistan, neon lighting, gritty', w: 800, h: 450 },
    { file: 'videos/vid6.jpg', p: 'Cinematic music video thumbnail, romantic walk in the rain, cinematic Pakistani setting', w: 800, h: 450 },
    { file: 'videos/vid7.jpg', p: 'Cinematic music video thumbnail, recording a song in a high-end studio, dark aesthetic', w: 800, h: 450 },
    { file: 'videos/vid8.jpg', p: 'Cinematic music video thumbnail, traditional wedding music scene, dhol players', w: 800, h: 450 },
    { file: 'videos/vid9.jpg', p: 'Cinematic music video thumbnail, desert folk music video, cinematic lighting', w: 800, h: 450 },
    { file: 'videos/vid10.jpg', p: 'Cinematic music video thumbnail, modern pop music video set, sleek and dark', w: 800, h: 450 },
    { file: 'videos/vid11.jpg', p: 'Cinematic music video thumbnail, rock band shredding on guitar, dramatic stage lights', w: 800, h: 450 },
    { file: 'videos/vid12.jpg', p: 'Cinematic music video thumbnail, intimate unplugged performance, warm lighting', w: 800, h: 450 },
    { file: 'videos/vid13.jpg', p: 'Cinematic music video thumbnail, colorful cultural festival in Pakistan at night', w: 800, h: 450 },
    { file: 'videos/vid14.jpg', p: 'Cinematic music video thumbnail, intense rap battle setting in an alley, dark', w: 800, h: 450 },
    { file: 'videos/vid15.jpg', p: 'Cinematic music video thumbnail, artist looking out over the city lights, cinematic', w: 800, h: 450 },
    
    // Artists (10)
    { file: 'artists/art1.jpg', p: 'Portrait of a generic young female Pakistani pop singer holding a microphone, dark stage', w: 500, h: 500 },
    { file: 'artists/art2.jpg', p: 'Portrait of a generic mature male Pakistani Sufi vocalist, traditional attire, passionate expression', w: 500, h: 500 },
    { file: 'artists/art3.jpg', p: 'Portrait of a generic modern Pakistani hip hop artist, streetwear, neon street background', w: 500, h: 500 },
    { file: 'artists/art4.jpg', p: 'Portrait of a generic female Pakistani indie musician playing acoustic guitar', w: 500, h: 500 },
    { file: 'artists/art5.jpg', p: 'Portrait of a generic male Pakistani classical singer, elegant kurta, dark background', w: 500, h: 500 },
    { file: 'artists/art6.jpg', p: 'Portrait of a generic female Sindhi artist in vibrant traditional dress, cinematic lighting', w: 500, h: 500 },
    { file: 'artists/art7.jpg', p: 'Silhouette portrait of a Pakistani rock guitarist, energetic vibe', w: 500, h: 500 },
    { file: 'artists/art8.jpg', p: 'Portrait of a generic male Pakistani pop star in a recording studio', w: 500, h: 500 },
    { file: 'artists/art9.jpg', p: 'Portrait of a generic female Pakistani traditional folk singer, dramatic shadows', w: 500, h: 500 },
    { file: 'artists/art10.jpg', p: 'Portrait of a generic Pakistani music producer at a mixing desk, dark and professional', w: 500, h: 500 },
    
    // Albums (10)
    { file: 'albums/alb1.jpg', p: 'Premium album cover photography, artistic shot of a vintage microphone', w: 500, h: 500 },
    { file: 'albums/alb2.jpg', p: 'Premium album cover photography, abstract light trails in a dark city', w: 500, h: 500 },
    { file: 'albums/alb3.jpg', p: 'Premium album cover photography, traditional Pakistani architectural details, dark maroon tone', w: 500, h: 500 },
    { file: 'albums/alb4.jpg', p: 'Premium album cover photography, a solitary acoustic guitar leaning against a brick wall', w: 500, h: 500 },
    { file: 'albums/alb5.jpg', p: 'Premium album cover photography, close up of piano keys in dim light', w: 500, h: 500 },
    { file: 'albums/alb6.jpg', p: 'Premium album cover photography, blurred crowd at a concert, cinematic', w: 500, h: 500 },
    { file: 'albums/alb7.jpg', p: 'Premium album cover photography, detailed texture of a tabla drum', w: 500, h: 500 },
    { file: 'albums/alb8.jpg', p: 'Premium album cover photography, artist walking away down a rainy street', w: 500, h: 500 },
    { file: 'albums/alb9.jpg', p: 'Premium album cover photography, abstract red and black smoke', w: 500, h: 500 },
    { file: 'albums/alb10.jpg', p: 'Premium album cover photography, close up of vinyl record spinning', w: 500, h: 500 }
];

async function processAll() {
    console.log(`Downloading ${tasks.length} images...`);
    // Download 5 at a time
    for (let i = 0; i < tasks.length; i += 5) {
        const batch = tasks.slice(i, i + 5);
        await Promise.all(batch.map(t => downloadImage(t.p, path.join(baseImgDir, t.file), t.w, t.h)));
        console.log(`Processed batch ${i/5 + 1}`);
    }
    console.log("Done downloading images.");
    
    const dbUpdates = `
<?php
require_once 'C:/xampp/htdocs/SOUND/config/db.php';
$pdo->query("UPDATE music SET cover_image = CONCAT('music/music', id, '.jpg') WHERE id <= 15");
$pdo->query("UPDATE videos SET thumbnail = CONCAT('videos/vid', id, '.jpg') WHERE id <= 15");
$pdo->query("UPDATE artists SET image = CONCAT('artists/art', id, '.jpg') WHERE id <= 10");
$pdo->query("UPDATE albums SET cover = CONCAT('albums/alb', id, '.jpg') WHERE id <= 10");
echo "Database updated successfully to use .jpg photography.";
?>
    `;
    fs.writeFileSync('C:/xampp/htdocs/SOUND/update_db_photos.php', dbUpdates);
}

processAll();
