<?php
require_once 'includes/header.php';
$table = 'genres';

if(isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    $_SESSION['success'] = "Genre deleted successfully.";
    header("Location: manage_genres.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM $table ORDER BY id DESC");
$records = $stmt->fetchAll();
?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Manage Genres</h2>
            <p class="text-secondary mb-0">View and manage Genres.</p>
        </div>
        <a href="#" class="btn btn-primary fw-bold" onclick="alert('Add Genre functionality is available through database seed or other interfaces in this demo.')"><i class="fas fa-plus me-2"></i>Add New Genre</a>
    </div>
    
    <?= getFlashSuccess() ?>
    
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3">ID</th>
                            <th>Name</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($records as $r): ?>
                        <tr>
                            <td class="ps-4 text-secondary">#<?= $r['id'] ?></td>
                            <td><?= htmlspecialchars($r['name'] ?? '') ?></td>
                            <td class="text-end pe-4">
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this Genre?');">
                                    <input type="hidden" name="delete_id" value="<?= $r['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$records): ?>
                        <tr><td colspan="5" class="text-center py-4 text-secondary">No Genres found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
