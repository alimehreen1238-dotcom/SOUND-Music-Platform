<?php
require_once 'includes/header.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $song_name = sanitize($_POST['song_name']);
    $artist_id = (int)$_POST['artist_id'];
    $album_id = $_POST['album_id'] ? (int)$_POST['album_id'] : null;
    $genre_id = (int)$_POST['genre_id'];
    $year_id = (int)$_POST['year_id'];
    $language_id = (int)$_POST['language_id'];
    $is_new = isset($_POST['is_new']) ? 1 : 0;
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("INSERT INTO music (song_name, artist_id, album_id, genre_id, year_id, language_id, music_file, is_new, status) VALUES (?, ?, ?, ?, ?, ?, 'dummy.mp3', ?, ?)");
    if($stmt->execute([$song_name, $artist_id, $album_id, $genre_id, $year_id, $language_id, $is_new, $status])) {
        $_SESSION['success'] = "Music has been added successfully.";
        header("Location: manage_music.php");
        exit;
    }
}
$artists = $pdo->query("SELECT * FROM artists ORDER BY name")->fetchAll();
$albums = $pdo->query("SELECT * FROM albums ORDER BY name")->fetchAll();
$genres = $pdo->query("SELECT * FROM genres ORDER BY name")->fetchAll();
$years = $pdo->query("SELECT * FROM years ORDER BY year DESC")->fetchAll();
$langs = $pdo->query("SELECT * FROM languages ORDER BY name")->fetchAll();
?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">Add New Music</h2>
    <div class="card bg-dark border-secondary">
        <div class="card-body p-4">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Song Name *</label>
                        <input type="text" name="song_name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Artist *</label>
                        <select name="artist_id" class="form-select" required>
                            <?php foreach($artists as $a): ?><option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Genre *</label>
                        <select name="genre_id" class="form-select" required>
                            <?php foreach($genres as $g): ?><option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Language *</label>
                        <select name="language_id" class="form-select" required>
                            <?php foreach($langs as $l): ?><option value="<?= $l['id'] ?>"><?= htmlspecialchars($l['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Year *</label>
                        <select name="year_id" class="form-select" required>
                            <?php foreach($years as $y): ?><option value="<?= $y['id'] ?>"><?= htmlspecialchars($y['year']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light">Status *</label>
                        <select name="status" class="form-select" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="mb-4 form-check">
                    <input type="checkbox" name="is_new" class="form-check-input" id="is_new" checked>
                    <label class="form-check-label text-light" for="is_new">Mark as New Content</label>
                </div>
                <button type="submit" class="btn btn-primary fw-bold px-4">Save Music</button>
                <a href="manage_music.php" class="btn btn-outline-secondary ms-2">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>