<?php
require_once 'includes/header.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $settingsToUpdate = ['Website Name', 'Website Tagline', 'About Website', 'Contact Email', 'Contact Phone', 'Address', 'Facebook URL', 'Instagram URL', 'YouTube URL', 'Footer Text', 'Copyright Text', 'Hero Heading', 'Hero Description', 'Welcome Heading', 'Welcome Description'];
    
    foreach($settingsToUpdate as $key) {
        if(isset($_POST[str_replace(' ', '_', $key)])) {
            $stmt = $pdo->prepare("UPDATE website_settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$_POST[str_replace(' ', '_', $key)], $key]);
        }
    }
    $_SESSION['success'] = "Website settings have been updated successfully.";
    header("Location: settings.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM website_settings");
$currentSettings = [];
while($row = $stmt->fetch()) { $currentSettings[$row['setting_key']] = $row['setting_value']; }
?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">Website Settings</h2>
    <?= getFlashSuccess() ?>
    
    <div class="card bg-dark border-secondary">
        <div class="card-body p-4">
            <form method="POST">
                <div class="row">
                    <?php foreach($currentSettings as $key => $val): ?>
                    <div class="col-md-6 mb-3">
                        <label class="form-label text-light"><?= htmlspecialchars($key) ?></label>
                        <?php if(strpos($key, 'Description') !== false || strpos($key, 'About') !== false): ?>
                            <textarea name="<?= str_replace(' ', '_', $key) ?>" class="form-control" rows="3"><?= htmlspecialchars($val) ?></textarea>
                        <?php else: ?>
                            <input type="text" name="<?= str_replace(' ', '_', $key) ?>" class="form-control" value="<?= htmlspecialchars($val) ?>">
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn btn-primary fw-bold px-4 mt-3">Save Settings</button>
            </form>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>