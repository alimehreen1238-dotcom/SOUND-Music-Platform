<?php
$pageTitle = "Dashboard";
require_once 'includes/header.php';

$stats = [
    'Music' => $pdo->query("SELECT COUNT(*) FROM music")->fetchColumn(),
    'Videos' => $pdo->query("SELECT COUNT(*) FROM videos")->fetchColumn(),
    'Artists' => $pdo->query("SELECT COUNT(*) FROM artists")->fetchColumn(),
    'Users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
];
?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-1">Dashboard</h2>
    <p class="text-secondary mb-4">Welcome to the SOUND Administration Panel.</p>
    
    <div class="row g-4 mb-4">
        <?php foreach($stats as $label => $count): ?>
        <div class="col-md-3">
            <div class="card bg-dark text-white border-secondary h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="text-secondary mb-2"><?= $label ?></h5>
                    <h2 class="fw-bold mb-0 text-primary"><?= $count ?></h2>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>