<?php
require_once 'includes/header.php';

if(isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM music WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    $_SESSION['success'] = "Music entry deleted successfully.";
    header("Location: manage_music.php");
    exit;
}

$stmt = $pdo->query("SELECT m.*, a.name as artist_name FROM music m LEFT JOIN artists a ON m.artist_id = a.id ORDER BY m.created_at DESC");
$musicList = $stmt->fetchAll();
?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Manage Music</h2>
            <p class="text-secondary mb-0">Add, edit, view and delete music content.</p>
        </div>
        <a href="add_music.php" class="btn btn-primary fw-bold"><i class="fas fa-plus me-2"></i>Add New Music</a>
    </div>
    
    <?= getFlashSuccess() ?>
    <?= getFlashError() ?>
    
    <div class="card bg-dark border-secondary">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3">ID</th>
                            <th>Song Name</th>
                            <th>Artist</th>
                            <th>Status</th>
                            <th>New</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        <?php foreach($musicList as $m): ?>
                        <tr>
                            <td class="ps-4 text-secondary">#<?= $m['id'] ?></td>
                            <td class="fw-bold"><?= htmlspecialchars($m['song_name']) ?></td>
                            <td><?= htmlspecialchars($m['artist_name']) ?></td>
                            <td><span class="badge <?= $m['status']=='active'?'bg-success':'bg-danger' ?>"><?= ucfirst($m['status']) ?></span></td>
                            <td><?= $m['is_new'] ? '<span class="badge bg-primary">Yes</span>' : '-' ?></td>
                            <td class="text-end pe-4">
                                <a href="../music_details.php?id=<?= $m['id'] ?>" target="_blank" class="btn btn-sm btn-outline-info"><i class="fas fa-eye"></i></a>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this item? This action cannot be undone.');">
                                    <input type="hidden" name="delete_id" value="<?= $m['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$musicList): ?>
                        <tr><td colspan="6" class="text-center py-4 text-secondary">No music entries found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>