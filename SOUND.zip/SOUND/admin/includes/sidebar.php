<div class="admin-sidebar shadow-lg">
    <div class="text-center mb-4">
        <h4 class="text-light fw-bold">SOUND Admin</h4>
        <small class="text-secondary"><?= htmlspecialchars($_SESSION['name']) ?></small>
    </div>
    <ul class="list-unstyled">
        <li><a href="index.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF'])=='index.php'?'active':'' ?>"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
        <li><a href="manage_music.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'music')!==false?'active':'' ?>"><i class="fas fa-music me-2"></i> Manage Music</a></li>
        <li><a href="manage_videos.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'video')!==false?'active':'' ?>"><i class="fas fa-video me-2"></i> Manage Videos</a></li>
        <li><a href="manage_artists.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'artist')!==false?'active':'' ?>"><i class="fas fa-users me-2"></i> Manage Artists</a></li>
        <li><a href="manage_albums.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'album')!==false?'active':'' ?>"><i class="fas fa-record-vinyl me-2"></i> Manage Albums</a></li>
        <li><a href="manage_genres.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'genre')!==false?'active':'' ?>"><i class="fas fa-list me-2"></i> Manage Genres</a></li>
        <li><a href="manage_languages.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'language')!==false?'active':'' ?>"><i class="fas fa-globe me-2"></i> Manage Languages</a></li>
        <li><a href="manage_users.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'user')!==false?'active':'' ?>"><i class="fas fa-user-shield me-2"></i> Manage Users</a></li>
        <li><a href="settings.php" class="admin-nav-link <?= strpos($_SERVER['PHP_SELF'],'setting')!==false?'active':'' ?>"><i class="fas fa-cog me-2"></i> Website Settings</a></li>
        <li><a href="/SOUND/index.php" class="admin-nav-link mt-4 text-info"><i class="fas fa-external-link-alt me-2"></i> View Website</a></li>
        <li><a href="/SOUND/auth/logout.php" class="admin-nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
    </ul>
</div>