<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if(isLoggedIn()) { header("Location: /SOUND/index.php"); exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $user_id = sanitize($_POST['user_id']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if(empty($name) || empty($user_id) || empty($address) || empty($phone) || empty($email) || empty($password)) {
        $_SESSION['error'] = "Please fill in all required fields.";
    } elseif($password !== $confirm) {
        $_SESSION['error'] = "Passwords do not match.";
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        if($stmt->fetchColumn() > 0) {
            $_SESSION['error'] = "This User ID is already taken.";
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if($stmt->fetchColumn() > 0) {
                $_SESSION['error'] = "This email address is already registered.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (name, user_id, address, phone, email, password) VALUES (?, ?, ?, ?, ?, ?)");
                if($stmt->execute([$name, $user_id, $address, $phone, $email, $hashed])) {
                    $_SESSION['success'] = "Your account has been created successfully. Welcome to SOUND!";
                    header("Location: login.php");
                    exit;
                } else {
                    $_SESSION['error'] = "Something went wrong. Please try again.";
                }
            }
        }
    }
}
$pageTitle = "Register";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Create Your SOUND Account</h2>
        <p class="text-center text-secondary mb-4">Join the SOUND community and unlock the ability to rate and review your favorite music and videos.</p>
        <?= getFlashError() ?>
        <form method="POST">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Full Name *</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">User ID *</label>
                    <input type="text" name="user_id" class="form-control" placeholder="Choose a unique user ID" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label text-light">Email Address *</label>
                <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Phone Number *</label>
                    <input type="text" name="phone" class="form-control" placeholder="Enter your phone number" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Address *</label>
                    <input type="text" name="address" class="form-control" placeholder="Enter your complete address" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Password *</label>
                    <input type="password" name="password" class="form-control" placeholder="Create a password" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Confirm Password *</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
                </div>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" required id="terms">
                <label class="form-check-label text-secondary" for="terms">I agree to the Terms & Conditions and Privacy Policy.</label>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Create Account</button>
        </form>
        <div class="text-center mt-4">
            <span class="text-secondary">Already have an account?</span> <a href="login.php" class="text-light text-decoration-none">Login</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>