<?php
session_start();
session_destroy();
header("Location: /SOUND/index.php");
?>