<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "If an account exists with this email address, password reset instructions have been sent.";
    header("Location: forgot_password.php"); exit;
}
$pageTitle = "Forgot Password";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Forgot Your Password?</h2>
        <p class="text-center text-secondary mb-4">Enter the email address associated with your SOUND account and we'll help you reset your password.</p>
        <?= getFlashSuccess() ?>
        <form method="POST">
            <div class="mb-4">
                <label class="form-label text-light">Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Send Reset Link</button>
        </form>
        <div class="text-center mt-4">
            <a href="login.php" class="text-primary text-decoration-none"><i class="fas fa-arrow-left me-2"></i>Back to Login</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>