<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if(isLoggedIn()) { header("Location: /SOUND/index.php"); exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = sanitize($_POST['login']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR user_id = ?)");
    $stmt->execute([$login, $login]);
    $user = $stmt->fetch();
    
    if($user && password_verify($password, $user['password'])) {
        if($user['status'] == 'inactive') {
            $_SESSION['error'] = "Your account is currently inactive.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            
            if($user['role'] == 'admin') header("Location: /SOUND/admin/index.php");
            else header("Location: /SOUND/user/dashboard.php");
            exit;
        }
    } else {
        $_SESSION['error'] = "Invalid User ID or password.";
    }
}
$pageTitle = "Login";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Welcome Back</h2>
        <p class="text-center text-secondary mb-4">Sign in to your SOUND account and continue exploring.</p>
        <?= getFlashError() ?>
        <?= getFlashSuccess() ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light">User ID or Email</label>
                <input type="text" name="login" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-light">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember">
                <label class="form-check-label text-secondary" for="remember">Remember Me</label>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Login</button>
        </form>
        <div class="text-center mt-4">
            <a href="forgot_password.php" class="text-primary text-decoration-none d-block mb-2">Forgot Password?</a>
            <span class="text-secondary">Don't have an account?</span> <a href="register.php" class="text-light text-decoration-none">Create an Account</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>