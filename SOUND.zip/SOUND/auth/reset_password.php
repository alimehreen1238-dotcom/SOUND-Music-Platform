<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['success'] = "Your password has been updated successfully.";
    header("Location: login.php"); exit;
}
$pageTitle = "Reset Password";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Create a New Password</h2>
        <p class="text-center text-secondary mb-4">Enter a new password for your SOUND account.</p>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light">New Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-4">
                <label class="form-label text-light">Confirm New Password</label>
                <input type="password" name="confirm" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Reset Password</button>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>