const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'index.php': `<?php
$pageTitle = "Home";
require_once 'includes/header.php';

// Fetch Latest Music
$stmt = $pdo->query("SELECT m.*, a.name as artist_name, al.name as album_name 
                     FROM music m 
                     JOIN artists a ON m.artist_id = a.id 
                     LEFT JOIN albums al ON m.album_id = al.id 
                     WHERE m.status = 'active' 
                     ORDER BY m.created_at DESC LIMIT 15");
$latestMusic = $stmt->fetchAll();

// Fetch Latest Videos
$stmt = $pdo->query("SELECT v.*, a.name as artist_name 
                     FROM videos v 
                     JOIN artists a ON v.artist_id = a.id 
                     WHERE v.status = 'active' 
                     ORDER BY v.created_at DESC LIMIT 15");
$latestVideos = $stmt->fetchAll();

// Fetch Featured Artists
$stmt = $pdo->query("SELECT * FROM artists ORDER BY created_at DESC LIMIT 10");
$featuredArtists = $stmt->fetchAll();

// Fetch Genres
$stmt = $pdo->query("SELECT * FROM genres LIMIT 12");
$genres = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero-section">
    <div id="three-canvas"></div>
    <div class="hero-overlay"></div>
    <div class="container hero-content text-center text-md-start">
        <h6 class="text-primary fw-bold tracking-wide mb-3 gsap-fade-up">MUSIC • VIDEOS • ARTISTS • STORIES</h6>
        <h1 class="display-1 fw-bold mb-4 text-white gsap-fade-up"><?= $settings['Hero Heading'] ?? 'Your Sound. Your World.' ?></h1>
        <p class="lead text-light mb-5 max-w-lg gsap-fade-up"><?= $settings['Hero Description'] ?? 'Discover music, videos, artists and stories from different cultures, languages and generations — all in one immersive place.' ?></p>
        <div class="d-flex gap-3 justify-content-center justify-content-md-start gsap-fade-up">
            <a href="music.php" class="btn btn-primary btn-lg px-4 py-2 rounded-pill">Explore Music</a>
            <a href="videos.php" class="btn btn-outline-light btn-lg px-4 py-2 rounded-pill">Watch Videos</a>
        </div>
    </div>
</section>

<!-- Welcome Section -->
<section class="section-padding bg-black">
    <div class="container text-center gsap-fade-up">
        <h2 class="fw-bold mb-4"><?= $settings['Welcome Heading'] ?? 'Welcome to SOUND' ?></h2>
        <p class="text-secondary mx-auto" style="max-width: 800px; font-size: 1.1rem;">
            <?= $settings['Welcome Description'] ?? 'Welcome to SOUND, your destination for discovering music and entertainment.' ?>
        </p>
        <p class="text-secondary mx-auto" style="max-width: 800px; font-size: 1.1rem;">
            Whether you are looking for a new song, exploring an artist, discovering an album or watching a video, SOUND makes it simple to find something that matches your mood.
        </p>
    </div>
</section>

<!-- Latest Music -->
<section class="section-padding">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-5 gsap-fade-up">
            <div>
                <h2 class="fw-bold mb-2">Latest Music</h2>
                <p class="text-secondary mb-0">Discover the newest additions to our music collection.</p>
            </div>
            <a href="music.php" class="btn btn-outline-light">View All Music</a>
        </div>
        
        <div class="horizontal-scroll gsap-stagger-cards">
            <?php foreach($latestMusic as $music): ?>
            <div class="col-card">
                <div class="music-card">
                    <?php if($music['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                    <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none text-light d-block">
                        <div class="card-img-wrapper">
                            <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" alt="<?= htmlspecialchars($music['song_name']) ?>">
                            <div class="play-overlay">
                                <i class="fas fa-play-circle play-btn play-music-btn" 
                                   data-src="/SOUND/assets/music/<?= $music['music_file'] ?>" 
                                   data-title="<?= htmlspecialchars($music['song_name']) ?>" 
                                   data-artist="<?= htmlspecialchars($music['artist_name']) ?>"
                                   data-cover="/SOUND/assets/images/<?= $music['cover_image'] ?>"></i>
                            </div>
                        </div>
                        <div class="p-3">
                            <h5 class="mb-1 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h5>
                            <p class="text-secondary mb-0 text-truncate"><?= htmlspecialchars($music['artist_name']) ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Latest Videos -->
<section class="section-padding bg-black">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-5 gsap-fade-up">
            <div>
                <h2 class="fw-bold mb-2">Latest Videos</h2>
                <p class="text-secondary mb-0">Watch the latest additions to the SOUND video collection.</p>
            </div>
            <a href="videos.php" class="btn btn-outline-light">View All Videos</a>
        </div>
        
        <div class="horizontal-scroll gsap-stagger-cards">
            <?php foreach($latestVideos as $video): ?>
            <div class="col-card" style="min-width: 300px;">
                <div class="video-card">
                    <?php if($video['is_new']): ?><span class="badge-new">NEW</span><?php endif; ?>
                    <a href="video_details.php?id=<?= $video['id'] ?>" class="text-decoration-none text-light d-block">
                        <div class="card-img-wrapper" style="height: 170px;">
                            <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" alt="<?= htmlspecialchars($video['video_name']) ?>">
                            <div class="play-overlay">
                                <i class="fas fa-play play-btn"></i>
                            </div>
                        </div>
                        <div class="p-3">
                            <h5 class="mb-1 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h5>
                            <p class="text-secondary mb-0 text-truncate"><?= htmlspecialchars($video['artist_name']) ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Artists -->
<section class="section-padding">
    <div class="container">
        <div class="text-center mb-5 gsap-fade-up">
            <h2 class="fw-bold mb-2">Featured Artists</h2>
            <p class="text-secondary">Meet the voices and creators behind the sounds you love.</p>
        </div>
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
            <?php foreach($featuredArtists as $artist): ?>
            <div class="col">
                <a href="artist_details.php?id=<?= $artist['id'] ?>" class="text-decoration-none text-center d-block artist-card-link">
                    <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle mb-3 border border-secondary" style="width:150px;height:150px;object-fit:cover;">
                    <h5 class="text-light mb-0"><?= htmlspecialchars($artist['name']) ?></h5>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Genres -->
<section class="section-padding bg-black">
    <div class="container">
        <div class="text-center mb-5 gsap-fade-up">
            <h2 class="fw-bold mb-2">Explore by Genre</h2>
            <p class="text-secondary">From timeless classics to modern sounds, explore entertainment across different genres.</p>
        </div>
        <div class="row row-cols-2 row-cols-md-4 g-3 gsap-stagger-cards">
            <?php foreach($genres as $genre): ?>
            <div class="col">
                <a href="genre_details.php?id=<?= $genre['id'] ?>" class="btn btn-outline-light w-100 py-3 fw-bold fs-5 rounded text-uppercase">
                    <?= htmlspecialchars($genre['name']) ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Pakistan Feature -->
<section class="section-padding text-center position-relative" style="background: linear-gradient(rgba(10,10,10,0.8), rgba(10,10,10,0.8)), url('/SOUND/assets/images/pakistan_bg.jpg') center/cover;">
    <div class="container gsap-fade-up">
        <h2 class="display-4 fw-bold mb-3 text-primary">The Sound of Pakistan</h2>
        <p class="lead text-light mb-4 mx-auto" style="max-width: 700px;">
            From timeless melodies to modern rhythms, Pakistani music continues to evolve while carrying stories, emotions and traditions across generations.
        </p>
        <a href="explore.php?region=pakistan" class="btn btn-primary btn-lg">Explore Pakistani Sounds</a>
    </div>
</section>

<!-- CTA -->
<section class="section-padding bg-black text-center">
    <div class="container gsap-fade-up">
        <h2 class="fw-bold mb-3">Find Your Next Favorite Sound</h2>
        <p class="text-secondary mb-4 mx-auto" style="max-width:600px;">
            Your next favorite song, artist or video could be just one click away. Create your SOUND account and become part of the community.
        </p>
        <div class="d-flex justify-content-center gap-3">
            <a href="explore.php" class="btn btn-primary btn-lg px-4">Start Exploring</a>
            <a href="auth/register.php" class="btn btn-outline-light btn-lg px-4">Create Account</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>`,

'auth/login.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if(isLoggedIn()) { header("Location: /SOUND/index.php"); exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = sanitize($_POST['login']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR user_id = ?)");
    $stmt->execute([$login, $login]);
    $user = $stmt->fetch();
    
    if($user && password_verify($password, $user['password'])) {
        if($user['status'] == 'inactive') {
            $_SESSION['error'] = "Your account is currently inactive.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            
            if($user['role'] == 'admin') header("Location: /SOUND/admin/index.php");
            else header("Location: /SOUND/user/dashboard.php");
            exit;
        }
    } else {
        $_SESSION['error'] = "Invalid User ID or password.";
    }
}
$pageTitle = "Login";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Welcome Back</h2>
        <p class="text-center text-secondary mb-4">Sign in to your SOUND account and continue exploring.</p>
        <?= getFlashError() ?>
        <?= getFlashSuccess() ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light">User ID or Email</label>
                <input type="text" name="login" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-light">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember">
                <label class="form-check-label text-secondary" for="remember">Remember Me</label>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Login</button>
        </form>
        <div class="text-center mt-4">
            <a href="forgot_password.php" class="text-primary text-decoration-none d-block mb-2">Forgot Password?</a>
            <span class="text-secondary">Don't have an account?</span> <a href="register.php" class="text-light text-decoration-none">Create an Account</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'auth/register.php': `<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if(isLoggedIn()) { header("Location: /SOUND/index.php"); exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $user_id = sanitize($_POST['user_id']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    
    if(empty($name) || empty($user_id) || empty($address) || empty($phone) || empty($email) || empty($password)) {
        $_SESSION['error'] = "Please fill in all required fields.";
    } elseif($password !== $confirm) {
        $_SESSION['error'] = "Passwords do not match.";
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        if($stmt->fetchColumn() > 0) {
            $_SESSION['error'] = "This User ID is already taken.";
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if($stmt->fetchColumn() > 0) {
                $_SESSION['error'] = "This email address is already registered.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (name, user_id, address, phone, email, password) VALUES (?, ?, ?, ?, ?, ?)");
                if($stmt->execute([$name, $user_id, $address, $phone, $email, $hashed])) {
                    $_SESSION['success'] = "Your account has been created successfully. Welcome to SOUND!";
                    header("Location: login.php");
                    exit;
                } else {
                    $_SESSION['error'] = "Something went wrong. Please try again.";
                }
            }
        }
    }
}
$pageTitle = "Register";
require_once '../includes/header.php';
?>
<div class="container auth-container gsap-fade-up">
    <div class="auth-card">
        <h2 class="fw-bold text-center mb-2">Create Your SOUND Account</h2>
        <p class="text-center text-secondary mb-4">Join the SOUND community and unlock the ability to rate and review your favorite music and videos.</p>
        <?= getFlashError() ?>
        <form method="POST">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Full Name *</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">User ID *</label>
                    <input type="text" name="user_id" class="form-control" placeholder="Choose a unique user ID" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label text-light">Email Address *</label>
                <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Phone Number *</label>
                    <input type="text" name="phone" class="form-control" placeholder="Enter your phone number" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Address *</label>
                    <input type="text" name="address" class="form-control" placeholder="Enter your complete address" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Password *</label>
                    <input type="password" name="password" class="form-control" placeholder="Create a password" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-light">Confirm Password *</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
                </div>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" required id="terms">
                <label class="form-check-label text-secondary" for="terms">I agree to the Terms & Conditions and Privacy Policy.</label>
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Create Account</button>
        </form>
        <div class="text-center mt-4">
            <span class="text-secondary">Already have an account?</span> <a href="login.php" class="text-light text-decoration-none">Login</a>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>`,

'auth/logout.php': `<?php
session_start();
session_destroy();
header("Location: /SOUND/index.php");
?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
