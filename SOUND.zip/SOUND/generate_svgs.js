const fs = require('fs');
const path = require('path');

const outputDir = 'C:/xampp/htdocs/SOUND/assets/images';

const colors = [
    ['#8B0000', '#2B0000'], ['#FF4500', '#8B0000'], ['#2F4F4F', '#000000'],
    ['#483D8B', '#000000'], ['#800080', '#2E0854'], ['#FFD700', '#8B0000'],
    ['#006400', '#000000'], ['#B22222', '#0A0A0A'], ['#FF1493', '#4B0082'],
    ['#008080', '#000000'], ['#DAA520', '#2E0854'], ['#CD5C5C', '#191970'],
    ['#DC143C', '#000000'], ['#D2691E', '#8B0000'], ['#FF8C00', '#000000'],
    ['#8B008B', '#000000'], ['#20B2AA', '#000000'], ['#C71585', '#2B0000'],
    ['#4B0082', '#000000'], ['#B8860B', '#2E0854']
];

const patterns = [
    '<circle cx="50%" cy="50%" r="40%" fill="none" stroke="white" stroke-width="2" stroke-dasharray="10 5" opacity="0.5"/>',
    '<rect x="10%" y="10%" width="80%" height="80%" fill="none" stroke="gold" stroke-width="2" opacity="0.4"/>',
    '<polygon points="0,100 100,0 100,100" fill="white" opacity="0.1"/>',
    '<path d="M0 50 Q 50 0 100 50 T 200 50" fill="none" stroke="white" stroke-width="4" opacity="0.3"/>',
    '<circle cx="20%" cy="80%" r="30%" fill="gold" opacity="0.2"/>',
    '<polygon points="50,10 90,90 10,90" fill="white" opacity="0.1"/>',
    '<rect x="0" y="50%" width="100%" height="50%" fill="black" opacity="0.5"/>',
    '<path d="M50 0 L100 50 L50 100 L0 50 Z" fill="white" opacity="0.2"/>'
];

function generateSVG(filename, text1, text2, type) {
    const [color1, color2] = colors[Math.floor(Math.random() * colors.length)];
    const pattern = patterns[Math.floor(Math.random() * patterns.length)];
    const id = Math.random().toString(36).substring(7);
    
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="${type==='video'?450:800}" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
            <linearGradient id="grad${id}" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:${color1};stop-opacity:1" />
                <stop offset="100%" style="stop-color:${color2};stop-opacity:1" />
            </linearGradient>
            <filter id="shadow${id}">
              <feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.5"/>
            </filter>
        </defs>
        <rect width="100" height="100" fill="url(#grad${id})" />
        ${pattern}
        <text x="50" y="45" font-family="Arial, sans-serif" font-size="${type==='video'?8:10}" font-weight="bold" fill="white" text-anchor="middle" filter="url(#shadow${id})">${text1.replace(/&/g, '&amp;')}</text>
        <text x="50" y="55" font-family="Arial, sans-serif" font-size="${type==='video'?4:5}" fill="rgba(255,255,255,0.7)" text-anchor="middle" letter-spacing="0.5">${text2.replace(/&/g, '&amp;')}</text>
        ${type === 'video' ? '<circle cx="50" cy="50" r="12" fill="rgba(0,0,0,0.5)"/><polygon points="46,42 46,58 58,50" fill="white"/>' : ''}
    </svg>`;
    
    fs.writeFileSync(path.join(outputDir, filename), svg);
}

// Ensure unique images for everything
const dbEntries = [
    {file: 'music1.svg', t1: 'Midnight in Lahore', t2: 'Ali Sethi', t: 'music'},
    {file: 'music2.svg', t1: 'Dil Ki Dastaan', t2: 'Atif Aslam', t: 'music'},
    {file: 'music3.svg', t1: 'Raat Ka Safar', t2: 'Uzair Jaswal', t: 'music'},
    {file: 'music4.svg', t1: 'Khwab', t2: 'Hadiqa Kiani', t: 'music'},
    {file: 'music5.svg', t1: 'Ishq Da Rang', t2: 'Abida Parveen', t: 'music'},
    {file: 'music6.svg', t1: 'Karachi Nights', t2: 'Young Stunners', t: 'music'},
    {file: 'music7.svg', t1: 'Tere Baad', t2: 'Ali Zafar', t: 'music'},
    {file: 'music8.svg', t1: 'Rang-e-Mohabbat', t2: 'Momina Mustehsan', t: 'music'},
    {file: 'music9.svg', t1: 'Saanson Mein', t2: 'Asim Azhar', t: 'music'},
    {file: 'music10.svg', t1: 'Chandni', t2: 'Naseebo Lal', t: 'music'},
    {file: 'music11.svg', t1: 'Dil Se Pakistan', t2: 'Junoon', t: 'music'},
    {file: 'music12.svg', t1: 'Shehr-e-Ishq', t2: 'Qurat-ul-Ain Balouch', t: 'music'},
    {file: 'music13.svg', t1: 'Barish', t2: 'Bilal Saeed', t: 'music'},
    {file: 'music14.svg', t1: 'Yaadon Ka Shehar', t2: 'Strings', t: 'music'},
    {file: 'music15.svg', t1: 'Safar', t2: 'Noori', t: 'music'},
    
    {file: 'vid1.svg', t1: 'Midnight in Lahore (Official Video)', t2: 'Cinematic View', t: 'video'},
    {file: 'vid2.svg', t1: 'Dil Ki Dastaan (Live)', t2: 'Concert Performance', t: 'video'},
    {file: 'vid3.svg', t1: 'Raat Ka Safar', t2: 'Music Video', t: 'video'},
    {file: 'vid4.svg', t1: 'Khwab (Acoustic)', t2: 'Studio Session', t: 'video'},
    {file: 'vid5.svg', t1: 'Ishq Da Rang', t2: 'Sufi Night', t: 'video'},
    {file: 'vid6.svg', t1: 'Karachi Nights', t2: 'Street Performance', t: 'video'},
    {file: 'vid7.svg', t1: 'Tere Baad', t2: 'Official Music Video', t: 'video'},
    {file: 'vid8.svg', t1: 'Rang-e-Mohabbat', t2: 'Live in Lahore', t: 'video'},
    {file: 'vid9.svg', t1: 'Saanson Mein', t2: 'Romantic Video', t: 'video'},
    {file: 'vid10.svg', t1: 'Chandni (Folk)', t2: 'Cultural Session', t: 'video'},
    {file: 'vid11.svg', t1: 'Dil Se Pakistan', t2: 'Anthem Video', t: 'video'},
    {file: 'vid12.svg', t1: 'Shehr-e-Ishq', t2: 'Official Video', t: 'video'},
    {file: 'vid13.svg', t1: 'Barish', t2: 'Rainy Scene', t: 'video'},
    {file: 'vid14.svg', t1: 'Yaadon Ka Shehar', t2: 'Classic Video', t: 'video'},
    {file: 'vid15.svg', t1: 'Safar', t2: 'Tour Video', t: 'video'},
    
    {file: 'artist1.svg', t1: 'Atif Aslam', t2: 'Artist', t: 'artist'},
    {file: 'artist2.svg', t1: 'Abida Parveen', t2: 'Artist', t: 'artist'},
    {file: 'artist3.svg', t1: 'Ali Zafar', t2: 'Artist', t: 'artist'},
    {file: 'artist4.svg', t1: 'Momina Mustehsan', t2: 'Artist', t: 'artist'},
    {file: 'artist5.svg', t1: 'Young Stunners', t2: 'Artist', t: 'artist'},
    {file: 'artist6.svg', t1: 'Ali Sethi', t2: 'Artist', t: 'artist'},
    {file: 'artist7.svg', t1: 'Naseebo Lal', t2: 'Artist', t: 'artist'},
    {file: 'artist8.svg', t1: 'Asim Azhar', t2: 'Artist', t: 'artist'},
    {file: 'artist9.svg', t1: 'Hadiqa Kiani', t2: 'Artist', t: 'artist'},
    {file: 'artist10.svg', t1: 'Junoon', t2: 'Artist', t: 'artist'},
    
    {file: 'album1.svg', t1: 'Jal Pari', t2: 'Album', t: 'album'},
    {file: 'album2.svg', t1: 'Raqs-e-Bismil', t2: 'Album', t: 'album'},
    {file: 'album3.svg', t1: 'Huqa Pani', t2: 'Album', t: 'album'},
    {file: 'album4.svg', t1: 'Awaaz', t2: 'Album', t: 'album'},
    {file: 'album5.svg', t1: 'Talisman', t2: 'Album', t: 'album'},
    {file: 'album6.svg', t1: 'Meri Kahani', t2: 'Album', t: 'album'},
    {file: 'album7.svg', t1: 'Parwaaz', t2: 'Album', t: 'album'},
    {file: 'album8.svg', t1: 'Dhaani', t2: 'Album', t: 'album'},
    {file: 'album9.svg', t1: 'Azadi', t2: 'Album', t: 'album'},
    {file: 'album10.svg', t1: 'Inqilab', t2: 'Album', t: 'album'},
    
    {file: 'pakistan_bg_hero.svg', t1: 'SOUND OF PAKISTAN', t2: 'MUSIC • VIDEOS • CULTURE', t: 'hero'}
];

dbEntries.forEach(entry => {
    generateSVG(entry.file, entry.t1, entry.t2, entry.t);
});

// Create an update script to modify the DB to use these files
const dbUpdates = `
<?php
require_once 'C:/xampp/htdocs/SOUND/config/db.php';
$pdo->query("UPDATE music SET cover_image = 'music' || id || '.svg' WHERE id <= 15");
$pdo->query("UPDATE videos SET thumbnail = 'vid' || id || '.svg' WHERE id <= 15");
$pdo->query("UPDATE artists SET image = 'artist' || id || '.svg' WHERE id <= 10");
$pdo->query("UPDATE albums SET cover = 'album' || id || '.svg' WHERE id <= 10");
echo "Database updated successfully.";
?>
`;
fs.writeFileSync('C:/xampp/htdocs/SOUND/update_db.php', dbUpdates);
