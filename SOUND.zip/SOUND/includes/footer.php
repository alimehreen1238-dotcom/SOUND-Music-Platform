    </main>
    <footer class="footer mt-auto py-5 bg-black text-light">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6">
                    <h3 class="fw-bold mb-3"><?= $settings['Website Name'] ?? 'SOUND' ?></h3>
                    <h6 class="text-primary mb-3"><?= $settings['Website Tagline'] ?? 'Your Sound. Your World.' ?></h6>
                    <p class="text-secondary"><?= $settings['Footer Text'] ?? 'Made for entertainment, discovery and connection.' ?></p>
                    <div class="social-links mt-4">
                        <a href="<?= $settings['Facebook URL'] ?? '#' ?>" class="me-3 fs-4 text-light"><i class="fab fa-facebook"></i></a>
                        <a href="<?= $settings['Instagram URL'] ?? '#' ?>" class="me-3 fs-4 text-light"><i class="fab fa-instagram"></i></a>
                        <a href="<?= $settings['YouTube URL'] ?? '#' ?>" class="fs-4 text-light"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="/SOUND/index.php">Home</a></li>
                        <li><a href="/SOUND/music.php">Music</a></li>
                        <li><a href="/SOUND/videos.php">Videos</a></li>
                        <li><a href="/SOUND/explore.php">Explore</a></li>
                        <li><a href="/SOUND/artists.php">Artists</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3">
                    <h5 class="mb-3">More</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="/SOUND/albums.php">Albums</a></li>
                        <li><a href="/SOUND/genres.php">Genres</a></li>
                        <li><a href="/SOUND/languages.php">Languages</a></li>
                        <li><a href="/SOUND/about.php">About</a></li>
                        <li><a href="/SOUND/contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="mb-3">Information</h5>
                    <ul class="list-unstyled footer-links mb-3">
                        <li><a href="/SOUND/faq.php">FAQ</a></li>
                        <li><a href="/SOUND/privacy_policy.php">Privacy Policy</a></li>
                        <li><a href="/SOUND/terms_conditions.php">Terms & Conditions</a></li>
                    </ul>
                    <p class="text-secondary mb-1"><i class="fas fa-envelope me-2"></i> <?= $settings['Contact Email'] ?? 'support@sound.com' ?></p>
                    <p class="text-secondary"><i class="fas fa-phone me-2"></i> <?= $settings['Contact Phone'] ?? '+92 300 1234567' ?></p>
                </div>
            </div>
            <div class="border-top border-secondary mt-4 pt-4 text-center text-secondary">
                <p class="mb-0"><?= $settings['Copyright Text'] ?? '© 2026 SOUND. All Rights Reserved.' ?></p>
            </div>
        </div>
    </footer>
    
    <!-- Mini Player Container -->
    <div id="mini-player" class="mini-player d-none">
        <div class="d-flex align-items-center w-100 px-3 py-2">
            <img id="mp-cover" src="/SOUND/assets/images/music/music1.jpg" alt="Cover" class="rounded me-3" style="width:50px;height:50px;object-fit:cover;">
            <div class="flex-grow-1 me-3 text-truncate">
                <h6 id="mp-title" class="mb-0 text-light text-truncate">Song Title</h6>
                <small id="mp-artist" class="text-secondary text-truncate">Artist</small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <button id="mp-play" class="btn text-light p-0 fs-3"><i class="fas fa-play-circle"></i></button>
                <button id="mp-close" class="btn text-secondary p-0 ms-2"><i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="progress-container px-3 pb-2 w-100">
            <input type="range" id="mp-progress" class="form-range" min="0" max="100" value="0">
        </div>
        <audio id="audio-element" src=""></audio>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="/SOUND/assets/js/main.js?v=6"></script>
</body>
</html>
