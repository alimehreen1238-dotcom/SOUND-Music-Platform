<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNavbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-3" href="/SOUND/index.php"><?= $settings['Website Name'] ?? 'SOUND' ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="/SOUND/index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/music.php">Music</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/videos.php">Videos</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/explore.php">Explore</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/artists.php">Artists</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/albums.php">Albums</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/genres.php">Genres</a></li>
                <li class="nav-item"><a class="nav-link" href="/SOUND/languages.php">Languages</a></li>
            </ul>
            <div class="d-flex align-items-center">
                <a href="/SOUND/search.php" class="text-light me-3 fs-5"><i class="fas fa-search"></i></a>
                <?php if (isLoggedIn()): ?>
                    <div class="dropdown">
                        <a class="btn btn-outline-light dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> Profile
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isAdmin()): ?>
                                <li><a class="dropdown-item" href="/SOUND/admin/index.php">Admin Panel</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="/SOUND/user/dashboard.php">Dashboard</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/SOUND/auth/logout.php">Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/SOUND/auth/login.php" class="btn btn-primary me-2">Login</a>
                    <a href="/SOUND/auth/register.php" class="btn btn-outline-light">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
