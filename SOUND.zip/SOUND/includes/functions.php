<?php
function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = "Please log in to continue.";
        header('Location: /SOUND/auth/login.php');
        exit;
    }
}
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /SOUND/403.php');
        exit;
    }
}
function sanitize($data) { return htmlspecialchars(strip_tags(trim($data))); }
function getFlashError() {
    if (isset($_SESSION['error'])) {
        $msg = $_SESSION['error']; unset($_SESSION['error']);
        return "<div class='alert alert-danger'>$msg</div>";
    }
    return '';
}
function getFlashSuccess() {
    if (isset($_SESSION['success'])) {
        $msg = $_SESSION['success']; unset($_SESSION['success']);
        return "<div class='alert alert-success'>$msg</div>";
    }
    return '';
}
function getStars($rating) {
    $stars = '';
    for($i=1; $i<=5; $i++) {
        if($i <= $rating) $stars .= '<i class="fas fa-star text-warning"></i>';
        else $stars .= '<i class="far fa-star text-warning"></i>';
    }
    return $stars;
}
?>