const fs = require('fs');
const path = require('path');
const basePath = 'C:/xampp/htdocs/SOUND';
const files = {
'artists.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$query = "SELECT a.*, g.name as genre_name, l.name as language_name,
          (SELECT COUNT(*) FROM music WHERE artist_id = a.id) as releases
          FROM artists a
          LEFT JOIN genres g ON a.genre_id = g.id
          LEFT JOIN languages l ON a.language_id = l.id
          WHERE 1=1";
$params = [];

if($search) {
    $query .= " AND a.name LIKE ?";
    $params[] = "%$search%";
}
$query .= " ORDER BY a.name ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$artistList = $stmt->fetchAll();

$pageTitle = "Discover Artists";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Discover Artists</h1>
            <p class="text-secondary">Explore artists from different genres, languages and regions. Discover their music, videos and albums.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="artists.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search artists..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($artistList) > 0): ?>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 gsap-stagger-cards">
        <?php foreach($artistList as $artist): ?>
        <div class="col">
            <div class="card bg-dark text-white h-100 border-secondary text-center p-3 artist-card hover-bg-primary transition-all">
                <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle mx-auto mb-3" style="width:120px;height:120px;object-fit:cover;">
                <h5 class="card-title fw-bold mb-1"><?= htmlspecialchars($artist['name']) ?></h5>
                <p class="text-secondary mb-2 small"><?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?> • <?= htmlspecialchars($artist['language_name'] ?? 'Various') ?></p>
                <p class="text-muted small mb-3"><?= $artist['releases'] ?> releases</p>
                <a href="artist_details.php?id=<?= $artist['id'] ?>" class="btn btn-outline-light btn-sm rounded-pill mt-auto">View Artist</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-users fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No artists found.</h4>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'artist_details.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT a.*, g.name as genre_name, l.name as language_name
          FROM artists a
          LEFT JOIN genres g ON a.genre_id = g.id
          LEFT JOIN languages l ON a.language_id = l.id
          WHERE a.id = ?");
$stmt->execute([$id]);
$artist = $stmt->fetch();

if(!$artist) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM music WHERE artist_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 8");
$stmt->execute([$id]);
$musicList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM videos WHERE artist_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 6");
$stmt->execute([$id]);
$videoList = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM albums WHERE artist_id = ? ORDER BY created_at DESC LIMIT 6");
$stmt->execute([$id]);
$albumList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($artist['name']);
require_once 'includes/header.php';
?>
<!-- Artist Hero -->
<section class="position-relative" style="height: 400px; background: linear-gradient(to top, rgba(10,10,10,1), rgba(10,10,10,0.4)), url('/SOUND/assets/images/<?= $artist['image'] ?>') center/cover; margin-top: -80px; padding-top: 80px;">
    <div class="container h-100 d-flex align-items-end pb-5 gsap-fade-up">
        <div class="d-flex align-items-end">
            <img src="/SOUND/assets/images/<?= $artist['image'] ?>" class="rounded-circle border border-4 border-dark me-4 shadow" style="width:200px;height:200px;object-fit:cover;">
            <div>
                <h1 class="display-3 fw-bold text-white mb-2"><?= htmlspecialchars($artist['name']) ?></h1>
                <p class="fs-5 text-light mb-0">
                    <span class="badge bg-primary me-2"><?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?></span>
                    <span class="badge bg-secondary me-2"><?= htmlspecialchars($artist['language_name'] ?? 'Various') ?></span>
                    <span class="text-muted"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($artist['region'] ?? '') ?>, <?= htmlspecialchars($artist['country'] ?? '') ?></span>
                </p>
            </div>
        </div>
    </div>
</section>

<div class="container py-5 gsap-fade-up">
    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-3 border-bottom border-secondary pb-2">About the Artist</h4>
            <p class="text-light text-justify mb-5" style="line-height:1.8;">
                <?= htmlspecialchars($artist['name']) ?> is an artist known for their work in <?= htmlspecialchars($artist['genre_name'] ?? 'Various') ?> music and entertainment. Explore the artist's music, videos and albums available on SOUND.
                <br><br>
                <?= nl2br(htmlspecialchars($artist['biography'] ?? '')) ?>
            </p>

            <h4 class="fw-bold mb-4">Music by <?= htmlspecialchars($artist['name']) ?></h4>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3 mb-5">
                <?php foreach($musicList as $music): ?>
                <div class="col">
                    <a href="music_details.php?id=<?= $music['id'] ?>" class="text-decoration-none">
                        <div class="card bg-dark border-secondary h-100">
                            <img src="/SOUND/assets/images/<?= $music['cover_image'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                            <div class="card-body p-2">
                                <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($music['song_name']) ?></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if(count($albumList) > 0): ?>
            <h4 class="fw-bold mb-4">Albums by <?= htmlspecialchars($artist['name']) ?></h4>
            <div class="row row-cols-2 row-cols-md-3 g-3 mb-5">
                <?php foreach($albumList as $album): ?>
                <div class="col">
                    <a href="album_details.php?id=<?= $album['id'] ?>" class="text-decoration-none">
                        <div class="card bg-dark border-secondary">
                            <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="card-img-top" style="height:150px;object-fit:cover;">
                            <div class="card-body p-2 text-center">
                                <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($album['name']) ?></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <?php if(count($videoList) > 0): ?>
            <h5 class="fw-bold mb-4">Videos by <?= htmlspecialchars($artist['name']) ?></h5>
            <?php foreach($videoList as $video): ?>
                <a href="video_details.php?id=<?= $video['id'] ?>" class="d-block text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary">
                    <img src="/SOUND/assets/images/<?= $video['thumbnail'] ?>" class="rounded w-100 mb-2" style="height:120px;object-fit:cover;">
                    <h6 class="text-light mb-0 text-truncate"><?= htmlspecialchars($video['video_name']) ?></h6>
                </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'albums.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$query = "SELECT al.*, a.name as artist_name, g.name as genre_name, y.year, l.name as language_name,
          (SELECT COUNT(*) FROM music WHERE album_id = al.id) as tracks
          FROM albums al
          LEFT JOIN artists a ON al.artist_id = a.id
          LEFT JOIN genres g ON al.genre_id = g.id
          LEFT JOIN years y ON al.year_id = y.id
          LEFT JOIN languages l ON al.language_id = l.id
          WHERE 1=1";
$params = [];

if($search) {
    $query .= " AND (al.name LIKE ? OR a.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%";
}
$query .= " ORDER BY al.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$albumList = $stmt->fetchAll();

$pageTitle = "Explore Albums";
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5">
        <div class="col-md-6">
            <h1 class="fw-bold mb-2">Explore Albums</h1>
            <p class="text-secondary">Browse albums from different artists, genres, years and languages.</p>
        </div>
        <div class="col-md-6">
            <form method="GET" action="albums.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control" placeholder="Search albums..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <?php if(count($albumList) > 0): ?>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4 gsap-stagger-cards">
        <?php foreach($albumList as $album): ?>
        <div class="col">
            <div class="album-card h-100 p-2">
                <a href="album_details.php?id=<?= $album['id'] ?>" class="text-decoration-none text-light d-block h-100">
                    <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="w-100 rounded mb-3 shadow" style="height:180px;object-fit:cover;">
                    <h6 class="fw-bold mb-1 text-truncate"><?= htmlspecialchars($album['name']) ?></h6>
                    <small class="text-secondary d-block text-truncate"><?= htmlspecialchars($album['artist_name']) ?></small>
                    <small class="text-muted d-block mt-2"><?= $album['year'] ?? 'Unknown' ?> • <?= $album['tracks'] ?> tracks</small>
                    <div class="mt-3 text-center"><span class="btn btn-sm btn-outline-light w-100">View Album</span></div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-record-vinyl fs-1 text-muted mb-3"></i>
        <h4 class="text-light">No albums found.</h4>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>`,

'album_details.php': `<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT al.*, a.name as artist_name, g.name as genre_name, y.year, l.name as language_name
          FROM albums al
          LEFT JOIN artists a ON al.artist_id = a.id
          LEFT JOIN genres g ON al.genre_id = g.id
          LEFT JOIN years y ON al.year_id = y.id
          LEFT JOIN languages l ON al.language_id = l.id
          WHERE al.id = ?");
$stmt->execute([$id]);
$album = $stmt->fetch();

if(!$album) { header("Location: 404.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM music WHERE album_id = ? AND status = 'active' ORDER BY created_at ASC");
$stmt->execute([$id]);
$trackList = $stmt->fetchAll();

$pageTitle = htmlspecialchars($album['name']);
require_once 'includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row mb-5 align-items-center">
        <div class="col-md-4 text-center text-md-start mb-4 mb-md-0">
            <img src="/SOUND/assets/images/<?= $album['cover'] ?>" class="img-fluid rounded shadow-lg border border-secondary" style="max-width:300px;">
        </div>
        <div class="col-md-8">
            <p class="text-primary fw-bold tracking-wide mb-1">ALBUM</p>
            <h1 class="display-4 fw-bold mb-2"><?= htmlspecialchars($album['name']) ?></h1>
            <h4 class="text-secondary mb-4">By <a href="artist_details.php?id=<?= $album['artist_id'] ?>" class="text-light text-decoration-none"><?= htmlspecialchars($album['artist_name']) ?></a></h4>
            
            <ul class="list-unstyled text-muted mb-4">
                <li><strong class="text-light">Release Year:</strong> <?= htmlspecialchars($album['year'] ?? 'Unknown') ?></li>
                <li><strong class="text-light">Genre:</strong> <?= htmlspecialchars($album['genre_name'] ?? 'Unknown') ?></li>
                <li><strong class="text-light">Language:</strong> <?= htmlspecialchars($album['language_name'] ?? 'Unknown') ?></li>
            </ul>

            <h5 class="fw-bold mb-2">About This Album</h5>
            <p class="text-light mb-0" style="max-width: 600px;">
                <?= htmlspecialchars($album['description'] ?? $album['name'].' is a collection of music by '.$album['artist_name'].'. Explore the tracks included in this album and discover more music from the artist.') ?>
            </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <h4 class="fw-bold mb-4 border-bottom border-secondary pb-2">Track List</h4>
            <div class="list-group list-group-flush bg-transparent">
                <?php $i=1; foreach($trackList as $track): ?>
                <div class="list-group-item bg-transparent text-light border-secondary py-3 d-flex align-items-center justify-content-between hover-bg-dark">
                    <div class="d-flex align-items-center">
                        <span class="text-secondary me-3" style="width:25px;"><?= sprintf("%02d", $i++) ?></span>
                        <button class="btn btn-sm btn-outline-light rounded-circle play-music-btn me-3" style="width:35px;height:35px;"
                           data-src="/SOUND/assets/music/<?= $track['music_file'] ?>" 
                           data-title="<?= htmlspecialchars($track['song_name']) ?>" 
                           data-artist="<?= htmlspecialchars($album['artist_name']) ?>"
                           data-cover="/SOUND/assets/images/<?= $album['cover'] ?>">
                            <i class="fas fa-play"></i>
                        </button>
                        <div>
                            <a href="music_details.php?id=<?= $track['id'] ?>" class="text-light fw-bold text-decoration-none d-block"><?= htmlspecialchars($track['song_name']) ?></a>
                            <small class="text-secondary"><?= htmlspecialchars($album['artist_name']) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if(empty($trackList)): ?>
                <p class="text-secondary">No tracks found in this album.</p>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <h5 class="fw-bold mb-4 mt-4 mt-md-0">More Albums by <?= htmlspecialchars($album['artist_name']) ?></h5>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM albums WHERE artist_id = ? AND id != ? LIMIT 3");
            $stmt->execute([$album['artist_id'], $id]);
            $related = $stmt->fetchAll();
            foreach($related as $rel):
            ?>
                <a href="album_details.php?id=<?= $rel['id'] ?>" class="d-flex align-items-center text-decoration-none mb-3 bg-dark p-2 rounded border border-secondary hover-bg-primary">
                    <img src="/SOUND/assets/images/<?= $rel['cover'] ?>" class="rounded me-3" style="width:60px;height:60px;object-fit:cover;">
                    <div>
                        <h6 class="text-light mb-1 text-truncate" style="max-width: 150px;"><?= htmlspecialchars($rel['name']) ?></h6>
                        <small class="text-secondary"><?= $rel['year'] ?? '' ?></small>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>`
};
for (const [relPath, content] of Object.entries(files)) { fs.writeFileSync(path.join(basePath, relPath), content); }
