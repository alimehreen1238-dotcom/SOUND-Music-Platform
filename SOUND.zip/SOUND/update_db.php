
<?php
require_once 'C:/xampp/htdocs/SOUND/config/db.php';
$pdo->query("UPDATE music SET cover_image = 'music' || id || '.svg' WHERE id <= 15");
$pdo->query("UPDATE videos SET thumbnail = 'vid' || id || '.svg' WHERE id <= 15");
$pdo->query("UPDATE artists SET image = 'artist' || id || '.svg' WHERE id <= 10");
$pdo->query("UPDATE albums SET cover = 'album' || id || '.svg' WHERE id <= 10");
echo "Database updated successfully.";
?>
