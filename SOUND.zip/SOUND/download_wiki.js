const https = require('https');
const fs = require('fs');
const path = require('path');

const baseImgDir = 'C:/xampp/htdocs/SOUND/assets/images';

function getWikiImages(query, limit) {
    return new Promise((resolve) => {
        const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=${limit}&prop=imageinfo&iiprop=url&format=json`;
        https.get(url, { headers: { 'User-Agent': 'SOUND-Project/1.0 (test@example.com)' } }, res => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (!parsed.query || !parsed.query.pages) return resolve([]);
                    const urls = Object.values(parsed.query.pages)
                        .map(p => p.imageinfo && p.imageinfo[0] ? p.imageinfo[0].url : null)
                        .filter(u => u && (u.endsWith('.jpg') || u.endsWith('.jpeg') || u.endsWith('.png')));
                    resolve(urls);
                } catch(e) { resolve([]); }
            });
        }).on('error', () => resolve([]));
    });
}

const downloadFile = (url, filepath) => {
    return new Promise((resolve) => {
        https.get(url, { headers: { 'User-Agent': 'SOUND-Project/1.0 (test@example.com)' } }, (res) => {
            if (res.statusCode === 200) {
                const file = fs.createWriteStream(filepath);
                res.pipe(file);
                file.on('finish', () => { file.close(); resolve(true); });
            } else {
                resolve(false);
            }
        }).on('error', () => resolve(false));
    });
};

async function processAll() {
    console.log("Fetching Wiki URLs...");
    const terms = ['singer performance', 'concert crowd', 'guitar playing', 'microphone studio', 'pakistan music'];
    let allUrls = [];
    
    for (let term of terms) {
        const urls = await getWikiImages(term, 20);
        allUrls.push(...urls);
    }
    
    // Deduplicate
    allUrls = [...new Set(allUrls)];
    console.log("Total unique real images found: " + allUrls.length);
    
    if (allUrls.length < 10) {
        console.log("Not enough images found.");
        return;
    }
    
    let uIdx = 0;
    const nextUrl = () => allUrls[uIdx++ % allUrls.length];

    const tasks = [
        { file: 'hero/hero_bg.jpg' },
        ...Array.from({length: 15}, (_, i) => ({ file: `music/music${i+1}.jpg` })),
        ...Array.from({length: 15}, (_, i) => ({ file: `videos/vid${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `artists/art${i+1}.jpg` })),
        ...Array.from({length: 10}, (_, i) => ({ file: `albums/alb${i+1}.jpg` }))
    ];
    
    for (let t of tasks) {
        let success = await downloadFile(nextUrl(), path.join(baseImgDir, t.file));
        if(!success) console.log("Failed " + t.file);
    }
    console.log("All downloads complete.");
}

processAll();
