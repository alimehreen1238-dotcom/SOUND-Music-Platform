<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();
if(isAdmin()) { header("Location: /SOUND/admin/index.php"); exit; }

$stmt = $pdo->prepare("SELECT COUNT(*) FROM reviews WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$totalReviews = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM ratings WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$totalRatings = $stmt->fetchColumn();

$pageTitle = "Dashboard";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <h2 class="fw-bold mb-2">Welcome Back, <?= htmlspecialchars($_SESSION['name']) ?></h2>
    <p class="text-secondary mb-5">Manage your SOUND account, reviews and ratings from your personal dashboard.</p>
    
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-comment-dots fs-1 text-primary mb-3"></i>
                    <h4>My Reviews</h4>
                    <p class="text-secondary">You have <?= $totalReviews ?> reviews.</p>
                    <a href="my_reviews.php" class="btn btn-outline-light mt-2">Manage Reviews</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-star fs-1 text-primary mb-3"></i>
                    <h4>My Ratings</h4>
                    <p class="text-secondary">You have <?= $totalRatings ?> ratings.</p>
                    <a href="my_ratings.php" class="btn btn-outline-light mt-2">Manage Ratings</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white h-100 border-secondary">
                <div class="card-body text-center p-4">
                    <i class="fas fa-user fs-1 text-primary mb-3"></i>
                    <h4>My Profile</h4>
                    <p class="text-secondary">View and edit your account information.</p>
                    <a href="profile.php" class="btn btn-outline-light mt-2">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center">
        <a href="../music.php" class="btn btn-primary px-4 me-2">Explore Music</a>
        <a href="../videos.php" class="btn btn-outline-light px-4">Explore Videos</a>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>