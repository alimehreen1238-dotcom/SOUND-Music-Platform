<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    
    $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
    if($stmt->execute([$name, $phone, $address, $_SESSION['user_id']])) {
        $_SESSION['name'] = $name;
        $_SESSION['success'] = "Your profile has been updated successfully.";
        header("Location: profile.php");
        exit;
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again.";
    }
}
$pageTitle = "My Profile";
require_once '../includes/header.php';
?>
<div class="container section-padding gsap-fade-up">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark text-white border-secondary">
                <div class="card-header border-secondary bg-transparent p-4">
                    <h3 class="mb-1">My Profile</h3>
                    <p class="text-secondary mb-0">View and manage your personal account information.</p>
                </div>
                <div class="card-body p-4">
                    <?= getFlashSuccess() ?>
                    <?= getFlashError() ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-secondary">User ID</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($user['user_id']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-secondary">Email Address</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-light">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label text-light">Address</label>
                            <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($user['address']) ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                        <a href="dashboard.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>